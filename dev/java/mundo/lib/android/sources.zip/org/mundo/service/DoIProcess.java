package org.mundo.service;


/**
 * Automatically generated distributed object class for <code>IProcess</code>.
 * @see org.mundo.service.IProcess
 */
public class DoIProcess extends org.mundo.rt.DoObject implements org.mundo.service.IProcess
{
  public DoIProcess()
  {
  }
  public DoIProcess(org.mundo.rt.Session session, Object obj) throws org.mundo.rt.RMCException
  {
    _bind(session, obj);
  }
  public DoIProcess(org.mundo.rt.Channel channel) throws org.mundo.rt.RMCException
  {
    _setPublisher(channel.getSession().publish(channel.getZone(), channel.getName()));
  }
  public DoIProcess(org.mundo.rt.DoObject o)
  {
    _assign(o);
  }
  public org.mundo.rt.ServerStub _getServerStub()
  {
    return SrvIProcess._getObject();
  }
  public static DoIProcess _of(org.mundo.rt.Session session, Object obj)
  {
    DoIProcess cs=(DoIProcess)_getDoObject(session, DoIProcess.class, obj);
    if (cs==null)
    {
      cs=new DoIProcess(session, obj);
      _putDoObject(session, obj, cs);
    }
    return cs;
  }
  public static DoIProcess _of(org.mundo.rt.Service s)
  {
    return _of(s.getSession(), s);
  }
  public String _getInterfaceName()
  {
    return "org.mundo.service.IProcess";
  }
  public static IProcess _localObject(IProcess obj)
  {
    if (obj instanceof org.mundo.rt.DoObject)
    {
      return (IProcess)((org.mundo.rt.DoObject)obj)._getLocalObject();
    }
    else
    {
      return obj;
    }
  }
  public String getSignalChannel()
  {
    if (localObj!=null) 
    {
      return ((org.mundo.service.IProcess)localObj).getSignalChannel();
    }
    org.mundo.rt.AsyncCall call=getSignalChannel(SYNC);
    return call.getMap().getString("value");
  }
  public org.mundo.rt.AsyncCall getSignalChannel(Options opt) 
  {
    org.mundo.rt.TypedMap m=new org.mundo.rt.TypedMap();
    m.putString("ptypes", "");
    m.putString("rtype", "s");
    org.mundo.rt.AsyncCall call=new org.mundo.rt.AsyncCall(this, "org.mundo.service.IProcess", "getSignalChannel", m);
    if (opt==ONEWAY)
    {
      call.invokeOneWay();
    }
    else if (opt==SYNC || opt==ASYNC)
    {
      call.invoke();
    }
    if (opt==SYNC)
    {
      try
      {
        if (!call.waitForReply())
        {
          throw call.getException();
        }
      }
      catch(RuntimeException x)
      {
        throw x;
      }
      catch(Exception x)
      {
        throw new org.mundo.rt.RMCException("unexpected exception", x);
      }
    }
    return call;
  }
  
  public String getName()
  {
    if (localObj!=null) 
    {
      return ((org.mundo.service.IProcess)localObj).getName();
    }
    org.mundo.rt.AsyncCall call=getName(SYNC);
    return call.getMap().getString("value");
  }
  public org.mundo.rt.AsyncCall getName(Options opt) 
  {
    org.mundo.rt.TypedMap m=new org.mundo.rt.TypedMap();
    m.putString("ptypes", "");
    m.putString("rtype", "s");
    org.mundo.rt.AsyncCall call=new org.mundo.rt.AsyncCall(this, "org.mundo.service.IProcess", "getName", m);
    if (opt==ONEWAY)
    {
      call.invokeOneWay();
    }
    else if (opt==SYNC || opt==ASYNC)
    {
      call.invoke();
    }
    if (opt==SYNC)
    {
      try
      {
        if (!call.waitForReply())
        {
          throw call.getException();
        }
      }
      catch(RuntimeException x)
      {
        throw x;
      }
      catch(Exception x)
      {
        throw new org.mundo.rt.RMCException("unexpected exception", x);
      }
    }
    return call;
  }
  
  public org.mundo.rt.GUID getNodeId()
  {
    if (localObj!=null) 
    {
      return ((org.mundo.service.IProcess)localObj).getNodeId();
    }
    org.mundo.rt.AsyncCall call=getNodeId(SYNC);
    return (org.mundo.rt.GUID)call.getObj();
  }
  public org.mundo.rt.AsyncCall getNodeId(Options opt) 
  {
    org.mundo.rt.TypedMap m=new org.mundo.rt.TypedMap();
    m.putString("ptypes", "");
    m.putString("rtype", "g");
    org.mundo.rt.AsyncCall call=new org.mundo.rt.AsyncCall(this, "org.mundo.service.IProcess", "getNodeId", m);
    if (opt==ONEWAY)
    {
      call.invokeOneWay();
    }
    else if (opt==SYNC || opt==ASYNC)
    {
      call.invoke();
    }
    if (opt==SYNC)
    {
      try
      {
        if (!call.waitForReply())
        {
          throw call.getException();
        }
      }
      catch(RuntimeException x)
      {
        throw x;
      }
      catch(Exception x)
      {
        throw new org.mundo.rt.RMCException("unexpected exception", x);
      }
    }
    return call;
  }
  
  public boolean shutdownNode()
  {
    if (localObj!=null) 
    {
      return ((org.mundo.service.IProcess)localObj).shutdownNode();
    }
    org.mundo.rt.AsyncCall call=shutdownNode(SYNC);
    return call.getMap().getBoolean("value");
  }
  public org.mundo.rt.AsyncCall shutdownNode(Options opt) 
  {
    org.mundo.rt.TypedMap m=new org.mundo.rt.TypedMap();
    m.putString("ptypes", "");
    m.putString("rtype", "t");
    org.mundo.rt.AsyncCall call=new org.mundo.rt.AsyncCall(this, "org.mundo.service.IProcess", "shutdownNode", m);
    if (opt==ONEWAY)
    {
      call.invokeOneWay();
    }
    else if (opt==SYNC || opt==ASYNC)
    {
      call.invoke();
    }
    if (opt==SYNC)
    {
      try
      {
        if (!call.waitForReply())
        {
          throw call.getException();
        }
      }
      catch(RuntimeException x)
      {
        throw x;
      }
      catch(Exception x)
      {
        throw new org.mundo.rt.RMCException("unexpected exception", x);
      }
    }
    return call;
  }
  
}