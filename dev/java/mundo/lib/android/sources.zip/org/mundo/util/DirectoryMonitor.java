/*
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is MundoCore Java.
 *
 * The Initial Developer of the Original Code is Telecooperation Group,
 * Department of Computer Science, Darmstadt University of Technology.
 * Portions created by the Initial Developer are
 * Copyright (C) 2001-2008 the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 * Erwin Aitenbichler
 */

package org.mundo.util;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeSet;

import org.mundo.rt.IEmits;
import org.mundo.rt.Mundo;
import org.mundo.rt.Publisher;
import org.mundo.rt.Service;
import org.mundo.rt.Signal;

            







/**
 * A DirectoryMonitor monitors a given directory for changes. If files are
 * added, deleted or modified, it sends events to all classes registered to the
 * emission interface. Changes in subdirectories are ignored. If a file is
 * renamed, this will be recognized as one file being deleted and another one
 * being created.
 * 
 * If the directory itself is deleted, a DirectoryMonitor sends delete events
 * for each file contained in the directory first, then a delete event about the
 * file "." to be deleted. As further monitoring does not make any sense, it
 * stops the thread - so if in the future a new directory with the same name is
 * created, this will not be monitored.
 * 
 * Lacking a general purpose Java event mechanism for monitoring files for
 * changes, this class polls the directory. The default interval between two
 * checks of the filesystem is 500ms.
 * 
 * @author AHa
 */
public class DirectoryMonitor extends Service implements IDirectoryMonitor, org.mundo.rt.IEmits /*emits IDirectoryMonitor.IDirectoryModification*/ {

  /**
   * Stores name and modification date for a File. The class is immutable and
   * sorts (alphabetically) by the file name.
   */
  private static class FileInfo implements Comparable<FileInfo> {

    /**
     * A singleton specifying an empty file. The empty file has metadata about
     * the directory.
     */
    public final static FileInfo EMPTY = new FileInfo();

    /**
     * The last modification date. Not used for comparing.
     */
    private final long lastModified;

    /**
     * The name of the file.
     */
    private final String name;

    /**
     * Private constructor for the EMPTY singleton.
     */
    private FileInfo() {
      name = ".";
      lastModified = 0;
    }

    /**
     * This constructor converts the data to be received from a File object to a
     * FileInfo object.
     * 
     * @param tostore the File object to be converted
     */
    public FileInfo(File tostore) {
      name = tostore.getName();
      lastModified = tostore.lastModified();
    }

    /**
     * Compares two FileInfo objects based on their names.
     * EMPTY.compareTo(FileInfo) always leads to 1, FileInfo.compareTo(EMPTY)
     * always leads to -1.
     * 
     * @param o the Object to compare the FileInfo to
     * @throws ClassCastException if o is no instance of FileInfo
     */
    public int compareTo(FileInfo o) {


      if(this == EMPTY)
        return o != EMPTY ? 1 : 0;
      else if(o == EMPTY)
        return -1;
      else
        return name.compareTo(((FileInfo)o).name);
    }

    public boolean equals(Object o) {
      if(this == o)
        return true;
      if(o == null || this == EMPTY)
        return false;
      if(o.getClass() != getClass())
        return false;

      FileInfo castedObj = (FileInfo)o;
      return this.name == null ? castedObj.name == null : this.name.equals(castedObj.name);
    }

    public int hashCode() {
      return name.hashCode();
    }

    public String toString() {
      return name;
    }

  }

  /**
   * The class for the working thread
   */
  private class Worker implements Runnable {

    /**
     * The directory to monitor
     */
    private File dir;

    /**
     * An array of size 1. If set to true, the thread will stop itself. The
     * array is used in order to have a reference.
     */
    private boolean stopRequest[];

    public Worker(File dir, boolean stopRequest[]) {
      this.dir = dir;
      this.stopRequest = stopRequest;
    }

    /**
     * Since Java lacks a nice generic map() function for lists and arrays, this
     * method does the work necessary. It maps an array of File objects to a
     * List of FileInfo objects. The relationship is as such, that for each i:
     * new FileInfo(list[i]).equals(returnvalue.get(i))
     * 
     * @param list an array of Files like the list from File#listFiles()
     * @return A List&lt;FileInfo> that have been mapped from <code>list</code>
     */
    private List<FileInfo> mapFileToFileStorage(File list[]) {
      if(list == null || list.length == 0)
        return Collections.emptyList();



      List<FileInfo> ret = new ArrayList<FileInfo>(list.length);
      for(int i = 0; i < list.length; i++)
        ret.add(new FileInfo(list[i]));
      return ret;
    }

    /**
     * Returns the next file out of a Iterator that iterates over a File if
     * possible. If the Iterator runs out of files, this method returns an EMPTY
     * FileInfo
     */
    private FileInfo nextFile(Iterator iter) {
      return iter.hasNext() ? (FileInfo)iter.next() : FileInfo.EMPTY;
    }

    private void notifyDeleted(FileInfo oldfile) {
      emit.fileRemoved(dir, new File(dir, oldfile.name));
    }

    private void notifyModified(FileInfo name) {
      emit.fileModified(dir, new File(dir, name.name));
    }

    private void notifyNew(FileInfo newfile) {
      emit.fileAdded(dir, new File(dir, newfile.name));
    }

    public void run() {
      // The content of the directory at the time of the last refresh. Sorted
      // using the File's compareTo method
      SortedSet<FileInfo> content = new TreeSet<FileInfo>(mapFileToFileStorage(dir.listFiles()));

      try {
        while(!stopRequest[0]) {
          // wait - for the polling
          Thread.sleep(interval);

          // check if the directory still exists - if not, make a final
          // notification and shutdown
          if(!dir.exists()) {
            for(Iterator i = content.iterator(); i.hasNext();)
              notifyDeleted((FileInfo)i.next());
            // for(FileInfo info: content)
              // notifyDeleted(info);
            notifyDeleted(FileInfo.EMPTY);

            stopRequest[0] = true;
            break;
          }

          // list the current entries
          SortedSet<FileInfo> newContent = new TreeSet<FileInfo>(mapFileToFileStorage(dir.listFiles()));
          // iterate through the sets, compare them and generate the
          // appropriate events
          Iterator contentIterator = content.iterator(), newIterator = newContent
              .iterator();

          FileInfo oldEntry, newEntry;
          // initialize the file pointers with the first element.
          oldEntry = nextFile(contentIterator);
          newEntry = nextFile(newIterator);

          while(oldEntry != FileInfo.EMPTY || newEntry != FileInfo.EMPTY) {
            int cmp = oldEntry.compareTo(newEntry);

            // the current file has a name coming after the current file
            if(cmp == 0) {
              if(oldEntry.lastModified < newEntry.lastModified)
                notifyModified(newEntry);

              oldEntry = nextFile(contentIterator);
              newEntry = nextFile(newIterator);
            } else if(cmp > 0) {
              notifyNew(newEntry);
              newEntry = nextFile(newIterator);
            } else { // (cmp < 0)
              notifyDeleted(oldEntry);
              oldEntry = nextFile(contentIterator);
            }
          }
          // the new file list replaces the old one
          content = newContent;
        }
      } catch(InterruptedException interrupt) {
        // do nothing
      }
    }

  }

  /**
   * A single DirectoryMonitor object that may be registered as a MundoService
   */
  private static DirectoryMonitor mysingleton;
  
  /**
   * All threads started by this service are part of the monitor group. This eases debugging.
   */
  private ThreadGroup monitorgroup;

  /**
   * Monitors a given directory with a given interval.
   * 
   * @param dir the directory to monitor
   * @throws IOException if <code>dir</code> does not exist or if it is not a
   *               directory
   */
  public static void monitorDirectory(File dir) throws IOException {
    if(!dir.exists())
      throw new IOException(dir.getAbsolutePath() + " does not exist");
    if(!dir.isDirectory())
      throw new IOException(dir.getAbsolutePath() + " is not a directory");
    String path = dir.getCanonicalPath();

    if(mysingleton == null) {
      mysingleton = new DirectoryMonitor();
      Mundo.registerService(mysingleton);
    }
    mysingleton.addMonitoringThread(path, dir);
  }

  /**
   * Monitors a given directory with a given interval and connects a slot object
   * to it.
   * 
   * @param dir the directory to monitor
   * @param target the object holding the slot for
   *              IDirectoryMonitor.IDirectoryModification signals
   * @throws IOException if <code>dir</code> does not exist or if it is not a
   *               directory
   */
  public static void monitorDirectory(File dir, Object target)
      throws IOException {
    monitorDirectory(dir);
    Signal.connect("rt", IDirectoryMonitor.IDirectoryModification.class, target);
  }

  /**
   * Sets the interval between two checks of the filesystem.
   * 
   * @param millis the interval in milliseconds
   * @throws IllegalArgumentException if millis &lt;= 0
   */
  public static void setInterval(long millis) throws IllegalArgumentException {
    if(millis > 0)
      interval = millis;
    else
      throw new IllegalArgumentException("interval too small");
  }

  /**
   * Retrieves the interval between two checks of the filesystem.
   * 
   * @return the interval in milliseconds
   */
  public static long getInterval() {
    return interval;
  }

  /**
   * The pause between two checks of a directory, specified in milliseconds
   */
  private static long interval = 500;

  /**
   * This is a Map&lt;String, boolean[]> for all monitored directories. The
   * String is the cannocialPath of the directory, the boolean array contains
   * one element. If the element is set to true, this indicates a stop request
   * for the appropriate monitoring thread.
   */
  private Map<String, boolean[]> monitoredDirs;

  /**
   * Constructs a DirectoryMonitor singleton
   */
  private DirectoryMonitor() {
    monitorgroup = new ThreadGroup("DirectoryMonitor");
    monitoredDirs = Collections.synchronizedMap(new HashMap<String, boolean[]>());


  }

  /**
   * Adds a new monitoring thread for a given cannocial path if there is not one
   * already.
   */
  private void addMonitoringThread(String path, File dir) {
    // check if there already is a thread monitoring the directory
    boolean stopper[];
    synchronized(monitoredDirs) {
      stopper = (boolean[])monitoredDirs.get(path);
      if(stopper != null && !stopper[0])
        return;

      stopper = new boolean[1];
      monitoredDirs.put(path, stopper);
    }
    Thread t = new Thread(new Worker(dir, stopper));
    t.setDaemon(true);
    t.start();
  }

  /**
   * Shuts down a DirectoryMonitor service. The shutdown requests all running
   * threads to end themselves.
   */
  public void shutdown() {
    synchronized(monitoredDirs) {
      for(Iterator i = monitoredDirs.values().iterator(); i.hasNext();)
        ((boolean[])i.next())[0] = true;
    }
  }


  // Generated by mcc
  protected class __EmitStub__ implements IDirectoryMonitor.IDirectoryModification
  {
    public void fileAdded(File p0, File p1) // IDirectoryMonitor.IDirectoryModification
    {
      Object[] a=org.mundo.rt.Signal.getTargets(IDirectoryMonitor.IDirectoryModification.class, DirectoryMonitor.this);
      if (a==null) return;
      for (int i=0; i<a.length; i++)
      {
        try
        {
          ((IDirectoryMonitor.IDirectoryModification)a[i]).fileAdded(p0, p1);
        }
        catch(Exception x)
        {
          org.mundo.rt.Logger.global.exception(x);
        }
      }
    }
    public void fileRemoved(File p0, File p1) // IDirectoryMonitor.IDirectoryModification
    {
      Object[] a=org.mundo.rt.Signal.getTargets(IDirectoryMonitor.IDirectoryModification.class, DirectoryMonitor.this);
      if (a==null) return;
      for (int i=0; i<a.length; i++)
      {
        try
        {
          ((IDirectoryMonitor.IDirectoryModification)a[i]).fileRemoved(p0, p1);
        }
        catch(Exception x)
        {
          org.mundo.rt.Logger.global.exception(x);
        }
      }
    }
    public void fileModified(File p0, File p1) // IDirectoryMonitor.IDirectoryModification
    {
      Object[] a=org.mundo.rt.Signal.getTargets(IDirectoryMonitor.IDirectoryModification.class, DirectoryMonitor.this);
      if (a==null) return;
      for (int i=0; i<a.length; i++)
      {
        try
        {
          ((IDirectoryMonitor.IDirectoryModification)a[i]).fileModified(p0, p1);
        }
        catch(Exception x)
        {
          org.mundo.rt.Logger.global.exception(x);
        }
      }
    }
  }
  private __EmitStub__ emit=new __EmitStub__();
  public boolean isEmitting(Class signal)
  {
    if (IDirectoryMonitor.IDirectoryModification.class.isAssignableFrom(signal)) return true;
    return false;
  }
}

