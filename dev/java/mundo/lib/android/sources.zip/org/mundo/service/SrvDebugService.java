package org.mundo.service;


/**
 * Automatically generated server stub for <code>DebugService</code>
 * @see org.mundo.service.DebugService
 */
public class SrvDebugService extends org.mundo.rt.ServerStub
{
  public SrvDebugService()
  {
  }
  private static org.mundo.rt.ServerStub _obj;
  public static org.mundo.rt.ServerStub _getObject()
  {
    if (_obj==null)
    {
      _obj=new SrvDebugService();
    }
    return _obj;
  }
  public void invoke(Object o, org.mundo.rt.TypedMap m, org.mundo.rt.TypedMap r)
  {
    String n=m.getString("request");
    DebugService p=(DebugService)o;
    try
    {
      if (n.equals("getNodeInfo") && m.getString("ptypes").equals(""))
      {
        r.putObject("value", p.getNodeInfo());
        return;
      }
      if (n.equals("getConnections") && m.getString("ptypes").equals(""))
      {
        r.putObject("value", p.getConnections());
        return;
      }
      if (n.equals("getServices") && m.getString("ptypes").equals(""))
      {
        r.putObject("value", p.getServices());
        return;
      }
      if (n.equals("getServiceInfo") && m.getString("ptypes").equals("g"))
      {
        r.putObject("value", p.getServiceInfo((org.mundo.rt.GUID)m.getObject("p0")));
        return;
      }
      if (n.equals("getERSImports") && m.getString("ptypes").equals(""))
      {
        r.putObject("value", p.getERSImports());
        return;
      }
      if (n.equals("getERSExports") && m.getString("ptypes").equals(""))
      {
        r.putObject("value", p.getERSExports());
        return;
      }
      if (n.equals("getLogMessages") && m.getString("ptypes").equals(""))
      {
        r.putObject("value", p.getLogMessages());
        return;
      }
      if (n.equals("shutdownNode") && m.getString("ptypes").equals(""))
      {
        p.shutdownNode();
        return;
      }
      if (n.equals("getNodeConfig") && m.getString("ptypes").equals(""))
      {
        r.putObject("value", p.getNodeConfig());
        return;
      }
      if (n.equals("crippleBlockSendsTo") && m.getString("ptypes").equals("g"))
      {
        r.putBoolean("value", p.crippleBlockSendsTo((org.mundo.rt.GUID)m.getObject("p0")));
        return;
      }
      if (n.equals("_getMethods") && m.getString("ptypes").equals(""))
      {
        r.putString("value",
        "org.mundo.service.DebugService$NodeInfo getNodeInfo()\n"+
        "java.util.List getConnections()\n"+
        "java.util.List getServices()\n"+
        "org.mundo.service.DebugService$ServiceEntry getServiceInfo(g)\n"+
        "java.util.List getERSImports()\n"+
        "java.util.List getERSExports()\n"+
        "java.util.List getLogMessages()\n"+
        "v shutdownNode()\n"+
        "org.mundo.rt.TypedMap getNodeConfig()\n"+
        "t crippleBlockSendsTo(g)\n"+
        "");
        return;
      }
    }
    catch(Exception x)
    {
      exceptionOccured(x, o, m, r);
    }
  }
}