/*
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is MundoCore Java.
 *
 * The Initial Developer of the Original Code is Telecooperation Group,
 * Department of Computer Science, Darmstadt University of Technology.
 * Portions created by the Initial Developer are
 * Copyright (C) 2001-2008 the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 * Erwin Aitenbichler
 */

package org.mundo.xml.xquery;

import java.io.StringReader;
import java.io.StreamTokenizer;
import java.io.IOException;
import java.util.HashMap;

import org.mundo.filter.AttributeFilter;
import org.mundo.filter.TypedMapFilter;

/**
 * Parses XQuery.
 * @author Erwin Aitenbichler
 */
public class XQuery
{
  public XQuery()
  {
    vars.put("msg", new XQVar("msg", new XQDocMessage()));
  }
  public XQVar getVar(String v)
  {
    return (XQVar)vars.get(v);
  }
  public XQQuery getAST()
  {
    return ast;
  }
  public void parse(String s) throws SyntaxException
  {
    ast=new XQQuery();
    try
    {
      // FIXME: StreamTokenizer is broken. Come up with something better.
      st=new StreamTokenizer(new StringReader(s));
      st.ordinaryChar('/');
      st.ordinaryChar('.');
      // FIXME: I would like to define 0..9 as word chars, but StreamTokenizer
      // does not support this.
      st.ordinaryChars('0', '9');

      st.nextToken();
      while (st.ttype!=st.TT_EOF)
      {
        if (st.ttype==st.TT_WORD)
        {
          if ("for".equals(st.sval))
            ast.fors=parseFor();
          else if ("where".equals(st.sval))
            ast.cond=parseWhere();
          else if ("return".equals(st.sval))
            ast.ret=parseReturn();
          else
            throw new SyntaxException("unexpected word "+st.sval);
        }
        else
          throw new SyntaxException("unexpected token "+(char)st.ttype);
      }
//      System.out.println(vars);
    }
    catch(IOException x)
    {
      throw new SyntaxException("I/O error", x);
    }
  }
  private XQFor parseFor() throws SyntaxException, IOException
  {
    XQFor root=new XQFor();
    XQFor f=root;
    for(;;)
    {
      st.nextToken();
      f.var=new XQVar(parseVar());
      vars.put(f.var.name, f.var);
      if (st.ttype!=st.TT_WORD || !"in".equals(st.sval))
        throw new SyntaxException("'in' expected");
      st.nextToken();
      f.path=parsePath();
      if (st.ttype==',')
      {
        f.next=new XQFor();
        f=f.next;
      }
      else
        break;
    }
    return root;
  }
  private String parseVar() throws SyntaxException, IOException
  {
    if (st.ttype!='$')
      throw new SyntaxException("variable expected");
    st.nextToken();
    if (st.ttype!=st.TT_WORD)
      throw new SyntaxException("variable name expected");
    String name=st.sval;
    st.nextToken();
    return name;
  }
  private XQObject parseStep() throws SyntaxException, IOException
  {
    if (st.ttype=='$')
    {
      String varName=parseVar();
      XQVar var = (XQVar)vars.get(varName);
      if (var==null)
        throw new SyntaxException("undefined variable "+varName);
      return var;
    }
    if (st.ttype==st.TT_WORD)
    {
      String word=st.sval;
      st.nextToken();
      // FIXME: remove this hack after replacing this lousy StreamTokenizer class
      while (st.ttype>='0' && st.ttype<='9')
      {
        word=word+(char)st.ttype;
        st.nextToken();
      }
      
      if (st.ttype=='(')
      {
        st.nextToken();
        XQFunction fn=new XQFunction(word);
        if (st.ttype!=')')
        {
          for(;;)
          {
            fn.addParam(parsePath());
            if (st.ttype==',')
              st.nextToken();
            else
              break;
          }
        }
        if (st.ttype!=')')
          throw new SyntaxException(") expected");
        st.nextToken();
        return fn;
      }
      return new XQNode(word);
    }
    if (st.ttype>='0' && st.ttype<='9' || st.ttype=='.')
    {
      long v=0;
      while (st.ttype>='0' && st.ttype<='9')
      {
        v=v*10+(st.ttype-'0');
        st.nextToken();
      }
      if (st.ttype!='.')
        return new XQLongLiteral(v);
      st.nextToken();
      double dv=v;
      double f=1.0;
      while (st.ttype>='0' && st.ttype<='9')
      {
        f/=10.0;
        dv+=f*(st.ttype-'0');
        st.nextToken();
      }
      return new XQDoubleLiteral(dv);
    }
    if (st.ttype=='\"' || st.ttype=='\'')
    {
      XQObject obj=new XQStringLiteral(st.sval);
      st.nextToken();
      return obj;
    }
    throw new SyntaxException("variable or word expected, but found ttype "+st.ttype);
  }
  private XQPathExpr parsePath() throws SyntaxException, IOException
  {
    XQPathExpr root=new XQPathExpr(parseStep());
    XQPathExpr path=root;
    while (st.ttype=='/')
    {
      st.nextToken();
      path.next=new XQPathExpr(parseStep());
      path=path.next;
    }
    return root;
  }
  private XQObject parseWhere() throws SyntaxException, IOException
  {
    st.nextToken();
    return parseOrExpr();
  }
  private XQObject parseOrExpr() throws SyntaxException, IOException
  {
    XQObject obj=parseAndExpr();
    if (st.ttype==st.TT_WORD && "or".equals(st.sval))
    {
      st.nextToken();
      obj=new XQOr(obj, parseOrExpr());
    }
    return obj;
  }
  private XQObject parseAndExpr() throws SyntaxException, IOException
  {
    XQObject obj=parseComparisonExpr();
    if (st.ttype==st.TT_WORD && "and".equals(st.sval))
    {
      st.nextToken();
      obj=new XQAnd(obj, parseAndExpr());
    }
    return obj;
  }
  private XQComparisonExpr parseComparisonExpr() throws SyntaxException, IOException
  {
    XQComparisonExpr ce=new XQComparisonExpr();
    ce.left=parsePath();
    int op=parseGeneralComp();
    if (op>0)
    {
      ce.op=op;
      ce.right=parsePath();
    }
    return ce;
  }
  private int parseGeneralComp() throws SyntaxException, IOException
  {
    if (st.ttype=='=')
    {
      st.nextToken();
      if (st.ttype=='=')
        st.nextToken();
      return AttributeFilter.OP_EQUAL;
    }
    if (st.ttype=='!')
    {
      st.nextToken();
      if (st.ttype!='=')
        throw new SyntaxException("error parsing != operator");
      st.nextToken();
      return AttributeFilter.OP_NOT_EQUAL;
    }
    if (st.ttype=='<')
    {
      st.nextToken();
      if (st.ttype=='=')
      {
        st.nextToken();
        return AttributeFilter.OP_LESS_EQUAL;
      }
      return AttributeFilter.OP_LESS;
    }
    if (st.ttype=='>')
    {
      st.nextToken();
      if (st.ttype=='=')
      {
        st.nextToken();
        return AttributeFilter.OP_GREATER_EQUAL;
      }
      return AttributeFilter.OP_GREATER;
    }
    return 0;
  }
  private XQReturn parseReturn() throws SyntaxException, IOException
  {
    st.nextToken();
    return new XQReturn(parsePath());
  }
  public TypedMapFilter getMapFilter() throws BuildException
  {
    XQMapBuilder builder=new XQMapBuilder();
    ast.buildMapFilter(builder);
    return builder.mf;
  }
  void buildPlan(XEPlanBuilder ctx) throws BuildException
  {
    ast.buildPlan(ctx);
  }
  public void buildPlan() throws BuildException
  {
    XEPlanBuilder ctx=new XEPlanBuilder();
    ast.buildPlan(ctx);
    System.out.println(ctx.plan);
  }
  
  /**
   * Indicates a syntax error while parsing the query expression.
   */
  public static class SyntaxException extends Exception
  {
    SyntaxException(String s)
    {
      super(s);
    }
    SyntaxException(String s, Throwable t)
    {
      super(s, t);
    }
  }

  /**
   * Indicates an error during building an execution plan for a query.
   */  
  public static class BuildException extends Exception
  {
    BuildException(String s)
    {
      super(s);
    }
    BuildException(String s, Throwable t)
    {
      super(s, t);
    }
  }
  
  private StreamTokenizer st;
  private HashMap<String,XQVar> vars = new HashMap<String,XQVar>();


  private XQQuery ast;
}
