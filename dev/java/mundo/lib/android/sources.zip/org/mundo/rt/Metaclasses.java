package org.mundo.rt;

class Metaclasses
{
  static void init()
  {
    org.mundo.rt.ClassWrapper.register(org.mundo.service.DebugService.LogEntry.class, "DebugService.LogEntry");
    org.mundo.rt.ClassWrapper.register(org.mundo.service.DebugService.PublisherEntry.class, "DebugService.PublisherEntry");
    org.mundo.rt.ClassWrapper.register(org.mundo.net.ProtocolCoordinator.Options.class, "ProtocolCoordinator$Options");
    org.mundo.rt.ClassWrapper.register(org.mundo.service.DebugService.ERSExportEntry.class, "DebugService.ERSExportEntry");
    org.mundo.rt.ClassWrapper.register(org.mundo.net.transport.ip.IPTransportService.Options.class, "IPTransportService$Options");
    org.mundo.rt.ClassWrapper.register(org.mundo.net.transport.ip.IPTransportService.OptBroadcast.class, "IPTransportService$OptBroadcast");
    org.mundo.rt.ClassWrapper.register(org.mundo.net.broker.P2PTopicBroker.Options.class, "P2PTopicBroker$Options");
    org.mundo.rt.ClassWrapper.register(org.mundo.net.transport.ip.IPTransportService.OptHost.class, "IPTransportService$OptHost");
    org.mundo.rt.ClassWrapper.register(org.mundo.net.transport.ip.IPTransportService.OptMulticast.class, "IPTransportService$OptMulticast");
    org.mundo.rt.ClassWrapper.register(org.mundo.service.DebugService.ERSImportEntry.class, "DebugService.ERSImportEntry");
    org.mundo.rt.ClassWrapper.register(org.mundo.service.DebugService.SubscriberEntry.class, "DebugService.SubscriberEntry");
    org.mundo.rt.ClassWrapper.register(org.mundo.net.transport.ip.IPTransportService.OptDiscovery.class, "IPTransportService$OptDiscovery");
    org.mundo.rt.ClassWrapper.register(org.mundo.service.ServiceManager.OptServiceManager.class, "ServiceManager$Options");
    org.mundo.rt.ClassWrapper.register(org.mundo.service.DebugService.ConnEntry.class, "DebugService.ConnEntry");
    org.mundo.rt.ClassWrapper.register(org.mundo.service.ServiceManager.OptNewInstance.class, "ServiceManager$OptNewInstance");
    org.mundo.rt.ClassWrapper.register(org.mundo.net.transport.ip.IPTransportService.OptNet.class, "IPTransportService$OptNet");
    org.mundo.rt.ClassWrapper.register(org.mundo.service.ServiceManager.OptRegisterClass.class, "ServiceManager$OptRegisterClass");
    org.mundo.rt.ClassWrapper.register(org.mundo.service.DebugService.NetInterface.class, "DebugService.NetInterface");
    org.mundo.rt.ClassWrapper.register(org.mundo.service.DebugService.ServiceEntry.class, "DebugService.ServiceEntry");
    org.mundo.rt.ClassWrapper.register(org.mundo.service.DebugService.NodeInfo.class, "DebugService.NodeInfo");
  }
}