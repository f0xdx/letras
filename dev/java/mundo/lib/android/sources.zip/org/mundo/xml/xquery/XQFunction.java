/*
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is MundoCore Java.
 *
 * The Initial Developer of the Original Code is Telecooperation Group,
 * Department of Computer Science, Darmstadt University of Technology.
 * Portions created by the Initial Developer are
 * Copyright (C) 2001-2008 the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 * Erwin Aitenbichler
 */

package org.mundo.xml.xquery;

import java.util.ArrayList;
import java.util.Iterator;

import org.mundo.filter.AttributeFilter;
import org.mundo.filter.TypedMapFilter;

/**
 * function
 */
public class XQFunction extends XQObject
{
  XQFunction(String n)
  {
    name=n;
  }
  void addParam(XQObject obj)
  {
    params.add(obj);
  }
  void buildMapFilter(XQMapBuilder ctx) throws XQuery.BuildException
  {
    int op=0;
    if ("contains".equals(name))
      op=AttributeFilter.OP_CONTAINS;
    else if ("starts-with".equals(name))
      op=AttributeFilter.OP_STARTS;
    else if ("ends-with".equals(name))
      op=AttributeFilter.OP_ENDS;
    if (op==0)
      throw new XQuery.BuildException("unsupported function "+name);

    ArrayList<XQNode> nodes = ctx.expandPath((XQPathExpr)params.get(0));


    TypedMapFilter mf=ctx.mf;
    int i, s=nodes.size()-1;
    for (i=0; i<s; i++)
      mf=ctx.getOrCreateMap(mf, ((XQNode)nodes.get(i)).name);
    mf.putString(((XQNode)nodes.get(s)).name, op, toStringValue((XQObject)params.get(1)));
  }
  void buildMapFilter(XQMapBuilder builder, TypedMapFilter mf, String key, int op) throws XQuery.BuildException
  {
    boolean value;
    if ("true".equals(name))
      value=true;
    else if ("false".equals(name))
      value=false;
    else
      throw new XQuery.BuildException("function must be true() or false() in boolean comparison");
    mf.putBoolean(key, op, value);
  }
  void buildPlan(XEPlanBuilder ctx) throws XQuery.BuildException
  {
    if ("doc".equals(name))
      ctx.document(toStringValue((XQObject)params.get(0)));
  }
  public String toString()
  {
    StringBuffer sb=new StringBuffer();
    sb.append(name);
    sb.append("(");
    boolean comma=false;
    for (XQObject obj : params)
    {




      if (comma)
        sb.append(", ");
      else 
        comma=true;
      sb.append(obj.toString());
    }
    return sb.toString();
  }
  private String toStringValue(XQObject obj)
  {
    if (obj instanceof XQPathExpr)
      obj=((XQPathExpr)obj).step;
    return ((XQStringLiteral)obj).value;
  }
  public String name;
  public ArrayList<XQObject> params = new ArrayList<XQObject>();


}
