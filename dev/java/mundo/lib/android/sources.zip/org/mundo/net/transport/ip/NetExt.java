/*
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is MundoCore Java.
 *
 * The Initial Developer of the Original Code is Telecooperation Group,
 * Department of Computer Science, Darmstadt University of Technology.
 * Portions created by the Initial Developer are
 * Copyright (C) 2001-2008 the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 * Erwin Aitenbichler
 */

package org.mundo.net.transport.ip;

import java.net.SocketException;
import java.net.DatagramSocket;

import org.mundo.rt.Logger;



/**
 * Native socket API extensions.
 */
public class NetExt
{
  /**
   * Enable/disable the SO_REUSEPORT, or alternatively, the SO_REUSEADDR socket option.
   * For UDP sockets it may be necessary to bind more than one socket to the same socket
   * address and port. This is typically for the purpose of receiving broadcast packets.
   * This option must be enabled prior to binding the socket.
   * @param sock  the socket.
   * @param reuse  whether to enable or disable this option.
   * @throws SocketException  if an error occurs enabling or disabling the SO_REUSEPORT
   *         socket option, or the socket is closed.
   */
  public static void setReusePort(DatagramSocket sock, boolean reuse) throws SocketException
  {
    boolean success = false;
    if ("Mac OS X".equals(System.getProperty("os.name")))
    {
      try
      {
        if (impl==null)
          impl = new NetExtImpl();
        impl.setReusePort(sock, reuse);
        log.finest("setReusePort succeeded");
        success = true;
      }
      catch(java.lang.UnsatisfiedLinkError e)
      {
        log.warning("Native MundoCore extension library could not be loaded!");
        log.warning(e.toString());
      }
      catch(java.lang.NoClassDefFoundError e)
      {
        log.warning("Native MundoCore extension library could not be loaded!");
        log.warning(e.toString());
      }
      catch(Exception x)
      {
        log.exception(x);
      }
    }
    if (!success)
    {
      sock.setReuseAddress(reuse);
      log.finest("setReuseAddress succeeded");
    }
  }
  
  public static NetExtImpl impl;
  private static Logger log = Logger.getLogger("netext");
}
