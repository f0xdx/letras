/*
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is MundoCore Java.
 *
 * The Initial Developer of the Original Code is Telecooperation Group,
 * Department of Computer Science, Darmstadt University of Technology.
 * Portions created by the Initial Developer are
 * Copyright (C) 2001-2008 the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 * Erwin Aitenbichler
 */

package org.mundo.rt;

import java.util.NoSuchElementException;



import java.util.HashMap;
import java.util.Set;
import java.util.Collection;
import java.util.Map;
import java.util.Iterator;
import java.util.ArrayList;

/** 
 * <p>An <code>ActiveMap</code> holds an object tree in an active form.
 * Active object trees hold arbitrary object types. Because the actual objects
 * are instantiated, the code associated with these objects is also loaded and
 * runnable.</p>
 *
 * <p><b>CLDC:</b> Floating point types and JavaXDR are not available in this
 * configuration.</p>
 *
 * @author Erwin Aitenbichler
 */



public class ActiveMap extends TypedContainer implements IActivate, Cloneable, ICopy, Map
<String, Object>
{
  /**
   * Creates a new, empty ActiveMap
   */
  public ActiveMap()
  {
  }

  /**
   * Constructs a new @code{ActiveMap} with the same mappings as the specified Map.
   */
  public ActiveMap(Map<? extends String, ? extends Object> m)


  {
    putAll(m);
  }






  
  /**
   * Creates a shallow copy of this map.
   * @return  a shallow copy of this map.
   */
  public ActiveMap clone()


  {
    ActiveMap map = new ActiveMap();
    map.ht = ht;
    map.deepenClone();
    return map;
  }
   
  /**
   * Clones mutable aggregated objects.
   */
  private void deepenClone()
  {








    ht=new HashMap<String,Object>(ht);


  }

  /**
   * Creates a deep copy of this map. All value objects that are mutable must
   * implement the <code>ICopy</code> interface. Failing to do so will lead
   * to an incomplete copy.
   * @return  a deep copy of this map.
   */
  public ActiveMap copy() //ICopy


  {
    ActiveMap map = new ActiveMap();
    map.ht = ht;
    map.deepenCopy();
    return map;
  }
  
  /**
   * Copies all aggregated objects.
   */
  private void deepenCopy()
  {








    HashMap<String,Object> src = ht;
    ht = new HashMap<String,Object>();
    for (Map.Entry<String,Object> e : src.entrySet())
    {
      ht.put(e.getKey(), deepCopy(e.getValue()));
    }








  }

  /**
   * Creates a deep copy of the specified object.
   */
  private Object deepCopy(Object obj)
  {
    if (obj instanceof ICopy)
      return ((ICopy)obj).copy();
    return obj;
  }
  
  /**
   * Associates the specified value with the specified key in this map.
   * If the map previously contained a mapping for this key, the old mapping is replaced
   * regardless of the previous type.
   * The value is internally stored using the <code>Byte</code> wrapper class.
   * @param key    key with which the specified value is to be associated.
   * @param value  value to be associated with the specified key.
   */
  public void putByte(String key, byte value)
  {
    put(key, new Byte(value));
  }
  /**
   * Returns the value to which the specified key is mapped.
   * @param key  the key whose associated value is to be returned.
   * @return     the value to which this map maps the specified key.
   * @throws NoSuchElementException  if there is no mapping for the specified key.
   * @throws NullPointerException    if the specified key is mapped to <code>null</code>.
   *   This exception can only happen in case of a type mismatch, i.e. the specified
   *   key has not previously been mapped by the <code>putByte</code> method.
   * @throws ClassCastException      if the specified key is not mapped to a <code>Byte</code>.
   *   This exception can only happen in case of a type mismatch, i.e. the specified
   *   key has not previously been mapped by the <code>putByte</code> method.
   */
  public byte getByte(String key)
  {
    return ((Byte)getWrapper(key)).byteValue(); 
  }
  /**
   * Returns the value to which the specified key is mapped. In case of any
   * error, <code>defaultValue</code> is returned.
   * @param key  the key whose associated value is to be returned.
   * @param defaultValue  the value to be returned if there is no or no valid
   *   mapping for the specified key.
   * @return     the value to which this map maps the specified key.
   */
  public byte getByte(String key, byte defaultValue)
  {
    try {
      return getByte(key);
    } catch (Exception x) {}
    return defaultValue;
  }

  /**
   * Associates the specified value with the specified key in this map.
   * If the map previously contained a mapping for this key, the old mapping is replaced
   * regardless of the previous type.
   * The value is internally stored using the non-standard <code>UnsignedByte</code> wrapper class.
   * @param key    key with which the specified value is to be associated.
   * @param value  value to be associated with the specified key.
   */
  public void putUByte(String key, short value)
  {
    put(key, new UnsignedByte(value));
  }
  /**
   * Returns the value to which the specified key is mapped.
   * @param key  the key whose associated value is to be returned.
   * @return     the value to which this map maps the specified key.
   * @throws NoSuchElementException  if there is no mapping for the specified key.
   * @throws NullPointerException    if the specified key is mapped to <code>null</code>.
   *   This exception can only happen in case of a type mismatch, i.e. the specified
   *   key has not previously been mapped by the <code>putUByte</code> method.
   * @throws ClassCastException      if the specified key is not mapped to a <code>UnsignedByte</code>.
   *   This exception can only happen in case of a type mismatch, i.e. the specified
   *   key has not previously been mapped by the <code>putUByte</code> method.
   */
  public short getUByte(String key)
  {
    return ((UnsignedByte)getWrapper(key)).shortValue();
  }
  /**
   * Returns the value to which the specified key is mapped. In case of any
   * error, <code>defaultValue</code> is returned.
   * @param key  the key whose associated value is to be returned.
   * @param defaultValue  the value to be returned if there is no or no valid
   *   mapping for the specified key.
   * @return     the value to which this map maps the specified key.
   */
  public short getUByte(String key, short defaultValue)
  {
    try {
      return getUByte(key);
    } catch (Exception x) {}
    return defaultValue;
  }

  /**
   * Associates the specified value with the specified key in this map.
   * If the map previously contained a mapping for this key, the old mapping is replaced
   * regardless of the previous type.
   * The value is internally stored using the <code>Short</code> wrapper class.
   * @param key    key with which the specified value is to be associated.
   * @param value  value to be associated with the specified key.
   */
  public void putShort(String key, short value)
  {
    put(key, new Short(value));
  }
  /**
   * Returns the value to which the specified key is mapped.
   * @param key  the key whose associated value is to be returned.
   * @return     the value to which this map maps the specified key.
   * @throws NoSuchElementException  if there is no mapping for the specified key.
   * @throws NullPointerException    if the specified key is mapped to <code>null</code>.
   *   This exception can only happen in case of a type mismatch, i.e. the specified
   *   key has not previously been mapped by the <code>putShort</code> method.
   * @throws ClassCastException      if the specified key is not mapped to a <code>Short</code>.
   *   This exception can only happen in case of a type mismatch, i.e. the specified
   *   key has not previously been mapped by the <code>putShort</code> method.
   */
  public short getShort(String key)
  {
    return ((Short)getWrapper(key)).shortValue();
  }
  /**
   * Returns the value to which the specified key is mapped. In case of any
   * error, <code>defaultValue</code> is returned.
   * @param key  the key whose associated value is to be returned.
   * @param defaultValue  the value to be returned if there is no or no valid
   *   mapping for the specified key.
   * @return     the value to which this map maps the specified key.
   */
  public short getShort(String key, short defaultValue)
  {
    try {
      return getShort(key);
    } catch (Exception x) {}
    return defaultValue;
  }

  /**
   * Associates the specified value with the specified key in this map.
   * If the map previously contained a mapping for this key, the old mapping is replaced
   * regardless of the previous type.
   * The value is internally stored using the non-standard <code>UnsignedShort</code> wrapper class.
   * @param key    key with which the specified value is to be associated.
   * @param value  value to be associated with the specified key.
   */
  public void putUShort(String key, int value)
  {
    put(key, new UnsignedShort(value));
  }
  /**
   * Returns the value to which the specified key is mapped.
   * @param key  the key whose associated value is to be returned.
   * @return     the value to which this map maps the specified key.
   * @throws NoSuchElementException  if there is no mapping for the specified key.
   * @throws NullPointerException    if the specified key is mapped to <code>null</code>.
   *   This exception can only happen in case of a type mismatch, i.e. the specified
   *   key has not previously been mapped by the <code>putUShort</code> method.
   * @throws ClassCastException      if the specified key is not mapped to a <code>UnsignedShort</code>.
   *   This exception can only happen in case of a type mismatch, i.e. the specified
   *   key has not previously been mapped by the <code>putUShort</code> method.
   */
  public int getUShort(String key)
  {
    return ((UnsignedShort)getWrapper(key)).intValue();
  }
  /**
   * Returns the value to which the specified key is mapped. In case of any
   * error, <code>defaultValue</code> is returned.
   * @param key  the key whose associated value is to be returned.
   * @param defaultValue  the value to be returned if there is no or no valid
   *   mapping for the specified key.
   * @return     the value to which this map maps the specified key.
   */
  public int getUShort(String key, int defaultValue)
  {
    try {
      return getUShort(key);
    } catch (Exception x) {}
    return defaultValue;
  }

  /**
   * Associates the specified value with the specified key in this map.
   * If the map previously contained a mapping for this key, the old mapping is replaced
   * regardless of the previous type.
   * The value is internally stored using the <code>Integer</code> wrapper class.
   * @param key    key with which the specified value is to be associated.
   * @param value  value to be associated with the specified key.
   */
  public void putInt(String key, int value)
  {
    put(key, new Integer(value));
  }
  /**
   * Returns the value to which the specified key is mapped.
   * @param key  the key whose associated value is to be returned.
   * @return     the value to which this map maps the specified key.
   * @throws NoSuchElementException  if there is no mapping for the specified key.
   * @throws NullPointerException    if the specified key is mapped to <code>null</code>.
   *   This exception can only happen in case of a type mismatch, i.e. the specified
   *   key has not previously been mapped by the <code>putInt</code> method.
   * @throws ClassCastException      if the specified key is not mapped to an <code>Integer</code>.
   *   This exception can only happen in case of a type mismatch, i.e. the specified
   *   key has not previously been mapped by the <code>putInt</code> method.
   */
  public int getInt(String key)
  {
    Integer i = (Integer)get(key);
    if (i==null)
      throw new NoSuchElementException("int '"+key+"' not found");
    return i.intValue();
  }
  /**
   * Returns the value to which the specified key is mapped. In case of any
   * error, <code>defaultValue</code> is returned.
   * @param key  the key whose associated value is to be returned.
   * @param defaultValue  the value to be returned if there is no or no valid
   *   mapping for the specified key.
   * @return     the value to which this map maps the specified key.
   */
  public int getInt(String key, int defaultValue)
  {
    Integer i = (Integer)get(key);
    if (i==null)
      return defaultValue;
    return i.intValue();
  }

  /**
   * Associates the specified value with the specified key in this map.
   * If the map previously contained a mapping for this key, the old mapping is replaced
   * regardless of the previous type.
   * The value is internally stored using the non-standard <code>UnsignedInteger</code> wrapper class.
   * @param key    key with which the specified value is to be associated.
   * @param value  value to be associated with the specified key.
   */
  public void putUInt(String key, long value)
  {
    put(key, new UnsignedInteger(value));
  }
  /**
   * Returns the value to which the specified key is mapped.
   * @param key  the key whose associated value is to be returned.
   * @return     the value to which this map maps the specified key.
   * @throws NoSuchElementException  if there is no mapping for the specified key.
   * @throws NullPointerException    if the specified key is mapped to <code>null</code>.
   *   This exception can only happen in case of a type mismatch, i.e. the specified
   *   key has not previously been mapped by the <code>putUInt</code> method.
   * @throws ClassCastException      if the specified key is not mapped to a <code>UnsignedInteger</code>.
   *   This exception can only happen in case of a type mismatch, i.e. the specified
   *   key has not previously been mapped by the <code>putUInt</code> method.
   */
  public long getUInt(String key)
  {
    return ((UnsignedInteger)getWrapper(key)).longValue();
  }
  /**
   * Returns the value to which the specified key is mapped. In case of any
   * error, <code>defaultValue</code> is returned.
   * @param key  the key whose associated value is to be returned.
   * @param defaultValue  the value to be returned if there is no or no valid
   *   mapping for the specified key.
   * @return     the value to which this map maps the specified key.
   */
  public long getUInt(String key, long defaultValue)
  {
    try {
      return getUInt(key);
    } catch (Exception x) {}
    return defaultValue;
  }

  /**
   * Associates the specified value with the specified key in this map.
   * If the map previously contained a mapping for this key, the old mapping is replaced
   * regardless of the previous type.
   * The value is internally stored using the <code>Long</code> wrapper class.
   * @param key    key with which the specified value is to be associated.
   * @param value  value to be associated with the specified key.
   */
  public void putLong(String key, long value)
  {
    put(key, new Long(value));
  }
  /**
   * Returns the value to which the specified key is mapped.
   * @param key  the key whose associated value is to be returned.
   * @return     the value to which this map maps the specified key.
   * @throws NoSuchElementException  if there is no mapping for the specified key.
   * @throws NullPointerException    if the specified key is mapped to <code>null</code>.
   *   This exception can only happen in case of a type mismatch, i.e. the specified
   *   key has not previously been mapped by the <code>putLong</code> method.
   * @throws ClassCastException      if the specified key is not mapped to a <code>Long</code>.
   *   This exception can only happen in case of a type mismatch, i.e. the specified
   *   key has not previously been mapped by the <code>putLong</code> method.
   */
  public long getLong(String key)
  {










    Number n=(Number)getWrapper(key);
    if (n instanceof Long ||
        n instanceof Integer ||
        n instanceof Short ||
        n instanceof Byte ||
        n instanceof UnsignedLong ||
        n instanceof UnsignedInteger ||
        n instanceof UnsignedShort ||
        n instanceof UnsignedByte)
      return n.longValue();
    throw new ClassCastException();
  }
  /**
   * Returns the value to which the specified key is mapped. In case of any
   * error, <code>defaultValue</code> is returned.
   * @param key  the key whose associated value is to be returned.
   * @param defaultValue  the value to be returned if there is no or no valid
   *   mapping for the specified key.
   * @return     the value to which this map maps the specified key.
   */
  public long getLong(String key, long defaultValue)
  {
    try {
      return getLong(key);
    } catch (Exception x) {}
    return defaultValue;
  }

  /**
   * Associates the specified value with the specified key in this map.
   * If the map previously contained a mapping for this key, the old mapping is replaced
   * regardless of the previous type.
   * The value is internally stored using the non-standard <code>UnsignedLong</code> wrapper class.
   * FIXME: values >= 2^63 are not handled correctly.
   * @param key    key with which the specified value is to be associated.
   * @param value  value to be associated with the specified key.
   */
  public void putULong(String key, long value)
  {
    put(key, new UnsignedLong(value));
  }
  /**
   * Returns the value to which the specified key is mapped.
   * @param key  the key whose associated value is to be returned.
   * @return     the value to which this map maps the specified key.
   * @throws NoSuchElementException  if there is no mapping for the specified key.
   * @throws NullPointerException    if the specified key is mapped to <code>null</code>.
   *   This exception can only happen in case of a type mismatch, i.e. the specified
   *   key has not previously been mapped by the <code>putULong</code> method.
   * @throws ClassCastException      if the specified key is not mapped to a <code>UnsignedLong</code>.
   *   This exception can only happen in case of a type mismatch, i.e. the specified
   *   key has not previously been mapped by the <code>putULong</code> method.
   */
  public long getULong(String key)
  {
    return ((UnsignedLong)getWrapper(key)).longValue();
  }
  /**
   * Returns the value to which the specified key is mapped. In case of any
   * error, <code>defaultValue</code> is returned.
   * @param key  the key whose associated value is to be returned.
   * @param defaultValue  the value to be returned if there is no or no valid
   *   mapping for the specified key.
   * @return     the value to which this map maps the specified key.
   */
  public long getULong(String key, long defaultValue)
  {
    try {
      return getLong(key);
    } catch (Exception x) {}
    return defaultValue;
  }

  /**
   * Associates the specified value with the specified key in this map.
   * If the map previously contained a mapping for this key, the old mapping is replaced
   * regardless of the previous type.
   * The value is internally stored using the <code>Boolean</code> wrapper class.
   * @param key    key with which the specified value is to be associated.
   * @param value  value to be associated with the specified key.
   */
  public void putBoolean(String key, boolean value)
  {
    put(key, new Boolean(value));
  }
  /**
   * Returns the value to which the specified key is mapped.
   * @param key  the key whose associated value is to be returned.
   * @return     the value to which this map maps the specified key.
   * @throws NoSuchElementException  if there is no mapping for the specified key.
   * @throws NullPointerException    if the specified key is mapped to <code>null</code>.
   *   This exception can only happen in case of a type mismatch, i.e. the specified
   *   key has not previously been mapped by the <code>putBool</code> method.
   * @throws ClassCastException      if the specified key is not mapped to a <code>Boolean</code>.
   *   This exception can only happen in case of a type mismatch, i.e. the specified
   *   key has not previously been mapped by the <code>putBool</code> method.
   */
  public boolean getBoolean(String key)
  {
    return ((Boolean)getWrapper(key)).booleanValue();
  }
  /**
   * Returns the value to which the specified key is mapped. In case of any
   * error, <code>defaultValue</code> is returned.
   * @param key  the key whose associated value is to be returned.
   * @param defaultValue  the value to be returned if there is no or no valid
   *   mapping for the specified key.
   * @return     the value to which this map maps the specified key.
   */
  public boolean getBoolean(String key, boolean defaultValue)
  {
    try {
      return getBoolean(key);
    } catch (Exception x) {}
    return defaultValue;
  }

  /**
   * Associates the specified value with the specified key in this map.
   * If the map previously contained a mapping for this key, the old mapping is replaced
   * regardless of the previous type.
   * The value is internally stored using the <code>Character</code> wrapper class.
   * @param key    key with which the specified value is to be associated.
   * @param value  value to be associated with the specified key.
   */
  public void putChar(String key, char value)
  {
    put(key, new Character(value));
  }
  /**
   * Returns the value to which the specified key is mapped.
   * @param key  the key whose associated value is to be returned.
   * @return     the value to which this map maps the specified key.
   * @throws NoSuchElementException  if there is no mapping for the specified key.
   * @throws NullPointerException    if the specified key is mapped to <code>null</code>.
   *   This exception can only happen in case of a type mismatch, i.e. the specified
   *   key has not previously been mapped by the <code>putChar</code> method.
   * @throws ClassCastException      if the specified key is not mapped to a <code>Character</code>.
   *   This exception can only happen in case of a type mismatch, i.e. the specified
   *   key has not previously been mapped by the <code>putChar</code> method.
   */
  public char getChar(String key)
  {
    return ((Character)getWrapper(key)).charValue();
  }
  /**
   * Returns the value to which the specified key is mapped. In case of any
   * error, <code>defaultValue</code> is returned.
   * @param key  the key whose associated value is to be returned.
   * @param defaultValue  the value to be returned if there is no or no valid
   *   mapping for the specified key.
   * @return     the value to which this map maps the specified key.
   */
  public char getChar(String key, char defaultValue)
  {
    try {
      return getChar(key);
    } catch (Exception x) {}
    return defaultValue;
  }

  // CLDC does not support floating point arithmetic
  /**
   * Associates the specified value with the specified key in this map.
   * If the map previously contained a mapping for this key, the old mapping is replaced
   * regardless of the previous type.
   * The value is internally stored using the <code>Float</code> wrapper class.
   * @param key    key with which the specified value is to be associated.
   * @param value  value to be associated with the specified key.
   */
  public void putFloat(String key, float value)
  {
    put(key, new Float(value));
  }
  /**
   * Returns the value to which the specified key is mapped.
   * @param key  the key whose associated value is to be returned.
   * @return     the value to which this map maps the specified key.
   * @throws NoSuchElementException  if there is no mapping for the specified key.
   * @throws NullPointerException    if the specified key is mapped to <code>null</code>.
   *   This exception can only happen in case of a type mismatch, i.e. the specified
   *   key has not previously been mapped by the <code>putFloat</code> method.
   * @throws ClassCastException      if the specified key is not mapped to a <code>Float</code>.
   *   This exception can only happen in case of a type mismatch, i.e. the specified
   *   key has not previously been mapped by the <code>putFloat</code> method.
   */
  public float getFloat(String key)
  {
    return ((Float)getWrapper(key)).floatValue();
  }
  /**
   * Returns the value to which the specified key is mapped. In case of any
   * error, <code>defaultValue</code> is returned.
   * @param key  the key whose associated value is to be returned.
   * @param defaultValue  the value to be returned if there is no or no valid
   *   mapping for the specified key.
   * @return     the value to which this map maps the specified key.
   */
  public float getFloat(String key, float defaultValue)
  {
    try {
      return getFloat(key);
    } catch (Exception x) {}
    return defaultValue;
  }
  
  /**
   * Associates the specified value with the specified key in this map.
   * If the map previously contained a mapping for this key, the old mapping is replaced
   * regardless of the previous type.
   * The value is internally stored using the <code>Double</code> wrapper class.
   * @param key    key with which the specified value is to be associated.
   * @param value  value to be associated with the specified key.
   */
  public void putDouble(String key, double value)
  {
    put(key, new Double(value));
  }
  /**
   * Returns the value to which the specified key is mapped.
   * @param key  the key whose associated value is to be returned.
   * @return     the value to which this map maps the specified key.
   * @throws NoSuchElementException  if there is no mapping for the specified key.
   * @throws NullPointerException    if the specified key is mapped to <code>null</code>.
   *   This exception can only happen in case of a type mismatch, i.e. the specified
   *   key has not previously been mapped by the <code>putDouble</code> method.
   * @throws ClassCastException      if the specified key is not mapped to a <code>Double</code>.
   *   This exception can only happen in case of a type mismatch, i.e. the specified
   *   key has not previously been mapped by the <code>putDouble</code> method.
   */
  public double getDouble(String key)
  {
    return ((Double)getWrapper(key)).doubleValue();
  }
  /**
   * Returns the value to which the specified key is mapped. In case of any
   * error, <code>defaultValue</code> is returned.
   * @param key  the key whose associated value is to be returned.
   * @param defaultValue  the value to be returned if there is no or no valid
   *   mapping for the specified key.
   * @return     the value to which this map maps the specified key.
   */
  public double getDouble(String key, double defaultValue)
  {
    try {
      return getDouble(key);
    } catch (Exception x) {}
    return defaultValue;
  }
  
  /**
   * Associates the specified value with the specified key in this map.
   * If the map previously contained a mapping for this key, the old mapping is replaced
   * regardless of the previous type.
   * @param key    key with which the specified value is to be associated.
   * @param value  value to be associated with the specified key. May be <code>null</code>.
   */
  public void putString(String key, String value)
  {
    put(key, value);
  }
  /**
   * Returns the value to which the specified key is mapped.
   * @param key  the key whose associated value is to be returned.
   * @return     the value to which this map maps the specified key. The return value
   *   is <code>null</code> if the key has explicitly been mapped so.
   * @throws NoSuchElementException  if there is no mapping for the specified key.
   * @throws ClassCastException      if the specified key is not mapped to a <code>String</code>.
   */
  public String getString(String key)
  {
    String s = (String)get(key);
    if (s==null)
      throw new NoSuchElementException("String '"+key+"' not found");
    return s;
  }
  /**
   * Returns the value to which the specified key is mapped. In case of any
   * error, <code>defaultValue</code> is returned.
   * @param key  the key whose associated value is to be returned.
   * @param defaultValue  the value to be returned if there is no or no valid
   *   mapping for the specified key.
   * @return     the value to which this map maps the specified key.
   */
  public String getString(String key, String defaultValue)
  {
    if (defaultValue == null)
      return (String)get(key);
    try {
      return getString(key);
    } catch (Exception x) {}
    return defaultValue;
  }
  /**
   * Associates the specified value with the specified key in this map.
   * If the map previously contained a mapping for this key, the old mapping is replaced
   * regardless of the previous type.
   * @param key    key with which the specified value is to be associated.
   * @param value  value to be associated with the specified key. May be <code>null</code>.
   */
  public void putGUID(String key, GUID value)
  {
    put(key, value);
  }
  /**
   * Returns the value to which the specified key is mapped.
   * @param key  the key whose associated value is to be returned.
   * @return     the value to which this map maps the specified key. The return value
   *   is <code>null</code> if the key has explicitly been mapped so.
   * @throws NoSuchElementException  if there is no mapping for the specified key.
   * @throws ClassCastException      if the specified key is not mapped to a <code>GUID</code>.
   */
  public GUID getGUID(String key)
  {
    return (GUID)getWrapper(key);
  }

  /**
   * Returns the value to which the specified key is mapped.
   * @param key  the key whose associated value is to be returned.
   * @return     the value to which this map maps the specified key. The return value
   *   is <code>null</code> if the key has explicitly been mapped so.
   * @throws NoSuchElementException  if there is no mapping for the specified key.
   */
  private Object getWrapper(String key)
  {
    Object obj=get(key);
    if (obj==null && !containsKey(key))
    {
      int i=key.indexOf('.');
      if (i<0)
        throw new NoSuchElementException("key '"+key+"' not found");
      String leaf=key;
      ActiveMap map=this;
      do
      {
        map=map.getMap(leaf.substring(0, i));
        if (map==null)
          throw new NoSuchElementException("key '"+key+"' not found");
        leaf=leaf.substring(i+1);
        i=leaf.indexOf('.');
      }
      while (i>=0);
      obj=map.get(leaf);
      if (obj==null && !containsKey(key))
        throw new NoSuchElementException("key '"+key+"' not found");
    }
    return obj;
  }
  /**
   * Associates the specified value with the specified key in this map.
   * If the map previously contained a mapping for this key, the old mapping is replaced
   * regardless of the previous type.
   * @param key    key with which the specified value is to be associated.
   * @param value  value to be associated with the specified key. May be <code>null</code>.
   */
  public void putObject(String key, Object value)
  {
    put(key, value);
  }
  /**
   * Returns the value to which the specified key is mapped.
   * @param key  the key whose associated value is to be returned.
   * @return     the value to which this map maps the specified key. The return value
   *   is <code>null</code> if the key has explicitly been mapped so.
   * @throws NoSuchElementException  if there is no mapping for the specified key.
   */
  public Object getObject(String key)
  {
    return getWrapper(key); // return ((ActiveMap)getWrapper(key)).activate();
  }
  /**
   * Returns the value to which the specified key is mapped. In case of any
   * error, <code>defaultValue</code> is returned.
   * @param key  the key whose associated value is to be returned.
   * @param defaultValue  the value to be returned if there is no or no valid
   *   mapping for the specified key.
   * @return  the value to which this map maps the specified key. The return value
   *   is <code>null</code> if the key has explicitly been mapped so.
   */
  public Object getObject(String key, Object defaultValue)
  {
    try
    {
      return getObject(key);
    }
    catch(Exception x)
    {
    }
    return defaultValue;
  }
  /**
   * Returns the ActiveMap object to which the specified key is mapped.
   * @param key  the key whose associated value is to be returned.
   * @return     the value to which this map maps the specified key. The return value
   *   is <code>null</code> if the key has explicitly been mapped so.
   * @throws NoSuchElementException  if there is no mapping for the specified key.
   */
  public ActiveMap getMap(String key)
  {
    return (ActiveMap)getWrapper(key);
  }

  /**
   * Returns the ActiveMap object to which the specified key is mapped. In case of
   * any error, <code>defaultValue</code> is returned.
   * @param key  the key whose associated value is to be returned.
   * @param defaultValue  the value to be returned if there is no or no valid
   *   mapping for the specified key.
   * @return     the value to which this map maps the specified key. The return value
   *   is <code>null</code> if the key has explicitly been mapped so.
   * @throws NoSuchElementException  if there is no mapping for the specified key.
   */
  public ActiveMap getMap(String key, ActiveMap defaultValue)
  {
    try
    {
      return getMap(key);
    }
    catch(Exception x)
    {
    }
    return defaultValue;
  }
  /**
   * Returns the TypedArray object to which the specified key is mapped.
   * @param key  the key whose associated value is to be returned.
   * @return     the value to which this map maps the specified key. The return value
   *   is <code>null</code> if the key has explicitly been mapped so.
   * @throws NoSuchElementException  if there is no mapping for the specified key.
   */
  public TypedArray getArray(String key)
  {
    return (TypedArray)getWrapper(key);
  }

  /**
   * Returns the TypedArray object to which the specified key is mapped. In case of
   * any error, <code>defaultValue</code> is returned.
   * @param key  the key whose associated value is to be returned.
   * @param defaultValue  the value to be returned if there is no or no valid
   *   mapping for the specified key.
   * @return     the value to which this map maps the specified key. The return value
   *   is <code>null</code> if the key has explicitly been mapped so.
   * @throws NoSuchElementException  if there is no mapping for the specified key.
   */
  public TypedArray getArray(String key, TypedArray defaultValue)
  {
    try
    {
      return getArray(key);
    }
    catch(Exception x)
    {
    }
    return defaultValue;
  }
  
  /**
   * Returns the unique type name for the external representation of
   * this object, that is shared by all platforms and implementations.
   * Typically this is the XSI (XML Schema Instance) type name.
   */
  public String _getExternalTypeName()
  {
    return null;
  }
  /**
   * Passivates the specified object and associates it with the specified key.
   * This method is typically called from <code>_passivate</code> methods.
   * @param key  key with which the passivated object is to be associated. 
   * @param obj  active object to be passivated.
   */
  public void putPassivated(String key, Object obj)
  {
    try
    {
      put(key, passivate(obj));
    }
    catch(Exception x)
    {
      x.printStackTrace();
    }
  }

  /**
   * Returns the passivated map for this map object.
   * @return  passive <code>TypedMap</code>.
   */
  public TypedMap passivateMap() throws Exception
  {
    return (TypedMap)passivate(this);
  }

  /**
   * Writes the state of this object into the specified map.
   * @param passiveMap  passive object.
   */
  public void _passivate(TypedMap passiveMap) throws Exception
  {
    String acName=getClass().getName();
    if (activeClassName!=null)
      passiveMap.setActiveClassName(acName+":"+activeClassName);
    else
      passiveMap.setActiveClassName(acName);

    Object key;






    for (Map.Entry<String, Object> entry: entrySet())
    {




      passiveMap.put(entry.getKey(), TypedMap.passivate(entry.getValue()));
    }
  }

  /**
   * Retrieves the passive object associated with the specified key from the
   * map and returns it in its activated form.
   * This method is typically called from <code>_activate</code> methods.
   * @param key  key whose associated value is to be returned.
   * @param ctx  the activation context.
   * @return     the activated object.
   * @throws Exception  the possible exceptions depend on the objects to be
   *         activated. Exceptions include:
   * @throws IllegalAccessException  if the class or its nullary constructor is
   *         not accessible. 
   * @throws InstantiationException  if this Class represents an abstract class,
   *         an interface, an array class, a primitive type, or void; or if the
   *         class has no nullary constructor; or if the instantiation fails for
   *         some other reason.
   * @throws ExceptionInInitializerError  if the initialization provoked by this
   *         method fails. 
   * @throws SecurityException  if there is no permission to create a new instance.
   */
  public Object getActivated(String key, TypedMap ctx) throws Exception
  {
    return activate(get(key), ctx);
  }
  
  /**
   * Initializes this <code>ActiveMap</code> instance with the
   * state contained in the specified <code>TypedMap</code>.
   * @param passiveMap  passive object.
   * @throws Exception  the possible exceptions depend on the objects to be
   *         activated. Exceptions include:
   * @throws IllegalAccessException  if the class or its nullary constructor is
   *         not accessible. 
   * @throws InstantiationException  if this Class represents an abstract class,
   *         an interface, an array class, a primitive type, or void; or if the
   *         class has no nullary constructor; or if the instantiation fails for
   *         some other reason.
   * @throws ExceptionInInitializerError  if the initialization provoked by this
   *         method fails. 
   * @throws SecurityException  if there is no permission to create a new instance.
   */
  public void _activate(TypedMap passiveMap, TypedMap ctx) throws Exception
  {
    String key;






    for (Iterator iter=passiveMap.keySet().iterator(); iter.hasNext();)
    {
      key=(String)iter.next();
      put(key, activate(passiveMap.get(key), ctx));
    }
  }

  /**
   * Compares if two given arrays are equal. Java's arrays do not override
   * the equals operation from Object. Therefore, the default operation
   * is not very useful.
   * @return  true, if the arrays have the same type, all lengths are equal
   *          and all elements are equal.
   */
  public static boolean arrayEquals(Object oa, Object ob)
  {
    if (!oa.getClass().equals(ob.getClass()))
      return false;
    String className=oa.getClass().getName();
    if (className.charAt(0)!='[')
      return oa.equals(ob);
    switch (className.charAt(1))
    {
      case 'B':
      {
        byte[] a=(byte[])oa;
        byte[] b=(byte[])ob;
        if (a.length!=b.length)
          return false;
        for (int i=0; i<a.length; i++)
          if (a[i]!=b[i])
            return false;
        return true;
      }
      case 'C':
      {
        char[] a=(char[])oa;
        char[] b=(char[])ob;
        if (a.length!=b.length)
          return false;
        for (int i=0; i<a.length; i++)
          if (a[i]!=b[i])
            return false;
        return true;
      }
      case 'D':
      {
        double[] a=(double[])oa;
        double[] b=(double[])ob;
        if (a.length!=b.length)
          return false;
        for (int i=0; i<a.length; i++)
          if (a[i]!=b[i])
            return false;
        return true;
      }
      case 'F':
      {
        float[] a=(float[])oa;
        float[] b=(float[])ob;
        if (a.length!=b.length)
          return false;
        for (int i=0; i<a.length; i++)
          if (a[i]!=b[i])
            return false;
        return true;
      }
      case 'I':
      {
        int[] a=(int[])oa;
        int[] b=(int[])ob;
        if (a.length!=b.length)
          return false;
        for (int i=0; i<a.length; i++)
          if (a[i]!=b[i])
            return false;
        return true;
      }
      case 'J':
      {
        long[] a=(long[])oa;
        long[] b=(long[])ob;
        if (a.length!=b.length)
          return false;
        for (int i=0; i<a.length; i++)
          if (a[i]!=b[i])
            return false;
        return true;
      }
      case 'S':
      {
        short[] a=(short[])oa;
        short[] b=(short[])ob;
        if (a.length!=b.length)
          return false;
        for (int i=0; i<a.length; i++)
          if (a[i]!=b[i])
            return false;
        return true;
      }
      case 'Z':
      {
        boolean[] a=(boolean[])oa;
        boolean[] b=(boolean[])ob;
        if (a.length!=b.length)
          return false;
        for (int i=0; i<a.length; i++)
          if (a[i]!=b[i])
            return false;
        return true;
      }
      case 'L':
      case '[':
      {
        Object[] a=(Object[])oa;
        Object[] b=(Object[])ob;
        if (a.length!=b.length)
          return false;
        for (int i=0; i<a.length; i++)
        {
          if ( (a[i]!=b[i]) &&
               (a[i]==null || b[i]==null || !arrayEquals(a[i], b[i])) )
            return false;
        }
        return true;
      }
      default:
        throw new IllegalStateException("Can't compare "+className);
    }
  }
  
  /**
   * Returns a string representation of this map. The string representation
   * consists of a list of key-value mappings in the order returned by the
   * map's entrySet view's iterator, enclosed in braces ("{}"). The active
   * class name is printed, if it is set, followed by a colon (":"). Adjacent
   * mappings are separated by the characters ", " (comma and space). Each
   * key-value mapping is rendered as the key followed by an equals sign ("=")
   * followed by the associated value.
   * 
   * @see java.lang.Object#toString()
   */
  public String toString()
  {
    StringBuffer sb=new StringBuffer();
    sb.append("{");
    if (activeClassName!=null)
    {
      sb.append(activeClassName);
      sb.append(": ");
    }
    Object key, value;




    for (Iterator iter=keySet().iterator(); iter.hasNext();)
    {
      key=iter.next();
      sb.append(key.toString());
      sb.append("=");
      value=get(key);
      if (value!=null)
        sb.append(value.toString());
      else
        sb.append("(null)");


      if (iter.hasNext())
        sb.append(", ");
    }
    sb.append("}");
    return sb.toString();
  }

  /**
   * Removes all mappings from this map.
   * 
   * @see java.util.Map#clear()
   */
  public void clear() // Map
  {
    ht.clear();
  }
  /**
   * Returns <code>true</code> if this map contains a mapping for the specified key.
   * 
   * @see java.util.Map#containsKey(Object)
   */
  public boolean containsKey(Object key) // Map
  {
    return ht.containsKey(key);
  }
  /**
   * Returns <code>true</code> if this map maps one or more keys to this value.
   * More formally, returns <code>true</code> if and only if this map contains
   * at least one mapping to a value v such that
   * <code>(value==null ? v==null : value.equals(v))</code>. This operation
   * will probably require time linear in the map size for most implementations
   * of map.
   * 
   * @see java.util.Map#containsValue(Object)
   */
  public boolean containsValue(Object value) // Map
  {







    return ht.containsValue(value);
  }
  /**
   * Returns a set view of the mappings contained in this map. Each element in
   * this set is a Map.Entry. The set is backed by the map, so changes to the
   * map are reflected in the set, and vice-versa. (If the map is modified
   * while an iteration over the set is in progress, the results of the iteration
   * are undefined.) The set supports element removal, which removes the
   * corresponding entry from the map, via the <code>Iterator.remove</code>,
   * <code>Set.remove</code>, <code>removeAll</code>, <code>retainAll</code>
   * and <code>clear</code> operations. It does not support the <code>add</code>
   * or <code>addAll</code> operations.
   * 
   * @see java.util.Map#entrySet()
   */
  public Set<Map.Entry<String, Object>> entrySet() // Map


  {
    return ht.entrySet();
  }
  /**
   * Compares the specified object with this map for equality. Returns
   * <code>true</code> if the given object is also a <code>ActiveMap</code>
   * and the two maps represent the same mappings.
   *  
   * @see java.util.Map#equals(Object)
   */
  public boolean equals(Object obj)
  {
    if (!(obj instanceof ActiveMap))
      return false;
    return ht.equals(((ActiveMap)obj).ht);
  }
  /**
   * Returns the value to which this map maps the specified key. Returns
   * <code>null</code> if the map contains no mapping for this key. A return
   * value of <code>null</code> does not necessarily indicate that the map
   * contains no mapping for the key; it's also possible that the map
   * explicitly maps the key to <code>null</code>. The <code>containsKey</code>
   * operation may be used to distinguish these two cases.
   * 
   * @see java.util.Map#get(Object)
   */
  public Object get(Object key) // Map
  {
    return ht.get(key);
  }








  /**
   * Returns the hash code value for this map. The hash code of a map is defined
   * to be the sum of the hash codes of each entry in the map's
   * <code>entrySet()</code> view.
   * 
   * @see java.util.Map#hashCode()
   */
  public int hashCode() // Map
  {
    return ht.hashCode();
  }
  /**
   * Returns <code>true</code> if this map contains no key-value mappings.
   * 
   * @see java.util.Map#isEmpty()
   */
  public boolean isEmpty() // Map
  {
    return ht.isEmpty();
  }
  /**
   * Returns a Set view of the keys contained in this map. The Set is backed by
   * the map, so changes to the map are reflected in the Set, and vice-versa.
   * (If the map is modified while an iteration over the Set is in progress,
   * the results of the iteration are undefined.)
   * 
   * @see java.util.Map#keySet()
   */
  public Set<String> keySet()


  {
    return ht.keySet();
  }
  /**
   * Associates the specified value with the specified key in this map
   * (optional operation). If the map previously contained a mapping for this
   * key, the old value is replaced.
   *
   * @see java.util.Map#put(Object,Object)
   */
  public Object put(String key, Object value) // Map<String,Object>


  {
    return ht.put(key, value);
  }







  /**
   * Copies all of the mappings from the specified map to this map. These
   * mappings will replace any mappings that this map had for any of the keys
   * currently in the specified map.
   * 
   * @see java.util.Map#putAll(Map)
   */
  public void putAll(Map<? extends String, ? extends Object> t)


  {
    ht.putAll(t);
  }
  /**
   * Removes the mapping for this key from this map if present.
   * 
   * @see java.util.Map#remove(Object)
   */
  public Object remove(String key) // Map


  {
    return ht.remove(key);
  }
  /**
   * I consider the Java 1.5 definition of Map.remove as incorrect.
   */
  public Object remove(Object key)
  {
    throw new UnsupportedOperationException("key must be a String");
  }
  
  /**
   * Returns the number of key-value mappings in this map.
   * 
   * @see java.util.Map#size()
   */
  public int size() // Map
  {
    return ht.size();
  }
  /**
   * Returns a collection view of the values contained in this map. The collection
   * is backed by the map, so changes to the map are reflected in the collection,
   * and vice-versa. (If the map is modified while an iteration over the collection
   * is in progress, the results of the iteration are undefined.) 
   * 
   * @see java.util.Map#values()
   */
  public Collection<Object> values()


  {
    return ht.values();
  }
  /**
   * Returns an iterator over the keys in this map.
   * @return  an iterator over the keys in this map.
   */
  public Iterator<String> keyIterator()


  {


    return ht.keySet().iterator();
  }
  /**
   * Returns an iterator over the values in this map.
   * @return  an iterator over the values in this map.
   */
  public Iterator<Object> valueIterator()


  {


    return ht.values().iterator();
  }

  public Iterator<Map.Entry<String,Object>> entryIterator()


  {


    return ht.entrySet().iterator();
  }



















































































  protected HashMap<String, Object> ht = new HashMap<String, Object>();


}
