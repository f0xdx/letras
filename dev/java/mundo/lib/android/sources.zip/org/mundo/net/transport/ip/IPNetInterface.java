/*
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is MundoCore Java.
 *
 * The Initial Developer of the Original Code is Telecooperation Group,
 * Department of Computer Science, Darmstadt University of Technology.
 * Portions created by the Initial Developer are
 * Copyright (C) 2001-2008 the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 * Erwin Aitenbichler
 */

package org.mundo.net.transport.ip;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.Enumeration;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.Inet4Address;
import org.mundo.rt.Logger;


import org.mundo.rt.TypedArray;

public class IPNetInterface
{
  public byte[] addr;
  public byte[] netmask;
  public byte[] bcastAddr;
  public String name;
  public String displayName;
  public int    flags=0;
  
  public static final int DEFAULT_NETMASK = 1;
  
  IPNetInterface()
  {
  }
  





















  public static ArrayList<IPNetInterface> getInterfaces(TypedArray broadcasts)


  {
    // NetworkInterface is a reliable and clean way to enumerate the available
    // network interfaces, but requires Java 1.4. However, it still does not
    // provide the netmask.
    ArrayList<IPNetInterface> list = new ArrayList<IPNetInterface>();


    Enumeration ifEnum=null;
    try
    {
      ifEnum = NetworkInterface.getNetworkInterfaces();
    }
    catch(Exception x)
    {
      log.exception(x);
      return null;
    }
    if (ifEnum!=null)
    {
      while (ifEnum.hasMoreElements())
      {
        NetworkInterface iface=(NetworkInterface)ifEnum.nextElement();
        Enumeration addrEnum=iface.getInetAddresses();
        while (addrEnum.hasMoreElements())
        {
          InetAddress addr=(InetAddress)addrEnum.nextElement();
          if (addr instanceof Inet4Address)
          {
            IPNetInterface ni=new IPNetInterface();
            ni.addr=addr.getAddress();
            ni.name=iface.getName();
            ni.displayName=iface.getDisplayName();
            list.add(ni);
          }
        }
      }
    }

    if (broadcasts!=null)
    {
      Iterator iter = list.iterator();
      while (iter.hasNext())
      {
        IPNetInterface ni = (IPNetInterface)iter.next();
        IPTransportService.OptNet defaultEntry = null;
        Iterator biter=broadcasts.iterator();
        while (biter.hasNext())
        {
          IPTransportService.OptNet b = (IPTransportService.OptNet)biter.next();
          byte[] bcastAddr = ipstr2bytes(b.broadcast);
          byte[] netmask = ipstr2bytes(b.netmask);
          if (netmask==null)
            continue;
          if (bcastAddr==null)
          {
            defaultEntry=b;
            continue;
          }
          if ((ni.addr[0]&netmask[0])==(bcastAddr[0]&netmask[0]) &&
              (ni.addr[1]&netmask[1])==(bcastAddr[1]&netmask[1]) &&
              (ni.addr[2]&netmask[2])==(bcastAddr[2]&netmask[2]) &&
              (ni.addr[3]&netmask[3])==(bcastAddr[3]&netmask[3]))
          {
            ni.bcastAddr=bcastAddr;
            ni.netmask=netmask;
            defaultEntry=null;
            break;
          }
        }
        if (defaultEntry!=null)
        {
          ni.netmask=ipstr2bytes(defaultEntry.netmask);
          ni.bcastAddr=new byte[4];
          ni.bcastAddr[0]=(byte)(ni.addr[0]|(~ni.netmask[0]));
          ni.bcastAddr[1]=(byte)(ni.addr[1]|(~ni.netmask[1]));
          ni.bcastAddr[2]=(byte)(ni.addr[2]|(~ni.netmask[2]));
          ni.bcastAddr[3]=(byte)(ni.addr[3]|(~ni.netmask[3]));
          ni.flags=DEFAULT_NETMASK;
        }
      }
    }

    if (broadcasts!=null)
      log.fine("found netmasks in configuration file");
    log.config("available network interfaces:");
    int i=0;
    Iterator iter=list.iterator();
    while (iter.hasNext())
    {
      i++;
      IPNetInterface ni=(IPNetInterface)iter.next();
      String name=(ni.name!=null) ? ni.name : Integer.toString(i);
      if (ni.displayName!=null)
        log.config(name+": "+ni.displayName);
      StringBuffer sb=new StringBuffer();
      sb.append(name).append(": ");
      sb.append(bytes2ipstr(ni.addr));
      if (ni.netmask!=null)
        sb.append("/").append(bytes2ipstr(ni.netmask));
      if (ni.bcastAddr!=null)
        sb.append(" bcast ").append(bytes2ipstr(ni.bcastAddr));
      if ((ni.flags & DEFAULT_NETMASK)>0)
        sb.append(" default");
      log.config(sb.toString());
    }
    return list;
  }

  static byte[] ipstr2bytes(String s)
  {
    // Do some quick checks, because Exceptions are slow
    if (s==null)
      return null;
    if (s.length()<7)
      return null;
    char c=s.charAt(0);
    if (c<'0' || c>'9')
      return null;
      
    // Parse IPv4 number
    try
    {
      byte[] a=new byte[4];
      int i=s.indexOf('.');
      if (i<0)
        return null;
      String t=s.substring(0, i);
      a[0]=(byte)Integer.parseInt(t);
      s=s.substring(i+1);

      i=s.indexOf('.');
      if (i<0)
        return null;
      t=s.substring(0, i);
      a[1]=(byte)Integer.parseInt(t);
      s=s.substring(i+1);

      i=s.indexOf('.');
      if (i<0)
        return null;
      t=s.substring(0, i);
      a[2]=(byte)Integer.parseInt(t);
      s=s.substring(i+1);
      
      a[3]=(byte)Integer.parseInt(s);

      return a;
    }
    catch(NumberFormatException x)
    {
    }
    return null;
  }

  static String bytes2ipstr(byte[] a)
  {
    return Integer.toString(a[0]&0xff)+"."+
           Integer.toString(a[1]&0xff)+"."+
           Integer.toString(a[2]&0xff)+"."+
           Integer.toString(a[3]&0xff);
  }

  private static Logger log = Logger.getLogger("ipni");
}
