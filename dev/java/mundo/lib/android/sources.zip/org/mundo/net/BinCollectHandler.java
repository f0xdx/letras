/*
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is MundoCore Java.
 *
 * The Initial Developer of the Original Code is Telecooperation Group,
 * Department of Computer Science, Darmstadt University of Technology.
 * Portions created by the Initial Developer are
 * Copyright (C) 2001-2008 the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 * Erwin Aitenbichler
 */

package org.mundo.net;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;

import org.mundo.rt.GUID;
import org.mundo.rt.IMessageHandler;
import org.mundo.rt.Message;
import org.mundo.rt.Service;
import org.mundo.rt.Blob;
import org.mundo.rt.TypedArray;
import org.mundo.rt.TypedMap;
import org.mundo.rt.Logger;




/**
 * A protocol handler to collect all chunks of a message into a single chunk.
 */
public class BinCollectHandler extends Service implements IMessageHandler, org.mundo.rt.IEmits /*emits IMessageHandler*/
{
  public BinCollectHandler()
  {
  }
  public void init()
  {
    super.init();
    ProtocolCoordinator.register(mimeType, this);
  }
  /**
   *
   */
  public boolean down(Message msg)
  {
    // Create output blob and write header
    Blob blob = new Blob();
    // Write MIME type
    serializeString(blob, msg.getType());
    // Write chunk count
    TypedArray binChunks = msg.getChunks("bin");
    int i, s = binChunks.size();
    serializeInt(blob, s);

    // Write binary chunks
    for (i=0; i<s; i++)
    {
      Message.Chunk c = (Message.Chunk)binChunks.get(i);
      Blob b = (Blob)c.content;
      serializeInt(blob, b.size()+4+c.name.length()+4+c.type.length());
      serializeString(blob, c.name);
      serializeString(blob, c.type);
      blob.write(b);
    }

    // FIXME: there is no need to keep other binary chunks
    //Message dmsg = msg.copyFrame();
    msg.setType(mimeType);
    msg.put("all", "bin", blob);

    log.finest("packed message with "+s+" chunks");
    return emit.down(msg);
  }

  /**
   *
   */
  public boolean up(Message msg)
  {
    Blob blob = null;
    try
    {
      blob = msg.getBlob("all", "bin");
      if (blob==null)
      {
        log.warning("all:bin expected - msg dropped");
        return false;
      }
      Cursor c = new Cursor(blob.getBuffer());
      
      // Create message and read MIME type
      msg = msg.copyFrame();
      String type = readString(c);
      if (type==null)
      {
        log.warning("invalid mimeType - msg dropped");
        return false;
      }
      msg.setType(type);

      // This assumption is wrong if there are two consecutive BinSerializationHandlers
      // in the stack on purpose.
//#ifdef 1
//      if (type.equals(mimeType))
//      {
//        log.severe("internal error: type is still "+mimeType+" - this creates an infinte loop!");
//        return false;
//      }
//#endif

      // Read number of chunks
      int i, n=readInt(c);
      for (i=0; i<n; i++)
      {
        // Read chunk size in bytes
        int chunkSize = readInt(c);
        // Read chunk name string
        String name = readString(c);
        if (name==null)
          throw new IllegalArgumentException("invalid chunk name");
        // Read chunk type string
        type = readString(c);
        if (type==null)
          throw new IllegalArgumentException("invalid chunk type");
        int sz = chunkSize-4-name.length()-4-type.length();
  //      log.finest("read chunk "+name+":"+type);
  
        if ("bin".equals(type))
        {
          Blob content = new Blob();
          content.write(c.b, c.pos, sz);
          msg.put(name, "bin", content);
        }
        else
        {
          log.warning("chunk type '"+type+"' not supported");
        }
        c.pos += sz;
      }
      log.finest("unpacked message with "+n+" chunks");

      return emit.up(msg);
    }
    catch(Exception x)
    {
      log.exception(x);
      try
      {
        Cursor c = new Cursor(blob.getBuffer());
        String mimeType = readString(c);
        log.fine(" mimeType  : "+mimeType);
        int i, n=readInt(c);
        log.fine("+chunks    : "+n);
        for (i=0; i<n; i++)
        {
          log.fine("+chunk     : "+i);
          int chunkSize = readInt(c);
          log.fine(" chunkSize : "+chunkSize);
          String name = readString(c);
          log.fine(" name      : "+name);
          String type = readString(c);
          log.fine(" type      : "+type);
          int sz = chunkSize-4-name.length()-4-type.length();
          log.fine(" size      : "+sz);
          c.pos += sz;
          log.fine("-chunk");
        }
        log.fine("-chunks");
      }
      catch(Exception x2)
      {
      }
    }
    return false;
  }  

  private static void serializeInt(Blob blob, int i)
  {
    byte[] a = { (byte)i, (byte)(i>>8), (byte)(i>>16), (byte)(i>>24) };
    blob.write(a);
  }

  private static void serializeString(Blob blob, String s)
  {
    byte[] a;
    try
    {
      a=s.getBytes("UTF8");
    }
    catch(UnsupportedEncodingException x)
    {
      a=s.getBytes();
    }
    serializeInt(blob, a.length);
    blob.write(a);
  }

  private int readInt(Cursor c)
  {
    byte[] b = c.b;
    int p = c.pos;
    int v = (b[p] & 0xff) |
            ((b[p+1] & 0xff) << 8) |
            ((b[p+2] & 0xff) << 16) |
            ((b[p+3] & 0xff) << 24);
    c.pos += 4;
    return v;
  }

  /**
   * Note that name and type strings must not be longer than 80 characters.
   * @return
   */
  private String readString(Cursor c)
  {
    int v = readInt(c);
    if (v<0 || v>80)
      return null;
    String s;
    try
    {
      s = new String(c.b, c.pos, v, "UTF8");
    }
    catch(UnsupportedEncodingException x)
    {
      byte[] a = new byte[v];
      System.arraycopy(c.b, c.pos, a, 0, v);
      s = new String(a);
    }
    c.pos += v;
    return s;
  }

  private class Cursor
  {
    Cursor(byte[] b)
    {
      this.b = b;
      pos = 0;
    }
    byte[] b;
    int    pos;
  }
  
  private Logger log = Logger.getLogger("bincoll");
  private static final String mimeType = "message/mc-bincoll";

  // Generated by mcc
  protected class __EmitStub__ implements IMessageHandler
  {
    public boolean down(Message p0) // IMessageHandler
    {
      Object[] a=org.mundo.rt.Signal.getTargets(IMessageHandler.class, BinCollectHandler.this);
      if (a==null) throw new IllegalStateException("signal not connected");
      return ((IMessageHandler)a[0]).down(p0);
    }
    public boolean up(Message p0) // IMessageHandler
    {
      Object[] a=org.mundo.rt.Signal.getTargets(IMessageHandler.class, BinCollectHandler.this);
      if (a==null) throw new IllegalStateException("signal not connected");
      return ((IMessageHandler)a[0]).up(p0);
    }
  }
  private __EmitStub__ emit=new __EmitStub__();
  public boolean isEmitting(Class signal)
  {
    if (IMessageHandler.class.isAssignableFrom(signal)) return true;
    return false;
  }
}
