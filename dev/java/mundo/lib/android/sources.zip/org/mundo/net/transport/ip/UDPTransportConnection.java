/*
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is MundoCore Java.
 *
 * The Initial Developer of the Original Code is Telecooperation Group,
 * Department of Computer Science, Darmstadt University of Technology.
 * Portions created by the Initial Developer are
 * Copyright (C) 2001-2008 the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 * Erwin Aitenbichler
 */

package org.mundo.net.transport.ip;

//#define TRACE_MODULE

import java.io.InputStream;
import java.io.OutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.EOFException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketException;
import java.net.DatagramPacket;
import java.util.Iterator;

import org.mundo.rt.GUID;
import org.mundo.rt.IReceiver;
import org.mundo.rt.Blob;
import org.mundo.rt.Signal;
import org.mundo.rt.Message;
import org.mundo.rt.TypedMap;
import org.mundo.rt.Mundo;
import org.mundo.rt.IntegerMonitor;
import org.mundo.rt.Mutex;
import org.mundo.rt.Queue;
import org.mundo.net.transport.TransportLink;

import org.mundo.rt.Logger;







/**
 * Implements a transport connection using UDP/IP.
 * @author Erwin Aitenbichler
 */
public class UDPTransportConnection
       implements IIPTransportConnection
{
  UDPTransportConnection(IPLink l)
  {
    route = l;
    InetSocketAddress a = route.getPeerExtAddress();
    remoteAddr = a.getAddress();
    remotePort = a.getPort();
    service = route.ipts;
  }
  public void init(GUID d, InetAddress a, int p, TypedMap opts) // IIPTransportConnection
  {
    // FIXME: The init method is relatively pointless as it is now.
    // see IIPTransportConnection for more comments
    
    mutex.lock();
//    destId=d;
//      remoteAddr=a;
//      remotePort=p;
    state=STATE_CONNECTING_2;
    if (route!=null)
    {
      route.remoteId=d;
      route.remoteName=opts.getString("name", null);
    }
    mutex.unlock();
  }
  /**
   * Returns the node identifier of the remote peer.
   * @return  the node GUID of the remote peer.
   */
/*
  public GUID getRemoteId() // ITransportConnection
  {
    GUID id;
    mutex.lock();
    id=destId;
    mutex.unlock();
    return id;
  }
*/
  /**
   * Returns the IP address of the remote peer.
   * @return  the IP address of the remote peer.
   */
  public InetAddress getRemoteAddress() // IIPTransportConnection
  {
    InetAddress addr;
    mutex.lock();
    addr=remoteAddr;
    mutex.unlock();
    return addr;
  }
  /**
   * Returns the remote port number.
   * @return  the remote port number.
   */
  public int getRemotePort() // IIPTransportConnection
  {
    int port;
    mutex.lock();
    port=remotePort;
    mutex.unlock();
    return port;
  }
  /**
   * Returns the state of this connection.
   */
  public int getState() // IIPTransportConnection
  {
    int s;
    mutex.lock();
    s=state;
    mutex.unlock();
    return s;
  }
  /**
   * Returns the associated route object.
   */
  public TransportLink getLink() // ITransportConnection
  {
    IPLink l;
    mutex.lock();
    l = route;
    mutex.unlock();
    return l;
  }
  /**
   * Returns the metric value of this connection. The routing service
   * always trys to use the connection with the lowest value. This method
   * always returns a valid value. If the connection is closed, the
   * returned value is as if the connection were open (or only minimally
   * different).
   * 
   * <table><tr><td><b>Metric</b></td><td><b>Description<b></td></tr>
   * <tr><td><code>9</code></td><td>Connections to <code>127.0.0.1:PRIMARY_PORT</code>. Because
   * connections to the primary port never time out, they should always
   * be used for data transfers when they are present.</td></tr>
   * <tr><td><code>10</code></td><td>Connections to <code>127.0.0.1</code>. Connections via the
   * loopback network interface are cheaper than real network connections.</td></tr>
   * <tr><td><code>20</code></td><td>Network connections.</td></tr>
   * <tr><td><code>999</code></td><td>If the connection object has not been initialized
   * with the address of the remote endpoint.</td></tr>
   * </table>
   */
  public int getMetric() // ITransportConnection
  {
    mutex.lock();
    try
    {
//      if (sock!=null && sock.getLocalPort()==IPTransportService.primaryPort)
//        return 9;
      if (remoteAddr==null)
        return 999;
      byte[] a=remoteAddr.getAddress();
      if (a[0]==127 && a[1]==0 && a[2]==0)
      {
        if (remotePort==IPTransportService.primaryPort)
          return 9;
        return 10;
      }
      return 20;
    }
    finally
    {
      mutex.unlock();
    }
  }
  /**
   * Opens the connection.
   */  
  public boolean connect() throws Exception // ITransportConnection
  {
    log.finer("connect: state="+state);
    boolean connOpened=false;
    mutex.lock();
    try
    {
      if (state==STATE_CONNECTING_2)
      {
        TypedMap doc=new TypedMap();
        doc.put("request", "NodeAddReply");
        doc.putInt("version", IPTransportService.CURRENT_PROTOCOL_VERSION);
        doc.putInt("udp-port", service.getUDPPort());
        doc.put("vpId", Mundo.getNodeId());
        doc.put("name", Mundo.getNodeName());
        log.fine("NodeAddReply > "+Mundo.getNodeId().shortString());
        Message msg = new Message("ipts", "passive", doc);
        service.serialize(msg);
        sendControl(msg);
        connOpened=true;
        state=STATE_CONNECTED;
      }
    }
    catch(Exception x)
    {
      log.exception(x);
    }
    mutex.unlock();
    if (connOpened)
      service.connectionOpened(this);
    return true;
  }
  
  private void sendControl(Message msg) throws IOException
  {
    byte[] src = msg.getBlob("all").getBuffer();
    byte[] dest = new byte[src.length+1];
    dest[0] = IPTransportService.MSGTYPE_CTRL_BIN;
    System.arraycopy(src, 0, dest, 1, src.length);
    
    DatagramPacket dgram = new DatagramPacket(dest, dest.length);
    dgram.setAddress(remoteAddr);
    dgram.setPort(remotePort);
    log.finer("send ctrl > "+remoteAddr+":"+remotePort);
    service.sendDatagram(dgram);
  }

  private void sendData(Message msg) throws IOException
  {
    TypedMap amap = msg.getMap("address", "passive");
    if (amap==null)
      throw new IllegalArgumentException("message does not contain an address map");
    String mimeType = amap.getString("mimeType");
    int ml = mimeType.length();
    if (ml>127)
      throw new IllegalArgumentException("mimeType string too long");

    byte[] src = msg.getBlob("all").getBuffer();
    byte[] dest = new byte[2+ml+src.length];
    dest[0] = IPTransportService.MSGTYPE_DATA;
    dest[1] = (byte)ml;
    System.arraycopy(mimeType.getBytes(), 0, dest, 2, ml);
    System.arraycopy(src, 0, dest, 2+ml, src.length);
    
    DatagramPacket dgram = new DatagramPacket(dest, dest.length);
    dgram.setAddress(remoteAddr);
    dgram.setPort(remotePort);
    log.finer("send data > "+remoteAddr+":"+remotePort);
    service.sendDatagram(dgram);
  }
  
  /**
   * Starts the disconnect operation.
   */
  public void disconnect() // ITransportConnection
  {
    mutex.lock();
    if (state<STATE_DISCONNECT_REQUESTED)
      state=STATE_DISCONNECTED;
    mutex.unlock();
  }
  /**
   * Waits until all messages in the send queue have been sent and closes
   * the socket.
   * @return  <code>true</code> if it was a clean shutdown, or
   *          <code>false</code> otherwise.
   */
  public boolean disconnectWait() // IIPTransportConnection
  {
    return true;
  }
  public boolean isConnected() // ITransportConnection
  {
    boolean b;
    mutex.lock();
    b=(state==STATE_CONNECTED);
    mutex.unlock();
    return b;
  }
  /**
   * Periodically called by a routing service to update the timeout counters
   * and to close unused connections.
   * @return  true if the connection is still open, false if not.
   */
  public boolean checkTimeout(int elapsed) // ITransportConnection
  {
    return (state<=STATE_CONNECTED);
  }

  public boolean send(Message msg) // ITransportConnection
  {
    if (state>STATE_CONNECTED)
    {
      log.severe("attempting to send after disconnect");
      return false;
    }
    mutex.lock();
    try
    {
      if (state>STATE_CONNECTED)
      {
        log.severe("attempting to send after disconnect");
        return false;
      }
      if (IPTransportService.mimeType.equals(msg.getType()))
        sendControl(msg);
      else
        sendData(msg);
      return true;
    }
    catch(IOException x)
    {
      log.exception(x);
    }
    finally
    {
      mutex.unlock();
    }
    return false;
  }
  /**
   * Returns a string representation of this object.
   * @return  a string representation of this object.
   */
  public String toString()
  {
    String s;
    mutex.lock();
    s="UDP: "+remoteAddr+":"+remotePort;
    mutex.unlock();
    return s;
  }


  private static int readInt(DataInputStream is) throws IOException
  {
    byte[] b=new byte[4];
    is.readFully(b);
    int v=(b[0]&0xff)|((b[1]&0xff)<<8)|((b[2]&0xff)<<16)|((b[3]&0xff)<<24);
    return v;
  }
  private static void writeInt(OutputStream os, int i) throws IOException
  {
    byte[] a = { (byte)i, (byte)(i>>8), (byte)(i>>16), (byte)(i>>24) };
    os.write(a);
  }

  // internal
//  private GUID destId;
  private InetAddress remoteAddr;
  private int remotePort;
//  private Socket sock;
  private IPTransportService service;
  private IPLink route;
  private Mutex mutex = new Mutex();
//  private OutputStream os;
  private static Logger log = Logger.getLogger("udp");



  // We permit disconnects only when useCnt==0. Read and write operations
  // increment this value to ensure that nobody is closing the connection
  // in parallel.
//  private IntegerMonitor useCnt = new IntegerMonitor(0);
//  private IntegerMonitor sendTimeout = new IntegerMonitor(-1);
//  private IntegerMonitor disconnectTimeout = new IntegerMonitor(-1);
  
  private int state = STATE_NULL;
}
