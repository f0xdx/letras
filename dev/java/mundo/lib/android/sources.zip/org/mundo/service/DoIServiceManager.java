package org.mundo.service;


/**
 * Automatically generated distributed object class for <code>IServiceManager</code>.
 * @see org.mundo.service.IServiceManager
 */
public class DoIServiceManager extends org.mundo.rt.DoObject implements org.mundo.service.IServiceManager
{
  public DoIServiceManager()
  {
  }
  public DoIServiceManager(org.mundo.rt.Session session, Object obj) throws org.mundo.rt.RMCException
  {
    _bind(session, obj);
  }
  public DoIServiceManager(org.mundo.rt.Channel channel) throws org.mundo.rt.RMCException
  {
    _setPublisher(channel.getSession().publish(channel.getZone(), channel.getName()));
  }
  public DoIServiceManager(org.mundo.rt.DoObject o)
  {
    _assign(o);
  }
  public org.mundo.rt.ServerStub _getServerStub()
  {
    return SrvIServiceManager._getObject();
  }
  public static DoIServiceManager _of(org.mundo.rt.Session session, Object obj)
  {
    DoIServiceManager cs=(DoIServiceManager)_getDoObject(session, DoIServiceManager.class, obj);
    if (cs==null)
    {
      cs=new DoIServiceManager(session, obj);
      _putDoObject(session, obj, cs);
    }
    return cs;
  }
  public static DoIServiceManager _of(org.mundo.rt.Service s)
  {
    return _of(s.getSession(), s);
  }
  public String _getInterfaceName()
  {
    return "org.mundo.service.IServiceManager";
  }
  public static IServiceManager _localObject(IServiceManager obj)
  {
    if (obj instanceof org.mundo.rt.DoObject)
    {
      return (IServiceManager)((org.mundo.rt.DoObject)obj)._getLocalObject();
    }
    else
    {
      return obj;
    }
  }
  public java.util.List getServiceInstances()
  {
    if (localObj!=null) 
    {
      return ((org.mundo.service.IServiceManager)localObj).getServiceInstances();
    }
    org.mundo.rt.AsyncCall call=getServiceInstances(SYNC);
    return (java.util.List)call.getObj();
  }
  public org.mundo.rt.AsyncCall getServiceInstances(Options opt) 
  {
    org.mundo.rt.TypedMap m=new org.mundo.rt.TypedMap();
    m.putString("ptypes", "");
    m.putString("rtype", "java.util.List");
    org.mundo.rt.AsyncCall call=new org.mundo.rt.AsyncCall(this, "org.mundo.service.IServiceManager", "getServiceInstances", m);
    if (opt==ONEWAY)
    {
      call.invokeOneWay();
    }
    else if (opt==SYNC || opt==ASYNC)
    {
      call.invoke();
    }
    if (opt==SYNC)
    {
      try
      {
        if (!call.waitForReply())
        {
          throw call.getException();
        }
      }
      catch(RuntimeException x)
      {
        throw x;
      }
      catch(Exception x)
      {
        throw new org.mundo.rt.RMCException("unexpected exception", x);
      }
    }
    return call;
  }
  
  public java.util.List getServiceClasses()
  {
    if (localObj!=null) 
    {
      return ((org.mundo.service.IServiceManager)localObj).getServiceClasses();
    }
    org.mundo.rt.AsyncCall call=getServiceClasses(SYNC);
    return (java.util.List)call.getObj();
  }
  public org.mundo.rt.AsyncCall getServiceClasses(Options opt) 
  {
    org.mundo.rt.TypedMap m=new org.mundo.rt.TypedMap();
    m.putString("ptypes", "");
    m.putString("rtype", "java.util.List");
    org.mundo.rt.AsyncCall call=new org.mundo.rt.AsyncCall(this, "org.mundo.service.IServiceManager", "getServiceClasses", m);
    if (opt==ONEWAY)
    {
      call.invokeOneWay();
    }
    else if (opt==SYNC || opt==ASYNC)
    {
      call.invoke();
    }
    if (opt==SYNC)
    {
      try
      {
        if (!call.waitForReply())
        {
          throw call.getException();
        }
      }
      catch(RuntimeException x)
      {
        throw x;
      }
      catch(Exception x)
      {
        throw new org.mundo.rt.RMCException("unexpected exception", x);
      }
    }
    return call;
  }
  
  public org.mundo.rt.TypedMap getServiceConfig(org.mundo.rt.GUID p0)
  {
    if (localObj!=null) 
    {
      return ((org.mundo.service.IServiceManager)localObj).getServiceConfig(p0);
    }
    org.mundo.rt.AsyncCall call=getServiceConfig(p0, SYNC);
    return (org.mundo.rt.TypedMap)call.getObj();
  }
  public org.mundo.rt.AsyncCall getServiceConfig(org.mundo.rt.GUID p0, Options opt) 
  {
    org.mundo.rt.TypedMap m=new org.mundo.rt.TypedMap();
    m.putString("ptypes", "g");
    m.putString("rtype", "org.mundo.rt.TypedMap");
    m.putObject("p0", p0);
    org.mundo.rt.AsyncCall call=new org.mundo.rt.AsyncCall(this, "org.mundo.service.IServiceManager", "getServiceConfig", m);
    if (opt==ONEWAY)
    {
      call.invokeOneWay();
    }
    else if (opt==SYNC || opt==ASYNC)
    {
      call.invoke();
    }
    if (opt==SYNC)
    {
      try
      {
        if (!call.waitForReply())
        {
          throw call.getException();
        }
      }
      catch(RuntimeException x)
      {
        throw x;
      }
      catch(Exception x)
      {
        throw new org.mundo.rt.RMCException("unexpected exception", x);
      }
    }
    return call;
  }
  
  public void setServiceConfig(org.mundo.rt.GUID p0, org.mundo.rt.TypedMap p1)
  {
    if (localObj!=null) 
    {
      ((org.mundo.service.IServiceManager)localObj).setServiceConfig(p0, p1);
      return;
    }
    setServiceConfig(p0, p1, SYNC);
  }
  public org.mundo.rt.AsyncCall setServiceConfig(org.mundo.rt.GUID p0, org.mundo.rt.TypedMap p1, Options opt) 
  {
    org.mundo.rt.TypedMap m=new org.mundo.rt.TypedMap();
    m.putString("ptypes", "g,org.mundo.rt.TypedMap");
    m.putString("rtype", "");
    m.putObject("p0", p0);
    m.putObject("p1", p1);
    org.mundo.rt.AsyncCall call=new org.mundo.rt.AsyncCall(this, "org.mundo.service.IServiceManager", "setServiceConfig", m);
    if (opt==ONEWAY)
    {
      call.invokeOneWay();
    }
    else if (opt==SYNC || opt==ASYNC)
    {
      call.invoke();
    }
    if (opt==SYNC)
    {
      try
      {
        if (!call.waitForReply())
        {
          throw call.getException();
        }
      }
      catch(RuntimeException x)
      {
        throw x;
      }
      catch(Exception x)
      {
        throw new org.mundo.rt.RMCException("unexpected exception", x);
      }
    }
    return call;
  }
  
  public void shutdownService(org.mundo.rt.GUID p0)
  {
    if (localObj!=null) 
    {
      ((org.mundo.service.IServiceManager)localObj).shutdownService(p0);
      return;
    }
    shutdownService(p0, SYNC);
  }
  public org.mundo.rt.AsyncCall shutdownService(org.mundo.rt.GUID p0, Options opt) 
  {
    org.mundo.rt.TypedMap m=new org.mundo.rt.TypedMap();
    m.putString("ptypes", "g");
    m.putString("rtype", "");
    m.putObject("p0", p0);
    org.mundo.rt.AsyncCall call=new org.mundo.rt.AsyncCall(this, "org.mundo.service.IServiceManager", "shutdownService", m);
    if (opt==ONEWAY)
    {
      call.invokeOneWay();
    }
    else if (opt==SYNC || opt==ASYNC)
    {
      call.invoke();
    }
    if (opt==SYNC)
    {
      try
      {
        if (!call.waitForReply())
        {
          throw call.getException();
        }
      }
      catch(RuntimeException x)
      {
        throw x;
      }
      catch(Exception x)
      {
        throw new org.mundo.rt.RMCException("unexpected exception", x);
      }
    }
    return call;
  }
  
  public void shutdownService(String p0)
  {
    if (localObj!=null) 
    {
      ((org.mundo.service.IServiceManager)localObj).shutdownService(p0);
      return;
    }
    shutdownService(p0, SYNC);
  }
  public org.mundo.rt.AsyncCall shutdownService(String p0, Options opt) 
  {
    org.mundo.rt.TypedMap m=new org.mundo.rt.TypedMap();
    m.putString("ptypes", "s");
    m.putString("rtype", "");
    m.putString("p0", p0);
    org.mundo.rt.AsyncCall call=new org.mundo.rt.AsyncCall(this, "org.mundo.service.IServiceManager", "shutdownService", m);
    if (opt==ONEWAY)
    {
      call.invokeOneWay();
    }
    else if (opt==SYNC || opt==ASYNC)
    {
      call.invoke();
    }
    if (opt==SYNC)
    {
      try
      {
        if (!call.waitForReply())
        {
          throw call.getException();
        }
      }
      catch(RuntimeException x)
      {
        throw x;
      }
      catch(Exception x)
      {
        throw new org.mundo.rt.RMCException("unexpected exception", x);
      }
    }
    return call;
  }
  
  public org.mundo.rt.DoObject newInstance(String p0, String p1, org.mundo.rt.TypedMap p2) throws ClassNotFoundException, InstantiationException, IllegalAccessException
  {
    if (localObj!=null) 
    {
      return ((org.mundo.service.IServiceManager)localObj).newInstance(p0, p1, p2);
    }
    org.mundo.rt.AsyncCall call=newInstance(p0, p1, p2, SYNC);
    return (org.mundo.rt.DoObject)call.getObj();
  }
  public org.mundo.rt.AsyncCall newInstance(String p0, String p1, org.mundo.rt.TypedMap p2, Options opt)  throws ClassNotFoundException, InstantiationException, IllegalAccessException
  {
    org.mundo.rt.TypedMap m=new org.mundo.rt.TypedMap();
    m.putString("ptypes", "s,s,org.mundo.rt.TypedMap");
    m.putString("rtype", "org.mundo.rt.DoObject");
    m.putString("p0", p0);
    m.putString("p1", p1);
    m.putObject("p2", p2);
    org.mundo.rt.AsyncCall call=new org.mundo.rt.AsyncCall(this, "org.mundo.service.IServiceManager", "newInstance", m);
    if (opt==ONEWAY)
    {
      call.invokeOneWay();
    }
    else if (opt==SYNC || opt==ASYNC)
    {
      call.invoke();
    }
    if (opt==SYNC)
    {
      try
      {
        if (!call.waitForReply())
        {
          throw call.getException();
        }
      }
      catch (ClassNotFoundException x)
      {
        throw x;
      }
      catch (InstantiationException x)
      {
        throw x;
      }
      catch (IllegalAccessException x)
      {
        throw x;
      }
      catch(RuntimeException x)
      {
        throw x;
      }
      catch(Exception x)
      {
        throw new org.mundo.rt.RMCException("unexpected exception", x);
      }
    }
    return call;
  }
  
  public void uploadFile(String p0, org.mundo.rt.Blob p1) throws java.io.IOException
  {
    if (localObj!=null) 
    {
      ((org.mundo.service.IServiceManager)localObj).uploadFile(p0, p1);
      return;
    }
    uploadFile(p0, p1, SYNC);
  }
  public org.mundo.rt.AsyncCall uploadFile(String p0, org.mundo.rt.Blob p1, Options opt)  throws java.io.IOException
  {
    org.mundo.rt.TypedMap m=new org.mundo.rt.TypedMap();
    m.putString("ptypes", "s,org.mundo.rt.Blob");
    m.putString("rtype", "");
    m.putString("p0", p0);
    m.putObject("p1", p1);
    org.mundo.rt.AsyncCall call=new org.mundo.rt.AsyncCall(this, "org.mundo.service.IServiceManager", "uploadFile", m);
    if (opt==ONEWAY)
    {
      call.invokeOneWay();
    }
    else if (opt==SYNC || opt==ASYNC)
    {
      call.invoke();
    }
    if (opt==SYNC)
    {
      try
      {
        if (!call.waitForReply())
        {
          throw call.getException();
        }
      }
      catch (java.io.IOException x)
      {
        throw x;
      }
      catch(RuntimeException x)
      {
        throw x;
      }
      catch(Exception x)
      {
        throw new org.mundo.rt.RMCException("unexpected exception", x);
      }
    }
    return call;
  }
  
  public org.mundo.rt.Blob downloadFile(String p0) throws java.io.IOException
  {
    if (localObj!=null) 
    {
      return ((org.mundo.service.IServiceManager)localObj).downloadFile(p0);
    }
    org.mundo.rt.AsyncCall call=downloadFile(p0, SYNC);
    return (org.mundo.rt.Blob)call.getObj();
  }
  public org.mundo.rt.AsyncCall downloadFile(String p0, Options opt)  throws java.io.IOException
  {
    org.mundo.rt.TypedMap m=new org.mundo.rt.TypedMap();
    m.putString("ptypes", "s");
    m.putString("rtype", "org.mundo.rt.Blob");
    m.putString("p0", p0);
    org.mundo.rt.AsyncCall call=new org.mundo.rt.AsyncCall(this, "org.mundo.service.IServiceManager", "downloadFile", m);
    if (opt==ONEWAY)
    {
      call.invokeOneWay();
    }
    else if (opt==SYNC || opt==ASYNC)
    {
      call.invoke();
    }
    if (opt==SYNC)
    {
      try
      {
        if (!call.waitForReply())
        {
          throw call.getException();
        }
      }
      catch (java.io.IOException x)
      {
        throw x;
      }
      catch(RuntimeException x)
      {
        throw x;
      }
      catch(Exception x)
      {
        throw new org.mundo.rt.RMCException("unexpected exception", x);
      }
    }
    return call;
  }
  
  public void deleteFile(String p0) throws java.io.IOException
  {
    if (localObj!=null) 
    {
      ((org.mundo.service.IServiceManager)localObj).deleteFile(p0);
      return;
    }
    deleteFile(p0, SYNC);
  }
  public org.mundo.rt.AsyncCall deleteFile(String p0, Options opt)  throws java.io.IOException
  {
    org.mundo.rt.TypedMap m=new org.mundo.rt.TypedMap();
    m.putString("ptypes", "s");
    m.putString("rtype", "");
    m.putString("p0", p0);
    org.mundo.rt.AsyncCall call=new org.mundo.rt.AsyncCall(this, "org.mundo.service.IServiceManager", "deleteFile", m);
    if (opt==ONEWAY)
    {
      call.invokeOneWay();
    }
    else if (opt==SYNC || opt==ASYNC)
    {
      call.invoke();
    }
    if (opt==SYNC)
    {
      try
      {
        if (!call.waitForReply())
        {
          throw call.getException();
        }
      }
      catch (java.io.IOException x)
      {
        throw x;
      }
      catch(RuntimeException x)
      {
        throw x;
      }
      catch(Exception x)
      {
        throw new org.mundo.rt.RMCException("unexpected exception", x);
      }
    }
    return call;
  }
  
  public void advertiseServices()
  {
    if (localObj!=null) 
    {
      ((org.mundo.service.IServiceManager)localObj).advertiseServices();
      return;
    }
    advertiseServices(SYNC);
  }
  public org.mundo.rt.AsyncCall advertiseServices(Options opt) 
  {
    org.mundo.rt.TypedMap m=new org.mundo.rt.TypedMap();
    m.putString("ptypes", "");
    m.putString("rtype", "");
    org.mundo.rt.AsyncCall call=new org.mundo.rt.AsyncCall(this, "org.mundo.service.IServiceManager", "advertiseServices", m);
    if (opt==ONEWAY)
    {
      call.invokeOneWay();
    }
    else if (opt==SYNC || opt==ASYNC)
    {
      call.invoke();
    }
    if (opt==SYNC)
    {
      try
      {
        if (!call.waitForReply())
        {
          throw call.getException();
        }
      }
      catch(RuntimeException x)
      {
        throw x;
      }
      catch(Exception x)
      {
        throw new org.mundo.rt.RMCException("unexpected exception", x);
      }
    }
    return call;
  }
  
  public void resumeService(org.mundo.rt.TypedMap p0) throws Exception
  {
    if (localObj!=null) 
    {
      ((org.mundo.service.IServiceManager)localObj).resumeService(p0);
      return;
    }
    resumeService(p0, SYNC);
  }
  public org.mundo.rt.AsyncCall resumeService(org.mundo.rt.TypedMap p0, Options opt)  throws Exception
  {
    org.mundo.rt.TypedMap m=new org.mundo.rt.TypedMap();
    m.putString("ptypes", "org.mundo.rt.TypedMap");
    m.putString("rtype", "");
    m.putObject("p0", p0);
    org.mundo.rt.AsyncCall call=new org.mundo.rt.AsyncCall(this, "org.mundo.service.IServiceManager", "resumeService", m);
    if (opt==ONEWAY)
    {
      call.invokeOneWay();
    }
    else if (opt==SYNC || opt==ASYNC)
    {
      call.invoke();
    }
    if (opt==SYNC)
    {
      try
      {
        if (!call.waitForReply())
        {
          throw call.getException();
        }
      }
      catch (Exception x)
      {
        throw x;
      }
    }
    return call;
  }
  
}