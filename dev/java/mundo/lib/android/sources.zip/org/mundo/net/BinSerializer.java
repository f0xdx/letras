/*
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is MundoCore Java.
 *
 * The Initial Developer of the Original Code is Telecooperation Group,
 * Department of Computer Science, Darmstadt University of Technology.
 * Portions created by the Initial Developer are
 * Copyright (C) 2001-2008 the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 * Erwin Aitenbichler
 */

package org.mundo.net;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Hashtable;
import java.util.NoSuchElementException;
import java.util.List;
import java.util.Map;
import java.util.Iterator;



import org.mundo.rt.TypedContainer;
import org.mundo.rt.TypedMap;
import org.mundo.rt.TypedArray;
import org.mundo.rt.Message;
import org.mundo.rt.Blob;
import org.mundo.rt.GUID;

/**
 * Transforms a passive object tree into a byte stream.
 * This implementation is not based on streams an will therefore also
 * work on Java versions without serialization support.
 * @see BinDeserializer
 * @author Erwin Aitenbichler
 */
public class BinSerializer
{
  /**
   * Initializes a new BinSerializer.
   */
  public BinSerializer()
  {
  }

  /**
   * Serializes an object.
   * @param obj  the passive object tree to serialize.
   * @return     a <code>Blob</code> containing the output byte stream.
   */
  public Blob serialize(Object obj) throws IOException
  {
    Blob blob=new Blob();
    serializeObject(blob, obj);
    return blob;
  }

  /**
   * Serializes a message. Serializes the chunk <code>main:passive</code> into
   * <code>main:bin</code>.
   * @param msg  a message containing a number of chunks. A chunk can either
   *             be a map containing a passive object tree or a blob containing
   *             binary data.
   */
  public void serializeMain(Message msg) throws IOException
  {
    TypedMap map = msg.getMap("main", "passive");
    if (map==null)
      throw new IllegalArgumentException("chunk main:passive expected");
    
    Blob blob = new Blob();
    serializeObject(blob, map);
    msg.put("main", "bin", blob);
  }

  /**
   * Serializes a message. Serializes all passive chunks into <code>main:bin</code>.
   * @param msg  a message containing a number of chunks. A chunk can either
   *             be a map containing a passive object tree or a blob containing
   *             binary data.
   */
  public void serialize(Message msg) throws IOException
  {
    int totalSize=0;
    int chunkCount=0;
    Blob blob;
      
    // Serialize passive chunks
    TypedArray passiveChunks=msg.getChunks("passive");
    int i, s=passiveChunks.size();
    chunkCount+=s;
    Blob passiveBlobs[]=new Blob[s];
    for (i=0; i<s; i++)
    {
      Message.Chunk c=(Message.Chunk)passiveChunks.get(i);
      blob=new Blob();
      serializeString(blob, c.name);
      serializeString(blob, c.type);
      TypedMap map=(TypedMap)c.content;
//      map.setActiveClassName(null);
      serializeObject(blob, map);
      passiveBlobs[i]=blob;
      totalSize+=4+blob.size();
    }

    // Create output blob and write header
    blob=new Blob();
    serializeInt(blob, chunkCount);

    // Write serialized passive chunks
    for (i=0; i<passiveBlobs.length; i++)
    {
      serializeInt(blob, passiveBlobs[i].size());
      blob.write(passiveBlobs[i]);
    }

    msg.put("all", "bin", blob);
  }

  /**
   * Serializes a message. Serializes all passive and binary chunks into
   * <code>all:bin</code>.
   * @param msg  a message containing a number of chunks. A chunk can either
   *             be a map containing a passive object tree or a blob containing
   *             binary data.
   */
  public void serializeAll(Message msg) throws IOException
  {
    int totalSize=0;
    int chunkCount=0;
    Blob blob;
      
    // Serialize passive chunks
    TypedArray passiveChunks=msg.getChunks("passive");
    int i, s=passiveChunks.size();
    chunkCount+=s;
    Blob passiveBlobs[]=new Blob[s];
    for (i=0; i<s; i++)
    {
      Message.Chunk c=(Message.Chunk)passiveChunks.get(i);
      blob=new Blob();
      serializeString(blob, c.name);
      serializeString(blob, c.type);
      TypedMap map=(TypedMap)c.content;
//      map.setActiveClassName(null);
      serializeObject(blob, map);
      passiveBlobs[i]=blob;
      totalSize+=4+blob.size();
    }

    // Determine sizes of binary chunks
    TypedArray binChunks=msg.getChunks("bin");
    s=binChunks.size();
    chunkCount+=s;
    for (i=0; i<s; i++)
    {
      Message.Chunk c=(Message.Chunk)binChunks.get(i);
      blob=(Blob)c.content;
      totalSize+=4+4+c.name.length()+4+c.type.length()+blob.size();
    }

    // Create output blob and write header
    blob=new Blob();
    serializeInt(blob, chunkCount);

    // Write serialized passive chunks
    for (i=0; i<passiveBlobs.length; i++)
    {
      serializeInt(blob, passiveBlobs[i].size());
      blob.write(passiveBlobs[i]);
    }

    // Write binary chunks
    s=binChunks.size();
    for (i=0; i<s; i++)
    {
      Message.Chunk c=(Message.Chunk)binChunks.get(i);
      Blob b=(Blob)c.content;
      serializeInt(blob, b.size()+4+c.name.length()+4+c.type.length());
      serializeString(blob, c.name);
      serializeString(blob, c.type);
      blob.write(b);
    }
    msg.put("all", "bin", blob);
  }

  private static void serializeInt(Blob blob, char c, int i)
  {
    byte[] a = { (byte)c, (byte)i, (byte)(i>>8), (byte)(i>>16), (byte)(i>>24) };
    blob.write(a);
  }

  private static void serializeInt(Blob blob, int i)
  {
    byte[] a = { (byte)i, (byte)(i>>8), (byte)(i>>16), (byte)(i>>24) };
    blob.write(a);
  }

  private static void serializeString(Blob blob, char c, String s)
  {
    byte[] a;
    int i, l=s.length();
    a = new byte[l];
    for (i=0; i<l; i++)
      a[i] = (byte)s.charAt(i);









    serializeInt(blob, c, a.length);
    blob.write(a);
  }

  private static void serializeString(Blob blob, String s)
  {
    byte[] a;
    int i, l=s.length();
    a = new byte[l];
    for (i=0; i<l; i++)
      a[i] = (byte)s.charAt(i);









    serializeInt(blob, a.length);
    blob.write(a);
  }
  
  private static void serializeObject(Blob blob, Object obj) throws IOException
  {
    if (obj==null)
    {
      final byte[] a = { '0' };
      blob.write(a);
      return;
    }

    if (obj instanceof Byte)
    {
      byte[] a = { 'b', ((Byte)obj).byteValue() };
      blob.write(a);
    }
    else if (obj instanceof Short)
    {
      short s = ((Short)obj).shortValue();
      byte[] a = { 'j', (byte)s, (byte)(s>>8) };
      blob.write(a);
    }
    else if (obj instanceof Integer)
    {
      int i = ((Integer)obj).intValue();
      byte[] a = { 'i', (byte)i, (byte)(i>>8), (byte)(i>>16), (byte)(i>>24) };
      blob.write(a);
    }
    else if (obj instanceof Long)
    {
      long l = ((Long)obj).longValue();
      byte[] a = { 'l', (byte)l, (byte)(l>>8), (byte)(l>>16), (byte)(l>>24),
                   (byte)(l>>32), (byte)(l>>40), (byte)(l>>48), (byte)(l>>56) };
      blob.write(a);
    }
    else if (obj instanceof Boolean)
    {
      byte[] a = { 't', (byte)(((Boolean)obj).booleanValue() ? 1 : 0) };
      blob.write(a);
    }
    else if (obj instanceof TypedContainer.UnsignedByte)
    {
      byte[] a = { 'B', ((TypedContainer.UnsignedByte)obj).byteValue() };
      blob.write(a);
    }
    else if (obj instanceof TypedContainer.UnsignedShort)
    {
      short s = ((TypedContainer.UnsignedShort)obj).shortValue();
      byte[] a = { 'J', (byte)s, (byte)(s>>8) };
      blob.write(a);
    }
    else if (obj instanceof TypedContainer.UnsignedInteger)
    {
      int i = ((TypedContainer.UnsignedInteger)obj).intValue();
      byte[] a = { 'I', (byte)i, (byte)(i>>8), (byte)(i>>16), (byte)(i>>24) };
      blob.write(a);
    }
    else if (obj instanceof TypedContainer.UnsignedLong)
    {
      long l = ((TypedContainer.UnsignedLong)obj).longValue();
      byte[] a = { 'L', (byte)l, (byte)(l>>8), (byte)(l>>16), (byte)(l>>24),
                   (byte)(l>>32), (byte)(l>>40), (byte)(l>>48), (byte)(l>>56) };
      blob.write(a);
    }
    else if (obj instanceof Float)
    {
      int i = Float.floatToRawIntBits(((Float)obj).floatValue());
      byte[] a = { 'f', (byte)i, (byte)(i>>8), (byte)(i>>16), (byte)(i>>24) };
      blob.write(a);
    }
    else if (obj instanceof Double)
    {
      long l = Double.doubleToRawLongBits(((Double)obj).doubleValue());
      byte[] a = { 'd', (byte)l, (byte)(l>>8), (byte)(l>>16), (byte)(l>>24),
                   (byte)(l>>32), (byte)(l>>40), (byte)(l>>48), (byte)(l>>56) };
      blob.write(a);
    }
    else if (obj instanceof Character)
    {
      int v=((Character)obj).charValue();
      if (v<0x100)
      {
        byte[] a = { 'c', (byte)((Character)obj).charValue() };
        blob.write(a);
      }
      else
      {
        byte[] a = { 'C', (byte)v, (byte)(v>>8) };
        blob.write(a);
      }
    }
    else if (obj instanceof GUID)
    {
      byte[] a = { 'g' };
      blob.write(a);
      blob.write( ((GUID)obj).getBytes() );
    }
    else if (obj instanceof String)
    {
      serializeString(blob, 's', (String)obj);
    }
    else if (obj instanceof TypedContainer.JavaXDR)
    {
      byte[] a=((TypedContainer.JavaXDR)obj).getBuffer();
      serializeInt(blob, 'x', a.length);
      blob.write(a);
    }
    else if (obj instanceof TypedArray)
    {
      TypedArray a=(TypedArray)obj;
      Iterator iter=a.iterator();
      serializeInt(blob, 'A', a.size());
      String cn=a.getActiveClassName();
      serializeString(blob, cn!=null ? cn : "");
      while (iter.hasNext())
        serializeObject(blob, iter.next());
    }
    else if (obj instanceof TypedMap)
    {
      TypedMap map=(TypedMap)obj;
      serializeInt(blob, 'M', map.size());
      String cn=map.getActiveClassName();
      serializeString(blob, cn!=null ? cn : "");
      for (Iterator i=map.keyIterator(); i.hasNext();)
      {
        String key=(String)i.next();
        serializeString(blob, (String)key);
        serializeObject(blob, map.get(key));
      }
    }
    else if (obj instanceof Blob)
    {
      Blob src=(Blob)obj;
      serializeInt(blob, 'N', src.size());
      blob.write(src);
    }
  }

}
