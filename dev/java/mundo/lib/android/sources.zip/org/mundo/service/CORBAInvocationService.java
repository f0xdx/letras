/*
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is MundoCore Java.
 *
 * The Initial Developer of the Original Code is Telecooperation Group,
 * Department of Computer Science, Darmstadt University of Technology.
 * Portions created by the Initial Developer are
 * Copyright (C) 2001-2008 the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 * Erwin Aitenbichler
 */

package org.mundo.service;


import java.util.HashMap;
import java.util.Iterator;

import javax.rmi.CORBA.Stub;
import org.omg.CORBA.ORB;
import org.omg.CORBA.Any;
import org.omg.CORBA.TCKind;
import org.omg.CORBA.TypeCode;
import org.omg.CORBA.portable.Delegate;
import org.omg.CORBA.portable.ObjectImpl;
import org.omg.CORBA.portable.InputStream;
import org.omg.CORBA.portable.OutputStream;
import org.omg.CORBA.portable.ResponseHandler;
import org.omg.CORBA.portable.InvokeHandler;
import org.omg.CosNaming.NamingContextExt;
import org.omg.CosNaming.NamingContextExtHelper;
import org.omg.PortableServer.Servant;
import org.omg.PortableServer.POA;
import org.omg.PortableServer.POAHelper;
import org.omg.CORBA.ORBPackage.InvalidName;

import org.mundo.rt.IBCLProvider;
import org.mundo.rt.Service;
import org.mundo.rt.IMessageHandler;
import org.mundo.rt.Message;
import org.mundo.rt.TypedMap;
import org.mundo.rt.Publisher;
import org.mundo.rt.Subscriber;
import org.mundo.rt.ProtocolStack;
import org.mundo.rt.ObjectAdapter;
import org.mundo.net.RMCService;
import org.mundo.reflect.MInterface;
import org.mundo.reflect.MMethod;
import org.mundo.reflect.MParam;

import org.mundo.rt.Logger;



/**
 * This service bridges from RMC to CORBA. The service accepts RMC invocations
 * and performs calls as a CORBA client.
 *
 * If CORBA bridging is used, exactly one instance of this service must be
 * created. A missing service leads to runtime exceptions and the behaviour
 * is undefined if multiple instances exist.
 */
public class CORBAInvocationService
       extends Service
       implements IMessageHandler, IBCLProvider.ISignal
{
  /**
   * Initializes a new <code>CORBAInvocationService</code>.
   */
  public CORBAInvocationService()
  {
    singleton=this;
  }
  /**
   * Returns the singleton instance of this service. If RMI bridging is used,
   * exactly one instance of this service should be created. If the service was
   * never instantiated (from the configuration file), then the return value is
   * <code>null</code>.
   * @return  the singleton instance of this service, or <code>null</code>
   *          in case of error.
   */
  public static CORBAInvocationService getInstance()
  {
    return singleton;
  }
  /**
   * Called when a message is passed down from a higher protocol handler.
   */
  public boolean down(Message msg) // IMessageHandler
  {
//    System.out.println(msg);

    // Get payload and address information from Message
    TypedMap map=msg.getMap();
    String channelName=msg.getMap("ers", "param").getString("channel");
    TypedMap opts=msg.getHandler().getOptions();

    // Lookup imported object
    Import imp = (Import)imports.get(channelName);
    if (imp==null)
    {
      String objectName;
      org.omg.CORBA.Object objRef;
      try
      {
        // Perform a naming lookup
        objectName=opts.getString("objectName");
        if (orb==null)
          createORB();

        // Resolve the Object Reference in Naming
        objRef=ncRef.resolve_str(objectName);
      }
      catch(java.util.NoSuchElementException x)
      {
        log.severe("the protocol handler option 'objectName' must specify the object name for the NameService lookup");
        return false;
      }
      catch(Exception x)
      {
        log.exception(x);
        return false;
      }
      log.fine("object "+objectName+"="+objRef.toString()+": lookup successful");
      imp=new Import(channelName, objectName, objRef);
      imports.put(channelName, imp);
    }

    ObjectImpl oi=(ObjectImpl)imp.objRef;
    try
    {
      // Create a new CORBA invocation request
      OutputStream out=oi._request(map.getString("request"), true);

      // Write parameters
      String ptypesStr=map.getString("ptypes");
      if (ptypesStr!=null && ptypesStr.length()>0)
      {
        String[] ptypes=ptypesStr.split(",");
        for (int i=0; i<ptypes.length; i++)
          write(out, ptypes[i], map.get("p"+i));
      }

      // Perform the call
      InputStream in=oi._invoke(out);
      try
      {
        if (!map.getBoolean("oneWay", false))
        {
          // Create response message
          TypedMap rmap=new TypedMap();
  
          // Read return value
          String rtype=map.getString("rtype", null);
          if (rtype!=null)
          {
            if (rtype.length()>0)
              rmap.put("value", read(in, rtype));
          }
          else
          {
            log.warning("missing rtype in request - can't unmarshal return value");
          }
  
          // Send response
          rmap.put("callId", map.get("callId"));
          rmap.put("request", map.getString("request")+"Reply");
          Message rmsg=new Message(rmap);
          session.send(map.getGUID("sessionId"), rmsg);
        }
      }
      finally
      {
        oi._releaseReply(in);
      }
    }
    catch(Exception x)
    {
      log.exception(x);
      return false;
    }
    return true;
  }
  /**
   * Called when a message is passed up from a lower protocol handler.
   */
  public boolean up(Message msg) // IMessageHandler
  {
    return false;
  }
  /**
   *
   */
  public void publisherAdded(Publisher p) // IBCLProvider.ISignal
  {
    log.fine("publisherAdded "+p.toString());
  }
  /**
   *
   */
  public void publisherRemoved(Publisher p) // IBCLProvider.ISignal
  {
    log.fine("publisherRemoved "+p.toString());
  }
  /**
   *
   */
  public void subscriberAdded(Subscriber s) // IBCLProvider.ISignal
  {
    log.fine("subscriberAdded "+s.toString());
    ProtocolStack.Handler h=s.getChannel().getStack().get(0);
    String channelName=s.getChannel().getName();
    TypedMap opts=h.getOptions();

    Export exp = (Export)exports.get(channelName);
    if (exp==null)
    {
      try
      {
        if (orb==null)
          createORB();
        if (rootPOA==null)
        {
          // get reference to rootpoa & activate the POAManager
          rootPOA=POAHelper.narrow(orb.resolve_initial_references("RootPOA"));
          rootPOA.the_POAManager().activate();
        }

        log.fine("bind "+opts.toString());
        ServerStub stub=new ServerStub(channelName, (Class)opts.get("interface"),
                                       (MInterface)opts.get("IDL"));

        // get object reference from the servant
        org.omg.CORBA.Object ref=rootPOA.servant_to_reference(stub);

        // bind the Object Reference in Naming
        ncRef.rebind(ncRef.to_name(opts.getString("objectName")), ref);

        exp=new Export(channelName);
        exports.put(channelName, exp);
      }
      catch(java.util.NoSuchElementException x)
      {
        log.severe("the protocol handler option 'objectName' must specify the "+
                   "object name for the bind and the option 'interface' point "+
                   "to the IDL interface");
      }
      catch(Exception x)
      {
        log.exception(x);
      }
    }
  }
  /**
   *
   */
  public void subscriberRemoved(Subscriber s) // IBCLProvider.ISignal
  {
    log.fine("subscriberRemoved "+s.toString());
  }
  /**
   * Returns the local server object for the given name.
   * @param name  the channel name of the object.
   * @return  the local object.
   */
  public Object getLocalObj(String name)
  {
    log.fine("getLocalObj "+name);
    ObjectAdapter oa=RMCService.getInstance().getObjectAdapter(name);
    if (oa==null)
      return null;
    return oa.getTarget();
  }
  private void createORB() throws InvalidName
  {
    // Create and initialize the ORB
    orb=ORB.init(new String[0], null);

    // Get the root naming context
    org.omg.CORBA.Object objRef=orb.resolve_initial_references("NameService");

    // Use NamingContextExt instead of NamingContext. This is 
    // part of the Interoperable naming Service.  
    ncRef=NamingContextExtHelper.narrow(objRef);
  }

  /**
   * Writes a value to a CDR marshal stream.
   */
  private void write(OutputStream strm, String tc, Object value)
  {
    if (tc.length()==1)
    {
      switch (tc.charAt(0))
      {
        case 'v':
          return;
        case 'b':
          strm.write_octet(((Byte)value).byteValue());
          return;
        case 'c':
          strm.write_char(((Character)value).charValue());
          return;
        case 'j':
          strm.write_short(((Short)value).shortValue());
          return;
        case 'i':
          strm.write_long(((Integer)value).intValue());
          return;
        case 'l':
          strm.write_longlong(((Long)value).longValue());
          return;
        case 'f':
          strm.write_float(((Float)value).floatValue());
          return;
        case 'd':
          strm.write_double(((Double)value).doubleValue());
          return;
        case 't':
          strm.write_boolean(((Boolean)value).booleanValue());
          return;
        case 's':
          strm.write_wstring((String)value);
          return;
      }
    }
    throw new UnsupportedOperationException("write operation for type '"+tc+"' not implemented");
  }
  /**
   * Reads a value from a CDR marshal stream.
   */
  private Object read(InputStream in, String tc)
  {
    if (tc.length()==1)
    {
      switch (tc.charAt(0))
      {
        case 'v':
          return null;
        case 'b':
          return new Byte(in.read_octet());
        case 'c':
          return new Character(in.read_char());
        case 'j':
          return new Short(in.read_short());
        case 'i':
          return new Integer(in.read_long());
        case 'l':
          return new Long(in.read_longlong());
        case 'f':
          return new Float(in.read_float());
        case 'd':
          return new Double(in.read_double());
        case 't':
          return new Boolean(in.read_boolean());
        case 's':
          return in.read_wstring();
      }
    }
    throw new UnsupportedOperationException("read operation for type '"+tc+"' not implemented");
  }

  private class ServerStub extends Servant implements InvokeHandler
  {
    ServerStub(String objName, Class ifc, MInterface idl)
    {
      this.objName=objName;
      this.ifc=ifc;
      this.idl=idl;
      idlID="IDL:"+idl.getPackage().getName()+"/"+idl.getName()+":1.0";
      log.fine("new server stub: "+idlID);
    }
    public OutputStream _invoke(String method, InputStream in, ResponseHandler rh)
    {
      // Build request
      MMethod mtd=idl.getMethod(method);
      TypedMap req=new TypedMap();
      req.put("interface", ifc.getName());
      req.put("request", method);
      req.put("ptypes", mtd.getParamTypeCode());
      String rtype=mtd.getReturnTypeCode();
      req.put("rtype", rtype);
      int i=0;
      for (MParam param : mtd.getParams())
      {




        req.put("p"+(i++), read(in, param.getType().getCode()));
      }

      // Invoke method
      log.fine("invoke: "+req);
      TypedMap resp=RMCService.getInstance().getObjectAdapter(objName).invoke(req);

      // Marshall response
      OutputStream out=rh.createReply();
      if (rtype.length()>0)
        write(out, rtype, resp.get("value"));
      return out;
    }
    public String[] _all_interfaces(POA poa, byte[] objectId)
    {
      return new String[] { idlID };
    }
    String objName;
    Class ifc;
    String idlID;
    MInterface idl;
  }

  private static class Import
  {
    Import(String cn, String uri, org.omg.CORBA.Object or)
    {
      channelName=cn;
      objectURI=uri;
      objRef=or;
    }
    String  channelName;
    String  objectURI;
    org.omg.CORBA.Object objRef;
  }

  private static class Export
  {
    Export(String cn)
    {
      channelName=cn;
    }
    String  channelName;
  }

  private HashMap<String,Import> imports = new HashMap<String,Import>();
  private HashMap<String,Export> exports = new HashMap<String,Export>();



  private ORB orb;
  private NamingContextExt ncRef;
  private POA rootPOA;
  private static CORBAInvocationService singleton;
  private static Logger log=Logger.getLogger("corba");
}
