/*
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is MundoCore Java.
 *
 * The Initial Developer of the Original Code is Telecooperation Group,
 * Department of Computer Science, Darmstadt University of Technology.
 * Portions created by the Initial Developer are
 * Copyright (C) 2001-2008 the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 * Erwin Aitenbichler
 */

package org.mundo.reflect;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

/**
 * Objects of this class represent packages.
 * @author Erwin Aitenbichler
 */
public class MPackage extends MMeta
{
  /**
   * Initializes a new package.
   * @param name  the package name.
   */
  public MPackage(String name)
  {
    this.name=name;
  }
  /**
   * Returns the package name.
   */
  public String getName()
  {
    return name;
  }
  /**
   * Adds an interface to the package.
   * @param ifc  the interface object.
   */
  public void addInterface(MInterface ifc)
  {
    ifc.setPackage(this);
    interfaces.add(ifc);
    interfaceMap.put(ifc.getName(), ifc);
  }
  /**
   * Returns the list of interfaces. Do not modify the returned list.
   * @return  the list of interfaces.
   */
  public ArrayList<MInterface> getInterfaces()


  {
    return interfaces;
  }
  /**
   * Returns the interface with the specified name.
   * @return  the interface object, or <code>null</code> if no interface by that
   *          name exists.
   */
  public MInterface getInterface(String name)
  {
    return (MInterface)interfaceMap.get(name);
  }
  /**
   * Returns a string representation of this object.
   */
  public String toString()
  {
    StringBuffer sb=new StringBuffer();
    sb.append("package ").append(name).append(" {\n");
    for (MInterface ifc : interfaces)
    {




      sb.append(ifc.toString());
      sb.append("\n");
    }
    sb.append("}");
    return sb.toString();
  }

  private String name;
  private ArrayList<MInterface> interfaces=new ArrayList<MInterface>();
  private HashMap<String,MInterface> interfaceMap=new HashMap<String,MInterface>();



}
