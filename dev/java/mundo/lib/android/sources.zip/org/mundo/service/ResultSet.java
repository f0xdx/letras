/*
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is MundoCore Java.
 *
 * The Initial Developer of the Original Code is Telecooperation Group,
 * Department of Computer Science, Darmstadt University of Technology.
 * Portions created by the Initial Developer are
 * Copyright (C) 2001-2008 the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 * Erwin Aitenbichler
 */

package org.mundo.service;

import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;
import org.mundo.rt.IReceiver;
import org.mundo.rt.Message;
import org.mundo.rt.MessageContext;
import org.mundo.rt.Logger;
import org.mundo.rt.Session;
import org.mundo.rt.DoObject;
import org.mundo.rt.GUID;
import org.mundo.rt.Signal;
import org.mundo.rt.TypedMap;
import org.mundo.net.routing.IRoutingService;
import org.mundo.filter.TypedMapFilter;




/**
 * <p>Encapsulates the result of a service query. Instances of <code>ResultSet</code>
 * are returned by the query functions of <code>ServiceManager</code>
 * and are usually not instantiated directly from client code.</p>
 *
 * <p><b>Loggers:</b> svcrs</p>
 *
 * @see ServiceManager
 * @author Erwin Aitenbichler
 */
public class ResultSet implements Iterable<ServiceInfo>, IReceiver, IRoutingService.IConn, org.mundo.rt.IEmits /*emits ResultSet.ISignal*/
{
  /**
   * Initializes a new result set.
   */
  public ResultSet(Session s)
  {
    session = s;
    // monitor coming and leaving peers
    Signal.connect("rt", IRoutingService.IConn.class, this);
  }
  /**
   * Stops updating of the result set.
   */
  public void release()
  {
    Signal.disconnect(IRoutingService.IConn.class, this);
    // TODO: disconnectAllReceivers
    // TODO: unsubscribe
  }
  /**
   * Returns all elements of the result set.
   */
  public List getList()
  {
    return list;
  }
  /**
   * Returns an iterator for the ServiceInfo elements contained in this result set.
   */
  public Iterator<ServiceInfo> iterator()
  {
    return list.iterator();
  }
  /**
   * Returns a string representation of this result set.
   */
  public String toString()
  {
    return list.toString();
  }
  /**
   * Internal use only. Sets the filter associated with this result set.
   */
  public void setFilter(TypedMapFilter f)
  {
    filter = f;
  }
  /**
   * Internal use only. Gets the filter associated with this result set.
   */
  TypedMapFilter getFilter()
  {
    return filter;
  }
  
  public synchronized void received(Message msg, MessageContext ctx) // IReceiver
  {
    try
    {
      ServiceInfo si = (ServiceInfo)msg.getObject();

      // find the received ServiceInfo in the list
      int n = -1;
      int s = list.size();
      for (int i=0; i<s; i++)
      {
        if (list.get(i).guid.equals(si.guid))
        {
          n = i;
          break;
        }
      }

      // Remote object references received through normal messages are
      // unbound. For that reason, we must bind references to the target
      // session before we can use them.
      if (session!=null && si.doService!=null)
      {
        // create a copy of ServiceInfo before modifying it, because it
        // might be used by others as well
        si = new ServiceInfo(si);
        // create a copy of the remote reference to the service
        si.doService = (DoObject)si.doService.clone();
        // bind the remote reference to the receiver's session
        si.doService._bind(session);
        
        if (si.update == si.UPDATE_PROPCHANGED)
        {
          // If a property change caused this element to become visible in this
          // result set, then change the update type to advertise.
          if (n < 0)
            si.update = si.UPDATE_ADVERTISE;
        }
        else if (si.update == si.UPDATE_PROPCHANGING)
        {
          // If a property change causes this element to become invisible in this
          // result set, then change the update type to unadvertise.
          TypedMap map = msg.getMap("main", "passive").getMap("newObject");
          if (map!=null && filter!=null && !filter.matches(map))
            si.update = si.UPDATE_UNADVERTISE;
        }
      }

      switch (si.update)
      {
        case ServiceInfo.UPDATE_ADVERTISE:
          if (n>=0)
            break;
          log.finer("service + "+si);
          list.add(si);
          log.finest("inserted: offset="+s+", n=1");
          emit.inserted(this, s, 1);
          break;
        case ServiceInfo.UPDATE_UNADVERTISE:
          if (n<0)
            break;
          log.finer("service - "+list.get(n));
          log.finest("removing: offset="+n+", n=1");
          emit.removing(this, n, 1);
          list.remove(n);
          log.finest("removed: offset="+n+", n=1");
          emit.removed(this, n, 1);
          break;
        case ServiceInfo.UPDATE_PROPCHANGING:
          if (n<0)
            break;
          log.finer("service propChanging "+si);
          log.finest("propChanging: offset="+n);
          emit.propChanging(this, n);
          break;
        case ServiceInfo.UPDATE_PROPCHANGED:
          if (n<0)
            break;
          list.set(n, si);
          log.finer("service propChanged "+si);
          log.finest("propChanged: offset="+n);
          emit.propChanged(this, n);
          break;
      }
    }
    catch(Exception x)
    {
      log.exception(x);
    }
  }

  /**
   * Raised when a new node is available.
   * @param id  the GUID of the new node.
   */
  public void nodeAdded(GUID id) // IRoutingService.IConn
  {
  }

  /**
   * Raised when no routes are left to a node.
   * @param id  the GUID of the node lost.
   */
  public synchronized void nodeRemoved(GUID id) // IRoutingService.IConn
  {
    log.fine("node - "+id.shortString());
    int n = 0;
    int first = -1;
    for (int i=0; i<list.size(); i++)
    {
      ServiceInfo si = list.get(i);
      if (id.equals(si.nodeId))
      {
        log.finest("service - "+si);
        if (first<0)
        {
          first = i;
          n = 1;
        }
        else
          n++;
      }
      else if (first>=0)
      {
        log.finest("removing: first="+first+", n="+n);
        emit.removing(this, first, n);
        for (int j=0; j<n; j++)
          list.remove(first);
        log.finest("removed: first="+first+", n="+n);
        emit.removed(this, first, n);
        first = -1;
        i -= n;
        n = 0;
      }
    }
    if (first>=0)
    {
      log.finest("removing: first="+first+", n="+n);
      emit.removing(this, first, n);
      for (int j=0; j<n; j++)
        list.remove(first);
      log.finest("removed: first="+first+", n="+n);
      emit.removed(this, first, n);
    }
  }

  /**
   * Interface defining the events raised by a result set.
   * @author Erwin Aitenbichler
   */
  public interface ISignal
  {
    /**
     * Raised after one or more elements were inserted into the result set.
     * @param offset  index of first new element
     * @param n       number of new elements
     */
    void inserted(ResultSet rs, int offset, int n);
    /**
     * Raised before one or more elements are removed from the result set.
     * @param offset  index of first element that will be removed
     * @param n       number of elements that will be removed
     */
    void removing(ResultSet rs, int offset, int n);
    /**
     * Raised after one or more elements were removed from the result set.
     * @param offset  index of first element removed
     * @param n       number of elements removed
     */
    void removed(ResultSet rs, int offset, int n);
    /**
     * Raised before the properties of an element are changed.
     * @param offset  index of the element that will be changed
     */
    void propChanging(ResultSet rs, int offset);
    /**
     * Raised after the properties of an element were changed.
     * @param offset  index of the element changed.
     */
    void propChanged(ResultSet rs, int offset);
  }
  
  /**
   * An abstract adapter class for receiving events from the signal interface.
   * The methods in this class are empty. This class exists as convenience
   * for creating receiver objects.
   * @author Erwin Aitenbichler
   */
  public static class SignalAdapter implements ISignal
  {
    public void inserted(ResultSet rs, int offset, int n) {}
    public void removing(ResultSet rs, int offset, int n) {}
    public void removed(ResultSet rs, int offset, int n) {}
    public void propChanging(ResultSet rs, int offset) {}
    public void propChanged(ResultSet rs, int offset) {}
  }

  private Session session;
  private TypedMapFilter filter;
  private ArrayList<ServiceInfo> list = new ArrayList<ServiceInfo>();
  private Logger log = Logger.getLogger("svcrs");

  // Generated by mcc
  protected class __EmitStub__ implements ResultSet.ISignal
  {
    public void inserted(ResultSet p0, int p1, int p2) // ResultSet.ISignal
    {
      Object[] a=org.mundo.rt.Signal.getTargets(ResultSet.ISignal.class, ResultSet.this);
      if (a==null) return;
      for (int i=0; i<a.length; i++)
      {
        try
        {
          ((ResultSet.ISignal)a[i]).inserted(p0, p1, p2);
        }
        catch(Exception x)
        {
          org.mundo.rt.Logger.global.exception(x);
        }
      }
    }
    public void removing(ResultSet p0, int p1, int p2) // ResultSet.ISignal
    {
      Object[] a=org.mundo.rt.Signal.getTargets(ResultSet.ISignal.class, ResultSet.this);
      if (a==null) return;
      for (int i=0; i<a.length; i++)
      {
        try
        {
          ((ResultSet.ISignal)a[i]).removing(p0, p1, p2);
        }
        catch(Exception x)
        {
          org.mundo.rt.Logger.global.exception(x);
        }
      }
    }
    public void removed(ResultSet p0, int p1, int p2) // ResultSet.ISignal
    {
      Object[] a=org.mundo.rt.Signal.getTargets(ResultSet.ISignal.class, ResultSet.this);
      if (a==null) return;
      for (int i=0; i<a.length; i++)
      {
        try
        {
          ((ResultSet.ISignal)a[i]).removed(p0, p1, p2);
        }
        catch(Exception x)
        {
          org.mundo.rt.Logger.global.exception(x);
        }
      }
    }
    public void propChanging(ResultSet p0, int p1) // ResultSet.ISignal
    {
      Object[] a=org.mundo.rt.Signal.getTargets(ResultSet.ISignal.class, ResultSet.this);
      if (a==null) return;
      for (int i=0; i<a.length; i++)
      {
        try
        {
          ((ResultSet.ISignal)a[i]).propChanging(p0, p1);
        }
        catch(Exception x)
        {
          org.mundo.rt.Logger.global.exception(x);
        }
      }
    }
    public void propChanged(ResultSet p0, int p1) // ResultSet.ISignal
    {
      Object[] a=org.mundo.rt.Signal.getTargets(ResultSet.ISignal.class, ResultSet.this);
      if (a==null) return;
      for (int i=0; i<a.length; i++)
      {
        try
        {
          ((ResultSet.ISignal)a[i]).propChanged(p0, p1);
        }
        catch(Exception x)
        {
          org.mundo.rt.Logger.global.exception(x);
        }
      }
    }
  }
  private __EmitStub__ emit=new __EmitStub__();
  public boolean isEmitting(Class signal)
  {
    if (ResultSet.ISignal.class.isAssignableFrom(signal)) return true;
    return false;
  }
}
