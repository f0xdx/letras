package org.mundo.service;


/**
 * Automatically generated distributed object class for <code>DebugService</code>.
 * @see org.mundo.service.DebugService
 */
public class DoDebugService extends org.mundo.rt.DoObject
{
  public DoDebugService()
  {
  }
  public DoDebugService(org.mundo.rt.Session session, Object obj) throws org.mundo.rt.RMCException
  {
    _bind(session, obj);
  }
  public DoDebugService(org.mundo.rt.Channel channel) throws org.mundo.rt.RMCException
  {
    _setPublisher(channel.getSession().publish(channel.getZone(), channel.getName()));
  }
  public DoDebugService(org.mundo.rt.DoObject o)
  {
    _assign(o);
  }
  public org.mundo.rt.ServerStub _getServerStub()
  {
    return SrvDebugService._getObject();
  }
  public static DoDebugService _of(org.mundo.rt.Session session, Object obj)
  {
    DoDebugService cs=(DoDebugService)_getDoObject(session, DoDebugService.class, obj);
    if (cs==null)
    {
      cs=new DoDebugService(session, obj);
      _putDoObject(session, obj, cs);
    }
    return cs;
  }
  public static DoDebugService _of(org.mundo.rt.Service s)
  {
    return _of(s.getSession(), s);
  }
  public String _getInterfaceName()
  {
    return "org.mundo.service.DebugService";
  }
  public org.mundo.service.DebugService.NodeInfo getNodeInfo()
  {
    if (localObj!=null) 
    {
      return ((org.mundo.service.DebugService)localObj).getNodeInfo();
    }
    org.mundo.rt.AsyncCall call=getNodeInfo(SYNC);
    return (org.mundo.service.DebugService.NodeInfo)call.getObj();
  }
  public org.mundo.rt.AsyncCall getNodeInfo(Options opt) 
  {
    org.mundo.rt.TypedMap m=new org.mundo.rt.TypedMap();
    m.putString("ptypes", "");
    m.putString("rtype", "org.mundo.service.DebugService$NodeInfo");
    org.mundo.rt.AsyncCall call=new org.mundo.rt.AsyncCall(this, "org.mundo.service.DebugService", "getNodeInfo", m);
    if (opt==ONEWAY)
    {
      call.invokeOneWay();
    }
    else if (opt==SYNC || opt==ASYNC)
    {
      call.invoke();
    }
    if (opt==SYNC)
    {
      try
      {
        if (!call.waitForReply())
        {
          throw call.getException();
        }
      }
      catch(RuntimeException x)
      {
        throw x;
      }
      catch(Exception x)
      {
        throw new org.mundo.rt.RMCException("unexpected exception", x);
      }
    }
    return call;
  }
  
  public java.util.List getConnections()
  {
    if (localObj!=null) 
    {
      return ((org.mundo.service.DebugService)localObj).getConnections();
    }
    org.mundo.rt.AsyncCall call=getConnections(SYNC);
    return (java.util.List)call.getObj();
  }
  public org.mundo.rt.AsyncCall getConnections(Options opt) 
  {
    org.mundo.rt.TypedMap m=new org.mundo.rt.TypedMap();
    m.putString("ptypes", "");
    m.putString("rtype", "java.util.List");
    org.mundo.rt.AsyncCall call=new org.mundo.rt.AsyncCall(this, "org.mundo.service.DebugService", "getConnections", m);
    if (opt==ONEWAY)
    {
      call.invokeOneWay();
    }
    else if (opt==SYNC || opt==ASYNC)
    {
      call.invoke();
    }
    if (opt==SYNC)
    {
      try
      {
        if (!call.waitForReply())
        {
          throw call.getException();
        }
      }
      catch(RuntimeException x)
      {
        throw x;
      }
      catch(Exception x)
      {
        throw new org.mundo.rt.RMCException("unexpected exception", x);
      }
    }
    return call;
  }
  
  public java.util.List getServices()
  {
    if (localObj!=null) 
    {
      return ((org.mundo.service.DebugService)localObj).getServices();
    }
    org.mundo.rt.AsyncCall call=getServices(SYNC);
    return (java.util.List)call.getObj();
  }
  public org.mundo.rt.AsyncCall getServices(Options opt) 
  {
    org.mundo.rt.TypedMap m=new org.mundo.rt.TypedMap();
    m.putString("ptypes", "");
    m.putString("rtype", "java.util.List");
    org.mundo.rt.AsyncCall call=new org.mundo.rt.AsyncCall(this, "org.mundo.service.DebugService", "getServices", m);
    if (opt==ONEWAY)
    {
      call.invokeOneWay();
    }
    else if (opt==SYNC || opt==ASYNC)
    {
      call.invoke();
    }
    if (opt==SYNC)
    {
      try
      {
        if (!call.waitForReply())
        {
          throw call.getException();
        }
      }
      catch(RuntimeException x)
      {
        throw x;
      }
      catch(Exception x)
      {
        throw new org.mundo.rt.RMCException("unexpected exception", x);
      }
    }
    return call;
  }
  
  public org.mundo.service.DebugService.ServiceEntry getServiceInfo(org.mundo.rt.GUID p0)
  {
    if (localObj!=null) 
    {
      return ((org.mundo.service.DebugService)localObj).getServiceInfo(p0);
    }
    org.mundo.rt.AsyncCall call=getServiceInfo(p0, SYNC);
    return (org.mundo.service.DebugService.ServiceEntry)call.getObj();
  }
  public org.mundo.rt.AsyncCall getServiceInfo(org.mundo.rt.GUID p0, Options opt) 
  {
    org.mundo.rt.TypedMap m=new org.mundo.rt.TypedMap();
    m.putString("ptypes", "g");
    m.putString("rtype", "org.mundo.service.DebugService$ServiceEntry");
    m.putObject("p0", p0);
    org.mundo.rt.AsyncCall call=new org.mundo.rt.AsyncCall(this, "org.mundo.service.DebugService", "getServiceInfo", m);
    if (opt==ONEWAY)
    {
      call.invokeOneWay();
    }
    else if (opt==SYNC || opt==ASYNC)
    {
      call.invoke();
    }
    if (opt==SYNC)
    {
      try
      {
        if (!call.waitForReply())
        {
          throw call.getException();
        }
      }
      catch(RuntimeException x)
      {
        throw x;
      }
      catch(Exception x)
      {
        throw new org.mundo.rt.RMCException("unexpected exception", x);
      }
    }
    return call;
  }
  
  public java.util.List getERSImports()
  {
    if (localObj!=null) 
    {
      return ((org.mundo.service.DebugService)localObj).getERSImports();
    }
    org.mundo.rt.AsyncCall call=getERSImports(SYNC);
    return (java.util.List)call.getObj();
  }
  public org.mundo.rt.AsyncCall getERSImports(Options opt) 
  {
    org.mundo.rt.TypedMap m=new org.mundo.rt.TypedMap();
    m.putString("ptypes", "");
    m.putString("rtype", "java.util.List");
    org.mundo.rt.AsyncCall call=new org.mundo.rt.AsyncCall(this, "org.mundo.service.DebugService", "getERSImports", m);
    if (opt==ONEWAY)
    {
      call.invokeOneWay();
    }
    else if (opt==SYNC || opt==ASYNC)
    {
      call.invoke();
    }
    if (opt==SYNC)
    {
      try
      {
        if (!call.waitForReply())
        {
          throw call.getException();
        }
      }
      catch(RuntimeException x)
      {
        throw x;
      }
      catch(Exception x)
      {
        throw new org.mundo.rt.RMCException("unexpected exception", x);
      }
    }
    return call;
  }
  
  public java.util.List getERSExports()
  {
    if (localObj!=null) 
    {
      return ((org.mundo.service.DebugService)localObj).getERSExports();
    }
    org.mundo.rt.AsyncCall call=getERSExports(SYNC);
    return (java.util.List)call.getObj();
  }
  public org.mundo.rt.AsyncCall getERSExports(Options opt) 
  {
    org.mundo.rt.TypedMap m=new org.mundo.rt.TypedMap();
    m.putString("ptypes", "");
    m.putString("rtype", "java.util.List");
    org.mundo.rt.AsyncCall call=new org.mundo.rt.AsyncCall(this, "org.mundo.service.DebugService", "getERSExports", m);
    if (opt==ONEWAY)
    {
      call.invokeOneWay();
    }
    else if (opt==SYNC || opt==ASYNC)
    {
      call.invoke();
    }
    if (opt==SYNC)
    {
      try
      {
        if (!call.waitForReply())
        {
          throw call.getException();
        }
      }
      catch(RuntimeException x)
      {
        throw x;
      }
      catch(Exception x)
      {
        throw new org.mundo.rt.RMCException("unexpected exception", x);
      }
    }
    return call;
  }
  
  public java.util.List getLogMessages()
  {
    if (localObj!=null) 
    {
      return ((org.mundo.service.DebugService)localObj).getLogMessages();
    }
    org.mundo.rt.AsyncCall call=getLogMessages(SYNC);
    return (java.util.List)call.getObj();
  }
  public org.mundo.rt.AsyncCall getLogMessages(Options opt) 
  {
    org.mundo.rt.TypedMap m=new org.mundo.rt.TypedMap();
    m.putString("ptypes", "");
    m.putString("rtype", "java.util.List");
    org.mundo.rt.AsyncCall call=new org.mundo.rt.AsyncCall(this, "org.mundo.service.DebugService", "getLogMessages", m);
    if (opt==ONEWAY)
    {
      call.invokeOneWay();
    }
    else if (opt==SYNC || opt==ASYNC)
    {
      call.invoke();
    }
    if (opt==SYNC)
    {
      try
      {
        if (!call.waitForReply())
        {
          throw call.getException();
        }
      }
      catch(RuntimeException x)
      {
        throw x;
      }
      catch(Exception x)
      {
        throw new org.mundo.rt.RMCException("unexpected exception", x);
      }
    }
    return call;
  }
  
  public void shutdownNode()
  {
    if (localObj!=null) 
    {
      ((org.mundo.service.DebugService)localObj).shutdownNode();
      return;
    }
    shutdownNode(SYNC);
  }
  public org.mundo.rt.AsyncCall shutdownNode(Options opt) 
  {
    org.mundo.rt.TypedMap m=new org.mundo.rt.TypedMap();
    m.putString("ptypes", "");
    m.putString("rtype", "");
    org.mundo.rt.AsyncCall call=new org.mundo.rt.AsyncCall(this, "org.mundo.service.DebugService", "shutdownNode", m);
    if (opt==ONEWAY)
    {
      call.invokeOneWay();
    }
    else if (opt==SYNC || opt==ASYNC)
    {
      call.invoke();
    }
    if (opt==SYNC)
    {
      try
      {
        if (!call.waitForReply())
        {
          throw call.getException();
        }
      }
      catch(RuntimeException x)
      {
        throw x;
      }
      catch(Exception x)
      {
        throw new org.mundo.rt.RMCException("unexpected exception", x);
      }
    }
    return call;
  }
  
  public org.mundo.rt.TypedMap getNodeConfig()
  {
    if (localObj!=null) 
    {
      return ((org.mundo.service.DebugService)localObj).getNodeConfig();
    }
    org.mundo.rt.AsyncCall call=getNodeConfig(SYNC);
    return (org.mundo.rt.TypedMap)call.getObj();
  }
  public org.mundo.rt.AsyncCall getNodeConfig(Options opt) 
  {
    org.mundo.rt.TypedMap m=new org.mundo.rt.TypedMap();
    m.putString("ptypes", "");
    m.putString("rtype", "org.mundo.rt.TypedMap");
    org.mundo.rt.AsyncCall call=new org.mundo.rt.AsyncCall(this, "org.mundo.service.DebugService", "getNodeConfig", m);
    if (opt==ONEWAY)
    {
      call.invokeOneWay();
    }
    else if (opt==SYNC || opt==ASYNC)
    {
      call.invoke();
    }
    if (opt==SYNC)
    {
      try
      {
        if (!call.waitForReply())
        {
          throw call.getException();
        }
      }
      catch(RuntimeException x)
      {
        throw x;
      }
      catch(Exception x)
      {
        throw new org.mundo.rt.RMCException("unexpected exception", x);
      }
    }
    return call;
  }
  
  public boolean crippleBlockSendsTo(org.mundo.rt.GUID p0)
  {
    if (localObj!=null) 
    {
      return ((org.mundo.service.DebugService)localObj).crippleBlockSendsTo(p0);
    }
    org.mundo.rt.AsyncCall call=crippleBlockSendsTo(p0, SYNC);
    return call.getMap().getBoolean("value");
  }
  public org.mundo.rt.AsyncCall crippleBlockSendsTo(org.mundo.rt.GUID p0, Options opt) 
  {
    org.mundo.rt.TypedMap m=new org.mundo.rt.TypedMap();
    m.putString("ptypes", "g");
    m.putString("rtype", "t");
    m.putObject("p0", p0);
    org.mundo.rt.AsyncCall call=new org.mundo.rt.AsyncCall(this, "org.mundo.service.DebugService", "crippleBlockSendsTo", m);
    if (opt==ONEWAY)
    {
      call.invokeOneWay();
    }
    else if (opt==SYNC || opt==ASYNC)
    {
      call.invoke();
    }
    if (opt==SYNC)
    {
      try
      {
        if (!call.waitForReply())
        {
          throw call.getException();
        }
      }
      catch(RuntimeException x)
      {
        throw x;
      }
      catch(Exception x)
      {
        throw new org.mundo.rt.RMCException("unexpected exception", x);
      }
    }
    return call;
  }
  
  public void propChanging(org.mundo.rt.Service p0)
  {
    if (localObj!=null) 
    {
      ((org.mundo.rt.Service.IProp)localObj).propChanging(p0);
      return;
    }
    propChanging(p0, SYNC);
  }
  public org.mundo.rt.AsyncCall propChanging(org.mundo.rt.Service p0, Options opt) 
  {
    org.mundo.rt.TypedMap m=new org.mundo.rt.TypedMap();
    m.putString("ptypes", "org.mundo.rt.Service");
    m.putString("rtype", "");
    m.putObject("p0", p0);
    org.mundo.rt.AsyncCall call=new org.mundo.rt.AsyncCall(this, "org.mundo.rt.Service$IProp", "propChanging", m);
    if (opt==ONEWAY)
    {
      call.invokeOneWay();
    }
    else if (opt==SYNC || opt==ASYNC)
    {
      call.invoke();
    }
    if (opt==SYNC)
    {
      try
      {
        if (!call.waitForReply())
        {
          throw call.getException();
        }
      }
      catch(RuntimeException x)
      {
        throw x;
      }
      catch(Exception x)
      {
        throw new org.mundo.rt.RMCException("unexpected exception", x);
      }
    }
    return call;
  }
  
  public void propChanged(org.mundo.rt.Service p0)
  {
    if (localObj!=null) 
    {
      ((org.mundo.rt.Service.IProp)localObj).propChanged(p0);
      return;
    }
    propChanged(p0, SYNC);
  }
  public org.mundo.rt.AsyncCall propChanged(org.mundo.rt.Service p0, Options opt) 
  {
    org.mundo.rt.TypedMap m=new org.mundo.rt.TypedMap();
    m.putString("ptypes", "org.mundo.rt.Service");
    m.putString("rtype", "");
    m.putObject("p0", p0);
    org.mundo.rt.AsyncCall call=new org.mundo.rt.AsyncCall(this, "org.mundo.rt.Service$IProp", "propChanged", m);
    if (opt==ONEWAY)
    {
      call.invokeOneWay();
    }
    else if (opt==SYNC || opt==ASYNC)
    {
      call.invoke();
    }
    if (opt==SYNC)
    {
      try
      {
        if (!call.waitForReply())
        {
          throw call.getException();
        }
      }
      catch(RuntimeException x)
      {
        throw x;
      }
      catch(Exception x)
      {
        throw new org.mundo.rt.RMCException("unexpected exception", x);
      }
    }
    return call;
  }
  
}