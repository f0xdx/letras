/*
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is MundoCore Java.
 *
 * The Initial Developer of the Original Code is Telecooperation Group,
 * Department of Computer Science, Darmstadt University of Technology.
 * Portions created by the Initial Developer are
 * Copyright (C) 2001-2008 the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 * Erwin Aitenbichler
 */

package org.mundo.net.routing;

import java.util.HashMap;

import org.mundo.rt.Channel;
import org.mundo.rt.GUID;
import org.mundo.rt.IReceiver;
import org.mundo.rt.IBCLProvider;
import org.mundo.rt.IMessageHandler;
import org.mundo.rt.Logger;
import org.mundo.rt.Message;
import org.mundo.rt.MessageContext;
import org.mundo.rt.Mundo;
import org.mundo.rt.Publisher;
import org.mundo.rt.SubscriptionParameters;
import org.mundo.rt.Subscriber;
import org.mundo.rt.Session;
import org.mundo.rt.Service;
import org.mundo.rt.TypedArray;
import org.mundo.rt.TypedMap;
import org.mundo.rt.ProtocolStack;
import org.mundo.net.ProtocolCoordinator;




/**
 * <p><code>RSSubscription</code> allows application services to directly
 * interface with routing services.</p>
 *
 * @since 1.0.0
 * @author Erwin Aitenbichler
 */
public class RSSubscription extends SubscriptionParameters
{
  /**
   * Returns a channel object for the specified MIME type.
   */
  public static Channel getChannel(Session session, String mimeType)
  {
    return session.getChannel("rt", "rssub."+mimeType);
  }
  /**
   * Creates a new routing service subscription.
   * @param session  the session object.
   * @param ch  the channel.
   * @return  a subscriber object.
   */  
  public static Subscriber subscribe(Session session, Channel ch)
  {
    String type = ch.getName();
    if (!type.startsWith("rssub."))
      throw new IllegalArgumentException("rssub channel expected");
    type = type.substring(6);
    Subscriber sub = session.subscribe(ch);
    sub.setParam(new RSSubscription(type));
    ProtocolCoordinator.getInstance().registerChannel(ch, RoutingService.class);

    // register protocol handler
    if (handler==null)
      handler = new Handler();
    ProtocolCoordinator.register(type, handler);
    
    return sub;
  }
  /**
   * Creates a new routing service subscription.
   * @param session  the session object.
   * @param ch  the channel.
   * @param rcv  the message receiver.
   * @return  a subscriber object.
   */
  public static Subscriber subscribe(Session session, Channel ch, IReceiver rcv)
  {
    Subscriber sub = subscribe(session, ch);
    sub.setReceiver(rcv);
    sub.enable();
    return sub;
  }
  /**
   * Creates a new routing service publisher.
   * @param session  the session object.
   * @return  a publisher object.
   */ 
  public static Publisher publish(Session session, Channel ch)
  {
    String type = ch.getName();
    if (!type.startsWith("rssub."))
      throw new IllegalArgumentException("rssub channel expected");
    type = type.substring(6);
    if (forwarder==null)
    {
      forwarder = new Forwarder();
      Mundo.registerService(forwarder);
    }
    forwarder.register(ch);
    Publisher pub = session.publish(ch);
    RSSubscription s = new RSSubscription(type);
    pub.setParam(s);
    return pub;
  }
  /**
   * Broadcasts the specified message in the current zone.
   */
  public static void sendToZone(Publisher pub, Message msg)
  {
    SubscriptionParameters sp = pub.getParam();
    if (sp==null)
      throw new IllegalArgumentException("advertisement parameters missing");
    if (!(sp instanceof RSSubscription))
      throw new IllegalArgumentException("advertisement parameters are not of type RSSubscription");
    // clone the message and set the app service's MIME type
    msg = msg.copyFrame();
    msg.setType(((RSSubscription)sp).getMIMEType());

    // create a routing service parameter header for zone broadcast
    TypedMap rp = new TypedMap();
    rp.putString("destType", "zone");
    msg.put("rs", "param", rp);
    
    pub.send(msg);
  }
  /**
   * Sends a source-routing message.
   */
  public static void sendTo(Publisher pub, TypedArray src, Message msg)
  {
    SubscriptionParameters sp = pub.getParam();
    if (sp==null)
      throw new IllegalArgumentException("advertisement parameters missing");
    if (!(sp instanceof RSSubscription))
      throw new IllegalArgumentException("advertisement parameters are not of type RSSubscription");
    // clone the message and set the app service's MIME type
    msg = msg.copyFrame();
    msg.setType(((RSSubscription)sp).getMIMEType());

    // create a routing service parameter header for zone broadcast
    TypedMap rp = new TypedMap();
    rp.putString("destType", "src");
    rp.putArray("src", new TypedArray(src));
    msg.put("rs", "param", rp);

    pub.send(msg);
  }

  /**
   * Initializes a new <code>RSSubscription</code>.
   */
  protected RSSubscription(String mimeType)
  {
    this.mimeType = mimeType;
  }
  /**
   * Returns the MIME type of this subscription or advertisement.
   */
  public String getMIMEType()
  {
    return mimeType;
  }

  private static class Handler
                   implements IMessageHandler, org.mundo.rt.IEmits
                   /*emits IMessageHandler*/
  {
    public boolean down(Message msg) //IMessageHandler
    {
      throw new UnsupportedOperationException();
    }
    public boolean up(Message msg) //IMessageHandler
    {
      TypedMap hdr = msg.getMap("rs", "passive");
      log.finer("rcvd message "+hdr.getString("type"));
      TypedMap amap = msg.getMap("address", "passive");
      amap.putString("channel", "rssub."+hdr.getString("type"));
      return emit.up(msg);
    }
  
  // Generated by mcc
  protected class __EmitStub__ implements IMessageHandler
  {
    public boolean down(Message p0) // IMessageHandler
    {
      Object[] a=org.mundo.rt.Signal.getTargets(IMessageHandler.class, RSSubscription.Handler.this);
      if (a==null) throw new IllegalStateException("signal not connected");
      return ((IMessageHandler)a[0]).down(p0);
    }
    public boolean up(Message p0) // IMessageHandler
    {
      Object[] a=org.mundo.rt.Signal.getTargets(IMessageHandler.class, RSSubscription.Handler.this);
      if (a==null) throw new IllegalStateException("signal not connected");
      return ((IMessageHandler)a[0]).up(p0);
    }
  }
  private __EmitStub__ emit=new __EmitStub__();
  public boolean isEmitting(Class signal)
  {
    if (IMessageHandler.class.isAssignableFrom(signal)) return true;
    return false;
  }
}
  
  private static class Forwarder
                   extends Service
                   implements IReceiver
  {
    @Override
    public void init()
    {
      super.init();
      log.finer("creating Forwarder");
    }
    void register(Channel ch)
    {
      String cn = ch.getName();
      if (subscribers.containsKey(cn))
        return;
      subscribers.put(cn, session.subscribe(ch, this));
    }
    public void received(Message msg, MessageContext ctx)
    {
      // only forward messages coming from local publishers
      if (ctx.publisher==null)
        return;
      SubscriptionParameters sp = ctx.publisher.getParam();
      if (sp==null)
        throw new IllegalArgumentException("advertisement parameters missing");
      if (!(sp instanceof RSSubscription))
        throw new IllegalArgumentException("advertisement parameters are not of type RSSubscription");
      log.fine("forwarding "+((RSSubscription)sp).getMIMEType());
      ProtocolCoordinator.getInstance().firstDown(msg);
    }
    private HashMap<String,Subscriber> subscribers = new HashMap<String,Subscriber>();
  }

  private String mimeType;
  private static Forwarder forwarder;
  private static Handler handler;
  private static final String RS_CHANNEL = "RSSubscription";
  private static Logger log = Logger.getLogger("rssub");
}
