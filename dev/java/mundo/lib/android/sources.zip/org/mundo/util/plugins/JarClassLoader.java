/*
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is MundoCore Java.
 *
 * The Initial Developer of the Original Code is Telecooperation Group,
 * Department of Computer Science, Darmstadt University of Technology.
 * Portions created by the Initial Developer are
 * Copyright (C) 2001-2008 the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 * Erwin Aitenbichler
 */

package org.mundo.util.plugins;

import java.io.ByteArrayOutputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.File;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

import org.mundo.util.plugins.VirtualDirectoryJarFile;

/**
 * A JarClassLoader is a class loader that loads classes out of a JAR file. It
 * is re-written from the scratch so that the Classpath project's class loader
 * does not poison MundoCore.
 * 
 * @author AHa
 */
public class JarClassLoader extends ClassLoader {

  /**
   * This size of a chunk of data to be read
   */
  private static final int CHUNKSIZE = 8192;

  /**
   * Contains the JAR file to load classes from
   */
  private File sourcefile;

  /**
   * Create a new JarClassLoader using a given class loader as the parent
   * instance.
   * 
   * @param parent the parent class loader of this instance
   * @param jarfile the file to load the classes from
   */
  public JarClassLoader(ClassLoader parent, File jarfile) {
    super(parent);
    init(jarfile);
  }

  /**
   * Creates a new class JarClassLoader using the system's default class loader
   * as a parent instance.
   * 
   * @param jarfile the file to load the classes from
   */
  public JarClassLoader(File jarfile) {
    super();
    init(jarfile);
  }

  /**
   * Initializes this class instance
   * 
   * @param jarfile the file this instance should load classes from
   */
  private void init(File jarfile) {
    sourcefile = jarfile;
  }

  /*
   * (non-Javadoc)
   * @see java.lang.ClassLoader#findClass(java.lang.String)
   */
  protected Class<?> findClass(String binaryname) throws ClassNotFoundException {


    // convert the binary name to a valid filename accoding to the Java class
    // placing schematics by substituting dots by slashes and adding the extension ".class"
    String filename = binaryname.replace('.', '/') + ".class";
    JarEntry entry = null; 
    JarFile jarfile = null;

    try {
      jarfile = !sourcefile.isDirectory() ? new JarFile(sourcefile) : new VirtualDirectoryJarFile(sourcefile);
      entry = jarfile.getJarEntry(filename);
    } catch(IOException e) {
      // do nothing, let entry stay null
    }
    if(entry == null)
      throw new ClassNotFoundException(jarfile.getName() + " does not contain " + binaryname);

    byte data[];
    try {
      // try to load the class data
      InputStream in = jarfile.getInputStream(entry);

      try {
        int size = (int)entry.getSize();
        if(size != -1) {
          // size is known - load it as a whole
          data = new byte[size];
          int offset = 0;
          while(offset != size) {
            int len = in.read(data, offset, size - offset);
            if(len == -1)
              throw new IOException("Wrong size of input data");
            offset += len;
          }
        } else {
          // read data in chunks
          byte chunk[] = new byte[CHUNKSIZE];
          int partsize;
          ByteArrayOutputStream buffer = new ByteArrayOutputStream(CHUNKSIZE);
          while((partsize = in.read(chunk)) == CHUNKSIZE)
            buffer.write(chunk, 0, partsize);
          data = buffer.toByteArray();
        }
      } finally {
        in.close();
      }
    } catch(IOException e) {
      throw new ClassNotFoundException("Error when loading " + binaryname + " from " + sourcefile.getName(), e);
    } finally {
      try {
        jarfile.close();
      } catch(IOException e) {
        // do nothing
      }
    }
    
    return defineClass(binaryname, data, 0, data.length);
  }
  
  /* (non-Javadoc)
   * @see java.lang.ClassLoader#getResourceAsStream(java.lang.String)
   */
  public InputStream getResourceAsStream(String name) {
    try {
      final JarFile jarfile = new JarFile(sourcefile);
      JarEntry entry = jarfile.getJarEntry(name);
      return entry != null ? new FilterInputStream(jarfile.getInputStream(entry)) {        
        public void close() throws IOException {
          jarfile.close();
        }
      }: null;
    } catch(IOException e) {
      return null;
    }
  }
}
