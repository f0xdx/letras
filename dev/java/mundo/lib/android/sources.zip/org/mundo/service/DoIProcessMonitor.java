package org.mundo.service;


/**
 * Automatically generated distributed object class for <code>IProcessMonitor</code>.
 * @see org.mundo.service.IProcessMonitor
 */
public class DoIProcessMonitor extends org.mundo.rt.DoObject implements org.mundo.service.IProcessMonitor
{
  public DoIProcessMonitor()
  {
  }
  public DoIProcessMonitor(org.mundo.rt.Session session, Object obj) throws org.mundo.rt.RMCException
  {
    _bind(session, obj);
  }
  public DoIProcessMonitor(org.mundo.rt.Channel channel) throws org.mundo.rt.RMCException
  {
    _setPublisher(channel.getSession().publish(channel.getZone(), channel.getName()));
  }
  public DoIProcessMonitor(org.mundo.rt.DoObject o)
  {
    _assign(o);
  }
  public org.mundo.rt.ServerStub _getServerStub()
  {
    return SrvIProcessMonitor._getObject();
  }
  public static DoIProcessMonitor _of(org.mundo.rt.Session session, Object obj)
  {
    DoIProcessMonitor cs=(DoIProcessMonitor)_getDoObject(session, DoIProcessMonitor.class, obj);
    if (cs==null)
    {
      cs=new DoIProcessMonitor(session, obj);
      _putDoObject(session, obj, cs);
    }
    return cs;
  }
  public static DoIProcessMonitor _of(org.mundo.rt.Service s)
  {
    return _of(s.getSession(), s);
  }
  public String _getInterfaceName()
  {
    return "org.mundo.service.IProcessMonitor";
  }
  public static IProcessMonitor _localObject(IProcessMonitor obj)
  {
    if (obj instanceof org.mundo.rt.DoObject)
    {
      return (IProcessMonitor)((org.mundo.rt.DoObject)obj)._getLocalObject();
    }
    else
    {
      return obj;
    }
  }
  public org.mundo.service.IProcess startProcess(String p0, String p1)
  {
    if (localObj!=null) 
    {
      return ((org.mundo.service.IProcessMonitor)localObj).startProcess(p0, p1);
    }
    org.mundo.rt.AsyncCall call=startProcess(p0, p1, SYNC);
    return (org.mundo.service.IProcess)call.getObj();
  }
  public org.mundo.rt.AsyncCall startProcess(String p0, String p1, Options opt) 
  {
    org.mundo.rt.TypedMap m=new org.mundo.rt.TypedMap();
    m.putString("ptypes", "s,s");
    m.putString("rtype", "org.mundo.service.IProcess");
    m.putString("p0", p0);
    m.putString("p1", p1);
    org.mundo.rt.AsyncCall call=new org.mundo.rt.AsyncCall(this, "org.mundo.service.IProcessMonitor", "startProcess", m);
    if (opt==ONEWAY)
    {
      call.invokeOneWay();
    }
    else if (opt==SYNC || opt==ASYNC)
    {
      call.invoke();
    }
    if (opt==SYNC)
    {
      try
      {
        if (!call.waitForReply())
        {
          throw call.getException();
        }
      }
      catch(RuntimeException x)
      {
        throw x;
      }
      catch(Exception x)
      {
        throw new org.mundo.rt.RMCException("unexpected exception", x);
      }
    }
    return call;
  }
  
  public org.mundo.service.IProcess findProcess(String p0)
  {
    if (localObj!=null) 
    {
      return ((org.mundo.service.IProcessMonitor)localObj).findProcess(p0);
    }
    org.mundo.rt.AsyncCall call=findProcess(p0, SYNC);
    return (org.mundo.service.IProcess)call.getObj();
  }
  public org.mundo.rt.AsyncCall findProcess(String p0, Options opt) 
  {
    org.mundo.rt.TypedMap m=new org.mundo.rt.TypedMap();
    m.putString("ptypes", "s");
    m.putString("rtype", "org.mundo.service.IProcess");
    m.putString("p0", p0);
    org.mundo.rt.AsyncCall call=new org.mundo.rt.AsyncCall(this, "org.mundo.service.IProcessMonitor", "findProcess", m);
    if (opt==ONEWAY)
    {
      call.invokeOneWay();
    }
    else if (opt==SYNC || opt==ASYNC)
    {
      call.invoke();
    }
    if (opt==SYNC)
    {
      try
      {
        if (!call.waitForReply())
        {
          throw call.getException();
        }
      }
      catch(RuntimeException x)
      {
        throw x;
      }
      catch(Exception x)
      {
        throw new org.mundo.rt.RMCException("unexpected exception", x);
      }
    }
    return call;
  }
  
  public boolean uploadFile(String p0, String p1)
  {
    if (localObj!=null) 
    {
      return ((org.mundo.service.IProcessMonitor)localObj).uploadFile(p0, p1);
    }
    org.mundo.rt.AsyncCall call=uploadFile(p0, p1, SYNC);
    return call.getMap().getBoolean("value");
  }
  public org.mundo.rt.AsyncCall uploadFile(String p0, String p1, Options opt) 
  {
    org.mundo.rt.TypedMap m=new org.mundo.rt.TypedMap();
    m.putString("ptypes", "s,s");
    m.putString("rtype", "t");
    m.putString("p0", p0);
    m.putString("p1", p1);
    org.mundo.rt.AsyncCall call=new org.mundo.rt.AsyncCall(this, "org.mundo.service.IProcessMonitor", "uploadFile", m);
    if (opt==ONEWAY)
    {
      call.invokeOneWay();
    }
    else if (opt==SYNC || opt==ASYNC)
    {
      call.invoke();
    }
    if (opt==SYNC)
    {
      try
      {
        if (!call.waitForReply())
        {
          throw call.getException();
        }
      }
      catch(RuntimeException x)
      {
        throw x;
      }
      catch(Exception x)
      {
        throw new org.mundo.rt.RMCException("unexpected exception", x);
      }
    }
    return call;
  }
  
}