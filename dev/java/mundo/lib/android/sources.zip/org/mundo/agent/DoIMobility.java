package org.mundo.agent;


/**
 * Automatically generated distributed object class for <code>IMobility</code>.
 * @see org.mundo.agent.IMobility
 */
public class DoIMobility extends org.mundo.rt.DoObject implements org.mundo.agent.IMobility
{
  public DoIMobility()
  {
  }
  public DoIMobility(org.mundo.rt.Session session, Object obj) throws org.mundo.rt.RMCException
  {
    _bind(session, obj);
  }
  public DoIMobility(org.mundo.rt.Channel channel) throws org.mundo.rt.RMCException
  {
    _setPublisher(channel.getSession().publish(channel.getZone(), channel.getName()));
  }
  public DoIMobility(org.mundo.rt.DoObject o)
  {
    _assign(o);
  }
  public org.mundo.rt.ServerStub _getServerStub()
  {
    return SrvIMobility._getObject();
  }
  public static DoIMobility _of(org.mundo.rt.Session session, Object obj)
  {
    DoIMobility cs=(DoIMobility)_getDoObject(session, DoIMobility.class, obj);
    if (cs==null)
    {
      cs=new DoIMobility(session, obj);
      _putDoObject(session, obj, cs);
    }
    return cs;
  }
  public static DoIMobility _of(org.mundo.rt.Service s)
  {
    return _of(s.getSession(), s);
  }
  public String _getInterfaceName()
  {
    return "org.mundo.agent.IMobility";
  }
  public static IMobility _localObject(IMobility obj)
  {
    if (obj instanceof org.mundo.rt.DoObject)
    {
      return (IMobility)((org.mundo.rt.DoObject)obj)._getLocalObject();
    }
    else
    {
      return obj;
    }
  }
  public void moveTo(String p0)
  {
    if (localObj!=null) 
    {
      ((org.mundo.agent.IMobility)localObj).moveTo(p0);
      return;
    }
    moveTo(p0, SYNC);
  }
  public org.mundo.rt.AsyncCall moveTo(String p0, Options opt) 
  {
    org.mundo.rt.TypedMap m=new org.mundo.rt.TypedMap();
    m.putString("ptypes", "s");
    m.putString("rtype", "");
    m.putString("p0", p0);
    org.mundo.rt.AsyncCall call=new org.mundo.rt.AsyncCall(this, "org.mundo.agent.IMobility", "moveTo", m);
    if (opt==ONEWAY)
    {
      call.invokeOneWay();
    }
    else if (opt==SYNC || opt==ASYNC)
    {
      call.invoke();
    }
    if (opt==SYNC)
    {
      try
      {
        if (!call.waitForReply())
        {
          throw call.getException();
        }
      }
      catch(RuntimeException x)
      {
        throw x;
      }
      catch(Exception x)
      {
        throw new org.mundo.rt.RMCException("unexpected exception", x);
      }
    }
    return call;
  }
  
  public void moveTo(String p0, String p1)
  {
    if (localObj!=null) 
    {
      ((org.mundo.agent.IMobility)localObj).moveTo(p0, p1);
      return;
    }
    moveTo(p0, p1, SYNC);
  }
  public org.mundo.rt.AsyncCall moveTo(String p0, String p1, Options opt) 
  {
    org.mundo.rt.TypedMap m=new org.mundo.rt.TypedMap();
    m.putString("ptypes", "s,s");
    m.putString("rtype", "");
    m.putString("p0", p0);
    m.putString("p1", p1);
    org.mundo.rt.AsyncCall call=new org.mundo.rt.AsyncCall(this, "org.mundo.agent.IMobility", "moveTo", m);
    if (opt==ONEWAY)
    {
      call.invokeOneWay();
    }
    else if (opt==SYNC || opt==ASYNC)
    {
      call.invoke();
    }
    if (opt==SYNC)
    {
      try
      {
        if (!call.waitForReply())
        {
          throw call.getException();
        }
      }
      catch(RuntimeException x)
      {
        throw x;
      }
      catch(Exception x)
      {
        throw new org.mundo.rt.RMCException("unexpected exception", x);
      }
    }
    return call;
  }
  
}