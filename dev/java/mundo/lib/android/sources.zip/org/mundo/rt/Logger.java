/*
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is MundoCore Java.
 *
 * The Initial Developer of the Original Code is Telecooperation Group,
 * Department of Computer Science, Darmstadt University of Technology.
 * Portions created by the Initial Developer are
 * Copyright (C) 2001-2008 the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 * Erwin Aitenbichler
 */

package org.mundo.rt;




import java.util.Iterator;
import java.util.ArrayList;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.IOException;
import java.io.FileOutputStream;
import java.util.Hashtable;
import android.util.Log;

/**
 * <p>Provides a portable logging API.</p>
 *
 * Log levels:
 * <table>
 * <tr><td>SEVERE</td><td>Used only for fatal errors whose occurrence has
 * a significant impact on the functionality of the whole middleware.
 * Because failures must be considered as normal in Ubiquitous Computing
 * and MundoCore is designed to be fault tolerant, almost no error
 * is considered as severe. Severe errors can be considered as something
 * like an OS kernel panic.</td></tr>
 * <tr><td>WARNING</td><td>Use for significant I/O errors or exceptions
 * caused by application services passing wrong parameters.</td></tr>
 * <tr><td>INFO</td><td>Use for major success messages or minor errors,
 * e.g., the loss of a network connection.</td></tr>
 * <tr><td>CONFIG</td><td>Use to inform about hardware configurations
 * or the impact of configuration file settings.</td></tr>
 * <tr><td>FINE</td><td>Use for debugging on method level.</td></tr>
 * <tr><td>FINER</td><td>Use for debug messages inside methods.</td></tr>
 * <tr><td>FINEST</td><td>Used for very detailled information, like full
 * dumps of messages or log messages of background threads that update
 * very frequently, e.g., every second.</td></tr>
 * </table>
 * 
 * <p>Log messages of the levels <code>FINE</code>, <code>FINER</code>, and
 * <code>FINEST</code> are for debugging purposes. They are only generated
 * in checked builds.</p>
 * 
 * @author Erwin Aitenbichler
 */
public class Logger
{
  public static final int OFF     = 0;
  public static final int SEVERE  = 1;
  public static final int WARNING = 2;
  public static final int INFO    = 3;
  public static final int CONFIG  = 4;
  public static final int FINE    = 5;
  public static final int FINER   = 6;
  public static final int FINEST  = 7;
  
  protected Logger(String name)
  {
    this.name=name;
  }
  /**
   * Logs a severe message.
   * @param text  the string message.
   */
  public void severe(String text)
  {
    publish(SEVERE, name, text);
  }
  /**
   * Logs a warning message.
   * @param text  the string message.
   */
  public void warning(String text)
  {
    publish(WARNING, name, text);
  }
  /**
   * Logs an information message.
   * @param text  the string message.
   */
  public void info(String text)
  {
    publish(INFO, name, text);
  }
  /**
   * Logs a configuration message.
   * @param text  the string message.
   */
  public void config(String text)
  {
    publish(CONFIG, name, text);
  }
  /**
   * Logs a FINE debug message.
   * @param text  the string message.
   */
  public void fine(String text)
  {
    publish(FINE, name, text);
  }
  /**
   * Logs a FINER debug message.
   * @param text  the string message.
   */
  public void finer(String text)
  {
    publish(FINER, name, text);
  }
  /**
   * Logs a FINEST debug message.
   * @param text  the string message.
   */
  public void finest(String text)
  {
    publish(FINEST, name, text);
  }
  public void log(int level, String msg, Throwable x)
  {
    StringBuffer sb=new StringBuffer();
    sb.append(msg).append(": ").append(x.toString());
    StackTraceElement[] list=x.getStackTrace();
    for (int i=0; i<list.length; i++)
    {
      sb.append("\n");
      sb.append(list[i].toString());
    }
    publish(level, name, sb.toString());
  }
  /**
   * Logs an exception with the level SEVERE.
   * @param x  the throwable to log.
   */
  public void exception(Throwable x)
  {
    log(SEVERE, "", x);
  }
  public void dump(byte[] b)
  {
    StringBuffer sb=new StringBuffer();
    for (int i=0; i<b.length; i++)
    {
      if (b[i]>=32 && b[i]<=127)
        sb.append((char)b[i]);
      else
      {
        sb.append("\\");
        sb.append(Integer.toString(b[i]&0xff));
      }
    }
    publish(FINEST, name, sb.toString());
  }
  public void trace(int line)
  {
    publish(FINEST, name, "line "+line);
  }
  private synchronized void publish(int level, String category, String text)
  {
    if (handlers==null)
      global.publish(level, category, text);
    else
    {
      for (IHandler h : handlers)
      {








        h.publish(new LogEntry(this, level, category, text));
      }
    }
  }
  public void addHandler(IHandler handler)
  {
    if (handlers==null)
      handlers = new ArrayList<IHandler>();
    handlers.add(handler);








  }
  public void removeHandler(IHandler handler)
  {
    if (!handlers.remove(handler))


      throw new IllegalArgumentException("no such handler");
  }
  public static Logger getLogger(String name)
  {
    if ("global".equals(name))
      return global;
    Logger l=(Logger)loggers.get(name);
    if (l==null)
    {
      l=new Logger(name);
      loggers.put(name, l);
    }
    return l;
  }
  public static Logger getLogger(Class cls)
  {
    return getLogger(cls.getName());
  }
  public String getName()
  {
    return name;
  }

  /**
   * Implement this interface to receive log data.
   */
  public interface IHandler
  {
    public void publish(LogEntry entry);
  }

  public static int parseLogLevel(String s)
  {
    if ("OFF".equals(s))
      return OFF;
    if ("SEVERE".equals(s) || "S".equals(s))
      return SEVERE;
    if ("WARNING".equals(s) || "W".equals(s))
      return WARNING;
    if ("INFO".equals(s) || "I".equals(s))
      return INFO;
    if ("CONFIG".equals(s) || "C".equals(s))
      return CONFIG;
    if ("FINE".equals(s) || "F".equals(s))
      return FINE;
    if ("FINER".equals(s))
      return FINER;
    if ("FINEST".equals(s))
      return FINEST;
    try
    {
      return Integer.parseInt(s);
    }
    catch(Exception x)
    {
    }
    return 0;
  }

  private static char[] chars = { '0', 'S', 'W', 'I', 'C', 'F', '6', '7' };
  public static char logLevelToChar(int l)
  {
    return chars[l];
  }

  /**
   * Check if a message of the given level would actually be logged by this logger.
   * This check is based on the Loggers effective level.
   * 
   * @param level a message logging level
   * @return true if the given message level is currently being logged.
   */
  public boolean isLoggable(int level) {
    int ll = logLevels.getInt(name, -1);
    if (ll<0)
      ll = defaultLogLevel;
    return level<=ll;
  }
  /**
   * Enables log writing to file. Not available on CLDC.
   * @param fileName  name of the output file.
   */
  public static boolean toFile(String fileName, int logLevel)
  {
    try
    {
      logWriter=new PrintWriter(new FileOutputStream(fileName));
      writerDefaultLogLevel = logLevel;
      return true;
    }
    catch(Exception x)
    {
      System.out.println(x);
    }
    return false;
  }

  /**
   * Closes the log file.
   * It is mandatory to call this method on shutdown when logging to a file.
   * Otherwise the log file is not be written to disk completely.
   * Log.shutdown is called from Mundo.shutdown.
   */
  public static void shutdown()
  {
    if (logWriter!=null)
      logWriter.close();
  }

  public static Logger global = new Logger("global");
  private String name;
  private static Hashtable<String,Logger> loggers = new Hashtable<String,Logger>();
  private ArrayList<IHandler> handlers;
  public ArrayList<LogEntry> entries;








  static int defaultLogLevel = WARNING;
  static int writerDefaultLogLevel = WARNING;
  static TypedMap logLevels = new TypedMap();
  static boolean logToConsole = true;
  static PrintWriter logWriter = null;

  public static void setConfig(TypedMap map)
  {
    if (map==null)
      return;

    defaultLogLevel = parseLogLevel(map.getString("default-log-level", "W"));
    writerDefaultLogLevel = defaultLogLevel;
    logToConsole = map.getBoolean("console", true);
    String filename = map.getString("filename", null);
    try
    {
      if (filename!=null)
        logWriter = new PrintWriter(new FileWriter(filename));
    }
    catch(IOException x)
    {
      x.printStackTrace();
    }

    TypedArray a = map.getArray("log-levels", null);
    if (a!=null)
    {
      for (Iterator i=a.iterator(); i.hasNext();)
      {
        TypedMap m = (TypedMap)i.next();
        logLevels.put(m.getString("category"), new Integer(parseLogLevel(m.getString("log-level"))));
      }
    }
  }

  static
  {
    int ll = parseLogLevel(System.getProperty("mc.logLevel"));
    if (ll!=0)
      defaultLogLevel = ll;

    global.addHandler(new IHandler() {
      public void publish(LogEntry entry) {
        int entryLL = entry.getLevel();
        int specLL = logLevels.getInt(entry.getCategory(), -1);
        int effectiveLL;









        // log to logfile
        effectiveLL = specLL;
        if (effectiveLL < 0)
          effectiveLL = writerDefaultLogLevel;
        if (logWriter!=null && entryLL<=effectiveLL)
        {
          logWriter.println(System.currentTimeMillis()+" "+entry.toString());
          logWriter.flush();
        }

        int l = entry.getLevel();
        if (l <= Logger.SEVERE)
          Log.e(entry.getCategory(), entry.getText());
        else if (l <= Logger.WARNING)
          Log.w(entry.getCategory(), entry.getText());
        else if (l <= Logger.CONFIG)
          Log.i(entry.getCategory(), entry.getText());
        else if (l <= Logger.FINE)
          Log.d(entry.getCategory(), entry.getText());
        else
          Log.v(entry.getCategory(), entry.getText());
      }
    });

    global.entries = new ArrayList<LogEntry>();




    global.addHandler(new IHandler() {
      public void publish(LogEntry entry) {
        global.entries.add(entry);
        if (global.entries.size()>1000)
          global.entries.remove(0);




      }
    });
  }
}
