/*
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is MundoCore Java.
 *
 * The Initial Developer of the Original Code is Telecooperation Group,
 * Department of Computer Science, Darmstadt University of Technology.
 * Portions created by the Initial Developer are
 * Copyright (C) 2001-2008 the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 * Erwin Aitenbichler
 */

package org.mundo.rt;




  



import java.util.LinkedList;
import java.util.Iterator;
import java.util.Collection;

/**
 * Implements a first-in-first-out queue. On standard edition and CDC the
 * elements are stored in a <code>LinkedList</code>. On CLDC, the elements
 * are stored in a <code>Vector</code>.
 * 
 * @author Erwin Aitenbichler
 */
public class Queue
<E> implements java.util.Queue<E>
{
  /**
   * Initializes a new queue.
   */
  public Queue()
  {
  }
  /**
   * Enqueues the specified object.
   * 
   * @param obj the object to enqueue.
   */
  public void enqueue(E obj)
  {


    ll.addLast(obj);
  }
  
  /**
   * Enqueues the specified object. This method is compatible with the JDK 1.5
   * syntax
   * 
   * @param obj the object to enqueue
   * @return true if the offer was accepted, false otherwise
   */
  public boolean offer(E obj) {
    try {
      enqueue(obj);
      return true;
    } catch(Exception didntadd) {
      return false;
    }
  }
  
  /**
   * Dequeues an object.
   * 
   * @return the dequeued object.
   * @throws NoSuchElementException if the queue is empty.
   */  
  public E dequeue()
  {




    return ll.removeFirst();
  }
  
  /**
   * Dequeues an object
   * 
   * @return the dequeued object.
   * @throws NoSuchElementException if the queue is empty
   */
  public E remove() {
    return dequeue();
  }
  
  /**
   * Dequeues an object
   * 
   * @return the dequeued object or null if the queue was empty
   */
  public E poll() {
    return isEmpty() ? null : dequeue();
  }
  
  /**
   * Returns the last element in the queue. This is the same element
   * <code>dequeue</code> would return, but <code>peek</code> does not
   * remove the element from the queue.
   * 
   * @return the last element in the queue or null if the queue is empty.
   */  
  public E peek()
  {
    return isEmpty() ? null : element();
  }
  /**
   * Returns the last element in the queue. This is the same element
   * <code>dequeue</code> would return, but <code>peek</code> does not
   * remove the element from the queue.
   * 
   * @return the last element in the queue
   * @throws NoSuchElementException if the queue is empty
   */  
  public E element()
  {


    return ll.getFirst();
  }
  /**
   * Returns the number of objects in the queue.
   * 
   * @return the number of objects in the queue.
   */
  public int size()
  {


    return ll.size();
  }
  /**
   * Returns whether the queue is empty.
   * 
   * @return <code>true</code> if the queue is empty; <code>false</code>
   *            otherwise.
   */
  public boolean isEmpty()
  {


    return ll.isEmpty();
  }
  /**
   * Clears the queue by removing all elements.
   */
  public void clear()
  {


    ll.clear();
  }
  
  /**
   * Returns true if this collection contains the specified element.
   */
  public boolean contains(Object o) {


    return ll.contains(o);
  }

  /**
   * Returns true if this collection contains all of the elements in the
   * specified collection.
   */
  public boolean containsAll(Collection<?> c) {











    return ll.containsAll(c);
  }
  
  
  /**
   * Returns an iterator over the elements in the queue. The iterator provides
   * the objects in the order they were enqueued.
   * 
   * @return an iterator over the elements in the queue.
   */
  public Iterator<E> iterator()
  {


    return ll.iterator();
  }
  


































  // methods that are necessary for java.util.Queue compatibility

  /**
   * Does not work, throws an UnsupportedOperationException
   */
  public boolean add(E o) {
    throw new UnsupportedOperationException();
  }

  /**
   * Does not work, throws an UnsupportedOperationException
   */
  public boolean addAll(Collection<? extends E> c) {
    throw new UnsupportedOperationException();
  }
  
  /**
   * Does not work, throws an UnsupportedOperationException
   */
  public boolean remove(Object o) {
    throw new UnsupportedOperationException();
  }

  /**
   * Does not work, throws an UnsupportedOperationException
   */
  public boolean removeAll(Collection<?> c) {
    throw new UnsupportedOperationException();
  }
  
  /**
   * Does not work, throws an UnsupportedOperationException
   */
  public boolean retainAll(Collection<?> c) {
    throw new UnsupportedOperationException();
  }
  
  /**
   * Returns an array containing all of the elements in this collection.
   */
  public Object[] toArray() {
    return ll.toArray();
  }
  
  /**
   * Returns an array containing all of the elements in this collection; the
   * runtime type of the returned array is that of the specified array.
   */
  public <T> T[] toArray(T[] a) {
    return ll.toArray(a);
  }
  



  private LinkedList<E> ll=new LinkedList<E>();


}
