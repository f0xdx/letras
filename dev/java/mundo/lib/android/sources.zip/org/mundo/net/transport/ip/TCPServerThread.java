/*
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is MundoCore Java.
 *
 * The Initial Developer of the Original Code is Telecooperation Group,
 * Department of Computer Science, Darmstadt University of Technology.
 * Portions created by the Initial Developer are
 * Copyright (C) 2001-2008 the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 * Erwin Aitenbichler
 */

package org.mundo.net.transport.ip;

import java.net.Socket;
import java.net.ServerSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;

import org.mundo.rt.Mundo;
import org.mundo.rt.Service;
import org.mundo.rt.Logger;



  
/**
 * Accept incoming TCP links from other nodes.
 */
class TCPServerThread extends Thread
{
  /**
   * Initializes a new TCP server thread, listening on the specified port.
   */
  TCPServerThread(IPTransportService ipts, InetAddress addr, int port, boolean reuse)
  {
    super(Mundo.getThreadGroup(), "ipts.server");
    this.ipts = ipts;
    this.requestedPort = port;
    this.reuse = reuse;
    this.addr = addr;
    this.port = 0;
  }
  synchronized boolean open()
  {
    if (serverSock!=null)
    {
      log.fine("socket already open");
      return true;
    }
    try
    {









      // bind requires Java 1.4
      serverSock = new ServerSocket();
      if (reuse)
        serverSock.setReuseAddress(true);
      serverSock.bind(new InetSocketAddress(addr, requestedPort));
      port = serverSock.getLocalPort();
      log.fine("bind "+addr+":"+port+(reuse ? " reuse" : "")+" succeeded");
    }
    catch(Exception x)
    {
      log.fine("bind "+addr+":"+requestedPort+(reuse ? " reuse" : "")+" failed");
      serverSock = null;
    }
    return serverSock!=null;
  }
  synchronized void close()
  {
    log.finest("close");
    port = 0;
    if (serverSock==null)
      return;
    ServerSocket sock = serverSock;
    serverSock = null;
    try
    {
      sock.close();
    }
    catch(Exception x)
    {
      log.exception(x);
    }
  }
  boolean isOpen()
  {
    return serverSock!=null;
  }
  int getLocalPort()
  {
    return port;
  }
  public void run()
  {
    int _port = port;
    log.finest("TCP server thread + "+(addr!=null ? addr : "")+":"+port);
    try
    {
      Socket sock;
      for(;;)
      {
        sock = serverSock.accept();
        if (ipts.getState() >= Service.STATE_SHUTDOWN)
          return;
        log.info("connect from tcp:/"+sock.getInetAddress()+":"+sock.getPort());
        IPLink route = new IPLink(ipts, IPLink.PROTO_TCP);
        TCPTransportConnection conn = new TCPTransportConnection(ipts, route, sock);
        conn.setKeepOpen(ipts.conf.keepOpen.booleanValue());
        route.iptc = conn;
        ipts.addLink(route);
        ipts.connectionCreated(conn);
        try
        {
          conn.connect();
        }
        catch(IllegalStateException x)
        {
          // Happens usually when concurrently shutting down
          if (ipts.getState() < Service.STATE_SHUTDOWN)
            log.exception(x);
        }
      }
    }
    catch(Exception x)
    {
      // serverSock is set to null to indicate a clean shutdown
      if (serverSock!=null)
      {
        log.exception(x);
      }
    }
    close();
    log.finest("TCP server thread - "+(addr!=null ? addr : "")+":"+port);
  }

  private int requestedPort;
  private InetAddress addr;
  private int port;
  private boolean reuse;
  private ServerSocket serverSock;
  private IPTransportService ipts;
  private Logger log = Logger.getLogger("ipts.tcp");
}
