/*
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is MundoCore Java.
 *
 * The Initial Developer of the Original Code is Telecooperation Group,
 * Department of Computer Science, Darmstadt University of Technology.
 * Portions created by the Initial Developer are
 * Copyright (C) 2001-2008 the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 * Erwin Aitenbichler
 */

package org.mundo.rt;

//#define LOG_MODULE

/**
 * Debugging helper class to detect where programs get stuck.
 */
public class Tracer
{
  public Tracer(String name)
  {
    this.name=name;
  }
  public synchronized void start()
  {
    location="after start";
    saveStack();
    if (thread!=null)
      return;
    thread=new MonitorThread();
    thread.start();


  }
  public synchronized void stop()
  {
    location="after stop";
    saveStack();
    if (thread==null)
      return;
    thread.interrupt();
    thread=null;


  }
  public synchronized void before(String loc)
  {
    location="in "+loc;
    timeout=0;
    saveStack();


  }
  public synchronized void after(String loc)
  {
    location="after "+loc;
    timeout=0;
    saveStack();


  }
  private void saveStack()
  {
    try
    {
      throw new Exception();
    }
    catch(Exception x)
    {
      stackTrace=x.getStackTrace();
    }
  }
  private static void printTrace(StackTraceElement[] list)
  {
    for (int i=0; i<list.length; i++)
    {
      String s=list[i].toString();
      if (!s.startsWith("org.mundo.rt.Tracer"))
        System.out.println(list[i]);
    }
  }
  private void stuck()
  {
    timeout=-60*1000;
    System.out.println("tracer: got stuck "+location);
    printTrace(stackTrace);
  }
  
  private class MonitorThread extends Thread
  {
    MonitorThread()
    {
    }
    public void run()
    {
      try
      {
        for(;;)
        {
          timeout+=1000;
          if (timeout>TIMEOUT_LIMIT)
          {
            stuck();
            break;
          }
          Thread.sleep(1000);
        }
      }
      catch(InterruptedException x)
      {
      }
    }
  }
  
  private String name;
  private StackTraceElement[] stackTrace;
  private String location;
  private int timeout;
  private static final int TIMEOUT_LIMIT=5000;
  private MonitorThread thread;


}
