package org.mundo.service;


/**
 * Automatically generated server stub for <code>IProcess</code>
 * @see org.mundo.service.IProcess
 */
public class SrvIProcess extends org.mundo.rt.ServerStub
{
  public SrvIProcess()
  {
  }
  private static org.mundo.rt.ServerStub _obj;
  public static org.mundo.rt.ServerStub _getObject()
  {
    if (_obj==null)
    {
      _obj=new SrvIProcess();
    }
    return _obj;
  }
  public void invoke(Object o, org.mundo.rt.TypedMap m, org.mundo.rt.TypedMap r)
  {
    String n=m.getString("request");
    IProcess p=(IProcess)o;
    try
    {
      if (n.equals("getSignalChannel") && m.getString("ptypes").equals(""))
      {
        r.putString("value", p.getSignalChannel());
        return;
      }
      if (n.equals("getName") && m.getString("ptypes").equals(""))
      {
        r.putString("value", p.getName());
        return;
      }
      if (n.equals("getNodeId") && m.getString("ptypes").equals(""))
      {
        r.putObject("value", p.getNodeId());
        return;
      }
      if (n.equals("shutdownNode") && m.getString("ptypes").equals(""))
      {
        r.putBoolean("value", p.shutdownNode());
        return;
      }
      if (n.equals("_getMethods") && m.getString("ptypes").equals(""))
      {
        r.putString("value",
        "s getSignalChannel()\n"+
        "s getName()\n"+
        "g getNodeId()\n"+
        "t shutdownNode()\n"+
        "");
        return;
      }
    }
    catch(Exception x)
    {
      exceptionOccured(x, o, m, r);
    }
  }
}