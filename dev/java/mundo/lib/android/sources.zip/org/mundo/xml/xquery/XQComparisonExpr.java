/*
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is MundoCore Java.
 *
 * The Initial Developer of the Original Code is Telecooperation Group,
 * Department of Computer Science, Darmstadt University of Technology.
 * Portions created by the Initial Developer are
 * Copyright (C) 2001-2008 the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 * Erwin Aitenbichler
 */

package org.mundo.xml.xquery;

import java.util.ArrayList;

import org.mundo.filter.AttributeFilter;
import org.mundo.filter.TypedMapFilter;

/**
 * A comparison expression.
 */
public class XQComparisonExpr extends XQObject
{
  XQComparisonExpr()
  {
  }
  void buildMapFilter(XQMapBuilder ctx) throws XQuery.BuildException
  {
    if (op==0)
    {
      left.buildMapFilter(ctx);
      return;
    }

    ArrayList<XQNode> nodes = ctx.expandPath(left);


    TypedMapFilter mf=ctx.mf;
    int i, s=nodes.size()-1;
    for (i=0; i<s; i++)
      mf=ctx.getOrCreateMap(mf, ((XQNode)nodes.get(i)).name);

    if (right.step instanceof XQLiteral)
    {
      ((XQLiteral)right.step).buildMapFilter(ctx, mf, ((XQNode)nodes.get(s)).name, op);
      return;
    }
    if (right.step instanceof XQFunction)
    {
      ((XQFunction)right.step).buildMapFilter(ctx, mf, ((XQNode)nodes.get(s)).name, op);
      return;
    }
    throw new XQuery.BuildException("right operand must be literal or boolean function");
  }
  void buildPlan(XEPlanBuilder ctx) throws XQuery.BuildException
  {
    left.buildPlan(ctx);
    XQObject obj=right.step;
    if (obj instanceof XQLongLiteral)
      ctx.stringToLong();
    else if (obj instanceof XQDoubleLiteral)
      ctx.stringToDouble();
    right.buildPlan(ctx);
    ctx.compare(op);
  }
  public XQObject[] children()
  {
    return new XQObject[] { left, right };
  }
  public String toString()
  {
    return left.toString()+AttributeFilter.opToString(op)+right.toString();
  }
  public int         op;
  public XQPathExpr  left;
  public XQPathExpr  right;
}
