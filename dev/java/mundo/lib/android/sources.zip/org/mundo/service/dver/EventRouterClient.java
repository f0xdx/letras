/*
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is MundoCore Java.
 *
 * The Initial Developer of the Original Code is Telecooperation Group,
 * Department of Computer Science, Darmstadt University of Technology.
 * Portions created by the Initial Developer are
 * Copyright (C) 2001-2008 the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 * Erwin Aitenbichler
 */

package org.mundo.service.dver;


import java.util.HashSet;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Iterator;





import java.util.Enumeration;
import org.mundo.rt.Service;
import org.mundo.rt.GUID;
import org.mundo.rt.Signal;
import org.mundo.rt.Message;
import org.mundo.rt.MessageContext;
import org.mundo.rt.Publisher;
import org.mundo.rt.Subscriber;
import org.mundo.rt.IBCLProvider;
import org.mundo.rt.TypedArray;
import org.mundo.rt.TypedMap;
import org.mundo.rt.Mundo;
import org.mundo.rt.IReceiver;
import org.mundo.rt.IMessageHandler;
import org.mundo.rt.Channel;
import org.mundo.rt.ProtocolStack;
import org.mundo.net.ProtocolCoordinator;
import org.mundo.net.routing.IRoutingService;
import org.mundo.net.transport.ITransportService;
import org.mundo.rt.Logger;



/**
 * Client-side service of the DVER event broker.
 */
public class EventRouterClient extends Service
       implements IBCLProvider.ISignal, IMessageHandler, org.mundo.rt.IEmits
       /*emits IMessageHandler*/
{
  public EventRouterClient()
  {
  }
  /**
   * Initializes the service.
   */
  public void init()
  {
    super.init();

    // register mimeType to receive control messages
    ProtocolCoordinator.register(mimeType, this);

    // start worker thread
    worker = new Worker();
    worker.start();
  }
  /**
   * Terminates the service.
   */
  public void shutdown()
  {
    worker.interrupt();
  
    super.shutdown();
  }
  /**
   * Raised on a local subscribe.
   */
  public synchronized void subscriberAdded(Subscriber s) /* IBCLProvider.ISignal */
  {
    if (!checkZone(s.getChannel().getZone()))
      return;
    log.fine("local subscribe: "+s.toString());

    if (subscriberSet.contains(s))


    {
      log.severe("subscriber added twice: "+s.toString());
      return;
    }
    subscriberSet.add(s);



    String channelName = s.getChannel().getName();
    SubEntry se = (SubEntry)subMap.get(channelName);
    if (se==null)
    {
      se = new SubEntry(channelName);
      se.addRef();
      se.state=true;
      subMap.put(channelName, se);
    }
    else
    {
      synchronized(se)
      {
        se.addRef();
      }
    }
    subscribersUpdated=true;
  }
  /**
   * Raised on a local unsubscribe.
   */
  public synchronized void subscriberRemoved(Subscriber s) /* IBCLProvider.ISignal */
  {
    if (!checkZone(s.getChannel().getZone()))
      return;
    log.fine("local unsubscribe: "+s.toString());

    if (!subscriberSet.remove(s))


    {
      log.severe("unknown subscriber: "+s.toString());
      return;
    }
    
    SubEntry se = (SubEntry)subMap.get(s.getChannel().getName());
    if (se==null)
      throw new IllegalStateException("reference counting is broken");
    synchronized(se)
    {
      if (!se.remRef())
      {
        se.state=false;
        subscribersUpdated=true;
      }
    }
  }
  /**
   * Raised on a local advertise.
   */
  public void publisherAdded(Publisher p) /* IBCLProvider.ISignal */
  {
    if (!checkZone(p.getChannel().getZone()))
      return;
    log.fine("local advertise: "+p.toString());
    
    if (publisherSet.contains(p))


    {
      log.severe("publisher added twice: "+p.toString());
      return;
    }
    publisherSet.add(p);


    
    String channelName=p.getChannel().getName();
    PubEntry pe = (PubEntry)pubMap.get(channelName);
    if (pe==null)
    {
      pe=new PubEntry(channelName);
      pe.addRef();
      pe.state=true;
      pubMap.put(channelName, pe);
    }
    else
    {
      synchronized(pe)
      {
        pe.addRef();
      }
    }
    publishersUpdated=true;
    if (!quenchingEnabled && !localSubs.containsKey(channelName))
    {
      log.fine("auto enable "+channelName);
      localSubs.put(channelName, session.subscribe(RT_ZONE, channelName, intMsgHandler));
    }
  }
  /**
   * Raised on a local unadvertise.
   */
  public void publisherRemoved(Publisher p) /* IBCLProvider.ISignal */
  {
    if (!checkZone(p.getChannel().getZone()))
      return;
    log.fine("local unadvertise: "+p.toString());
    
    if (!publisherSet.remove(p))


    {
      log.severe("unknown publisher: "+p.toString());
      return;
    }
    
    String channelName=p.getChannel().getName();
    PubEntry pe = (PubEntry)pubMap.get(channelName);
    if (pe==null)
      throw new IllegalStateException("reference counting is broken");
    synchronized(pe)
    {
      if (!pe.remRef())
      {
        pe.state=false;
        publishersUpdated=true;

        if (!quenchingEnabled)
        {
          Subscriber sub = (Subscriber)localSubs.remove(channelName);
          if (sub!=null)
          {
            log.fine("auto disable "+channelName);
            session.unsubscribeDelayed(sub);
          }
        }
      }
    }
  }
  /**
   *
   */
  public boolean down(Message msg) // IMessageHandler
  {
    String channelName;
    try
    {
      channelName=msg.getMap(CHUNK_NAME, "passive").getString("channel");
    }
    catch(NullPointerException x)
    {
      log.severe("missing channel name parameter in down");
      return false;
    }
    log.finer("forwarding msg for "+channelName+" to server");
    sendToServer(msg);
    return true;
  }
  /**
   * Raised when an external message has been received.
   */
  public boolean up(Message msg) // IMessageHandler
  {
    TypedMap map=msg.getMap(CHUNK_NAME, "passive");
    if (map==null)
      return false;
    String request=map.getString("request", null);
    if (request==null)
      return false;
    if (request.equals("ServerAd"))
      handleServerAd(map.getGUID("server"));
    else if (request.equals("Enable"))
    {
      if (quenchingEnabled)
        handleEnable(map);
    }
    else if (request.equals("Message"))
      handleServerMessage(map, msg);
    return true;
  }
  /**
   *
   */
  private synchronized void handleServerAd(GUID id)
  {
    if (id.equals(serverId))
    {
      log.warning("received another server ad with same id: "+id.toString());
      return;
    }
    serverId=id;
    log.fine("server found: "+serverId.shortString());
    for (SubEntry se : subMap.values())
    {








      synchronized(se)
      {
        se.committedState=false;
      }
    }
    subscribersUpdated=true;
    for (PubEntry pe : pubMap.values())
    {








      synchronized(pe)
      {
        pe.committedState=false;
      }
    }
    publishersUpdated=true;
    if (quenchingEnabled)
    {
      enabledChannels=new HashSet<String>();
      for (Subscriber sub : localSubs.values())
        session.unsubscribe(sub);
      localSubs=new HashMap<String,Subscriber>();










    }
    if (messageQueue!=null)
    {
      for (Message msg : messageQueue)
      {








        Message dmsg = msg.copyFrame();
        TypedMap amap = new TypedMap();
        amap.put("destType", "node");
        amap.put("destId", serverId);
        dmsg.put("rs", "param", amap);
        if (!emit.down(dmsg))
        {
          log.warning("send failed > "+serverId.shortString());
        }
      }
      messageQueue=null;
    }
  }
  /**
   *
   */
  private synchronized void handleEnable(TypedMap map)
  {
    TypedArray enables = map.getArray("enables", null);
    if (enables!=null)
    {
      for (Object obj : enables)
      {
        TypedMap m = (TypedMap)obj;




        String channelName = m.getString("channel");
        if (!enabledChannels.add(channelName))


        {
          log.warning("duplicate enable for "+channelName);
        }
        else
        {
          log.fine("enable "+channelName);
          localSubs.put(channelName, session.subscribe(RT_ZONE, channelName, intMsgHandler));
        }
      }
    }
    TypedArray disables = map.getArray("disables", null);
    if (disables!=null)
    {
      for (Object obj : disables)
      {
        TypedMap m = (TypedMap)obj;




        String channelName = m.getString("channel");
        if (!enabledChannels.remove(channelName))


        {
          log.warning("duplicate disable for "+channelName);
        }
        else
        {
          log.fine("disable "+channelName);
          session.unsubscribe((Subscriber)localSubs.remove(channelName));
        }
      }
    }
  }
  /**
   *
   */
  private void handleServerMessage(TypedMap map, Message msg)
  {
    log.finer("received message for "+map.getString("channel"));
/*
    try
    {
      msg.activate();
    }
    catch(Throwable t)
    {
      log.exception(t);
    }
*/
    Mundo.bcl.send(new Channel("rt", map.getString("channel")), msg, session);
  }
  /**
   * Checks whether we are responsible for the specified zone.
   */
  private boolean checkZone(String zoneName)
  {
    return "lan".equals(zoneName);
  }
  /**
   * Sends a control message to the server.
   */
  private void sendToServer(TypedMap map)
  {
    if (serverId==null)
      throw new IllegalStateException("no server");
    Message msg = new Message();
    msg.put(CHUNK_NAME, "passive", map);

    TypedMap amap = new TypedMap();
    amap.put("destType", "node");
    amap.put("destId", serverId);
    msg.put("rs", "param", amap);

    msg.setStack(ProtocolCoordinator.getInstance().getDefaultStack(), IBCLProvider.ISignal.class);
    msg.setType(mimeType);
    if (!emit.down(msg))
    {
      log.warning("send failed > "+serverId.shortString());
    }
  }
  /**
   * Sends a payload message to the server.
   */
  private void sendToServer(Message msg)
  {
    if (serverId==null)
    {
      log.finer("no server - enqueuing msg");
      synchronized(this)
      {
        if (messageQueue==null)
          messageQueue = new ArrayList<Message>();
        messageQueue.add(msg);








      }
      return;
    }
    log.finer("sending msg to server");
    Message dmsg = msg.copyFrame();
    TypedMap amap = new TypedMap();
    amap.put("destType", "node");
    amap.put("destId", serverId);
    dmsg.put("rs", "param", amap);
    if (!emit.down(dmsg))
    {
      log.warning("send failed > "+serverId.shortString());
    }
  }

  private class Entry
  {
    void addRef()
    {
      refcnt++;
    }
    boolean remRef()
    {
      if (refcnt==0)
        throw new IllegalStateException("reference counter underrun");
      refcnt--;
      return refcnt>0;
    }
    public String toString()
    {
      return channelName;
    }
    String channelName;
    int refcnt=0;
    boolean state=false;
    boolean committedState=false;
  }

  private class SubEntry extends Entry
  {
    SubEntry(String channelName)
    {
      this.channelName=channelName;
    }
  }
  
  private class PubEntry extends Entry
  {
    PubEntry(String channelName)
    {
      this.channelName=channelName;
    }
  }

  private class Worker extends Thread
  {
    Worker()
    {
    }
    public void run()
    {
      try
      {
        for(;;)
        {
          ArrayList<SubEntry> subs = null;
          ArrayList<PubEntry> pubs = null;






          synchronized(EventRouterClient.this)
          {
            if (serverId!=null)
            {
              if (subscribersUpdated)
              {
                subs = new ArrayList<SubEntry>(subMap.values());






                subscribersUpdated = false;
              }
              if (publishersUpdated)
              {
                pubs = new ArrayList<PubEntry>(pubMap.values());






                publishersUpdated = false;
              }
            }
          }
          TypedArray subReqs = new TypedArray();
          TypedArray unsubReqs = new TypedArray();
          if (subs!=null)
          {
            for (SubEntry se : subs)
            {








              synchronized(se)
              {
                if (se.state && !se.committedState)
                {
                  log.fine("send subscribe "+se.toString());
                  se.committedState=se.state;
                  TypedMap map=new TypedMap();
                  map.put("channel", se.channelName);
                  subReqs.add(map);
                }
                else if (!se.state && se.committedState)
                {
                  log.fine("send unsubscribe "+se.toString());
                  se.committedState=se.state;
                  TypedMap map=new TypedMap();
                  map.put("channel", se.channelName);
                  unsubReqs.add(map);
                }
              }
            }
          }
          TypedArray advReqs = new TypedArray();
          TypedArray unadvReqs = new TypedArray();
          if (pubs!=null)
          {
            for (PubEntry pe : pubs)
            {








              synchronized(pe)
              {
                if (pe.state && !pe.committedState)
                {
                  log.fine("send advertise "+pe.toString());
                  pe.committedState=pe.state;
                  TypedMap map=new TypedMap();
                  map.put("channel", pe.channelName);
                  advReqs.add(map);
                }
                else if (!pe.state && pe.committedState)
                {
                  log.fine("send unadvertise "+pe.toString());
                  pe.committedState=pe.state;
                  TypedMap map=new TypedMap();
                  map.put("channel", pe.channelName);
                  unadvReqs.add(map);
                }
              }
            }
          }
          if (subReqs.size()>0 || unsubReqs.size()>0 ||
              advReqs.size()>0 || unadvReqs.size()>0)
          {
            TypedMap msg=new TypedMap();
            msg.put("request", "Update");
            msg.put("clientId", Mundo.getNodeId());
            if (subReqs.size()>0)
              msg.put("subscribes", subReqs);
            if (unsubReqs.size()>0)
              msg.put("unsubscribes", unsubReqs);
            if (advReqs.size()>0)
              msg.put("advertises", advReqs);
            if (unadvReqs.size()>0)
              msg.put("unadvertises", unadvReqs);
            sendToServer(msg);
          }
          // FIXME: use a monitor here
          Thread.sleep(100);
        }
      }
      catch(InterruptedException x)
      {
      }
    }
  }

  private final IReceiver intMsgHandler = new IReceiver()
  {
    public void received(Message msg, MessageContext ctx)
    {
      log.finer("local msg for "+ctx.channel.getName());
      boolean enabled;
      if (quenchingEnabled)
      {
        synchronized(EventRouterClient.this)
        {
          enabled = enabledChannels.contains(ctx.channel.getName());


        }
      }
      else
        enabled=true;
      if (enabled)
      {
        msg = msg.copyFrame();

        TypedMap map = new TypedMap();
        map.put("request", "Message");
        map.put("channel", ctx.channel.getName());
        map.put("clientId", Mundo.getNodeId());
        map.put("contentType", msg.getType());
        msg.put(CHUNK_NAME, "passive", map);

        msg.setType(mimeType); 
        ProtocolCoordinator.getInstance().firstDown(msg);
      }
    }
  };

  private HashSet<Subscriber> subscriberSet = new HashSet<Subscriber>();
  private HashSet<Publisher> publisherSet = new HashSet<Publisher>();
  private HashMap<String,SubEntry> subMap = new HashMap<String,SubEntry>();
  private HashMap<String,PubEntry> pubMap = new HashMap<String,PubEntry>();
  private HashSet<String> enabledChannels = new HashSet<String>();
  private HashMap<String,Subscriber> localSubs = new HashMap<String,Subscriber>();
  private ArrayList<Message> messageQueue = null;
















  private boolean subscribersUpdated = false;
  private boolean publishersUpdated = false;
  private Logger log = Logger.getLogger("erc");
  private Worker worker;
  private GUID serverId;
  private boolean quenchingEnabled=false;
  // Event Router Client/Server Protocol
  private static final String CHUNK_NAME="ercsp";
  private static final String RT_ZONE="rt";
  private static final String mimeType = "message/mc-ercsp";

  // Generated by mcc
  protected class __EmitStub__ implements IMessageHandler
  {
    public boolean down(Message p0) // IMessageHandler
    {
      Object[] a=org.mundo.rt.Signal.getTargets(IMessageHandler.class, EventRouterClient.this);
      if (a==null) throw new IllegalStateException("signal not connected");
      return ((IMessageHandler)a[0]).down(p0);
    }
    public boolean up(Message p0) // IMessageHandler
    {
      Object[] a=org.mundo.rt.Signal.getTargets(IMessageHandler.class, EventRouterClient.this);
      if (a==null) throw new IllegalStateException("signal not connected");
      return ((IMessageHandler)a[0]).up(p0);
    }
  }
  private __EmitStub__ emit=new __EmitStub__();
  public boolean isEmitting(Class signal)
  {
    if (IMessageHandler.class.isAssignableFrom(signal)) return true;
    return false;
  }
}
