/*
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is MundoCore Java.
 *
 * The Initial Developer of the Original Code is Telecooperation Group,
 * Department of Computer Science, Darmstadt University of Technology.
 * Portions created by the Initial Developer are
 * Copyright (C) 2001-2008 the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 * Erwin Aitenbichler
 */

package org.mundo.rt;




import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

import org.mundo.rt.Logger;



/**
 * Sessions manage publishers, subscribers and exported objects.
 * Instances of <code>Session</code> are owned by a <code>Service</code>
 * and have the following responsiblities:
 * <ul>
 *   <li>They manage advertisements, subscriptions and exported objects.</li>
 *   <li>Sessions implement the <em>Active Object Pattern</em> to decouple
 *       message reception from message handling. (This behaviour is
 *       optional and can be controlled via the dispatch mode.)</li>
 *   <li>Sessions control execution. Only one message handler associated
 *       with a session is active at any time. The session serializes
 *       incoming messages.</li>
 * </ul>
 *
 * @see Service
 * @author Erwin Aitenbichler
 */
public class Session implements IReceiver
{
  /**
   * Initializes a new session.
   */
  Session(Service s)
  {
    service=s;
    guid=new GUID();
  }
  /**
   * Returns a session-specific <code>Channel</code> object for the
   * specified zone and channel names. The channel object is either
   * retrieved from a hashtable or newly created, if it does not
   * already exist.
   * @param zone  the zone name.
   * @param name  the channel name.
   * @return  the channel object.
   */
  public Channel getChannel(String zone, String name)
  {
    Channel c=(Channel)channels.get(zone+":"+name);
    if (c==null)
    {
      c=new Channel(this, zone, name);
      channels.put(zone+":"+name, c);
    }
    return c;
  }
  /**
   * Returns the <code>Service</code> that owns this <code>Session</code>.
   * @return  the service object.
   */
  public Service getService()
  {
    return service;
  }
  /**
   * Subscribes to a channel. This method automically subscribes to the specified
   * channel, sets the receiver callback and enables the subscription.
   *
   * The subscription can be removed by calling <code>Session.unsubscribe</code>.
   * All subscriptions are automatically removed when the associated
   * service terminates. Thus, it is not required to manually unsubscribe
   * everything when a service is shut down.
   *
   * @param zone         the zone name.
   * @param channelName  the channel name.
   * @param rcv          the receiver callback that will receive messages.
   * @return  a subscriber object
   */
  public Subscriber subscribe(String zone, String channelName, IReceiver rcv)
  {
    if (channelName==null)
      channelName="*";
    Subscriber s=new Subscriber(getChannel(zone, channelName));
    s.setReceiver(rcv);


    subscriptions.add(s);
    Mundo.bcl.subscribe(s);
    return s;
  }
  /**
   * Subscribes to a channel. After calling this method, it is necessary to
   * set the receiver callback using <code>Subscriber.setReceiver</code> and
   * to enable the subscription with <code>Subscriber.enable</code>.
   *
   * The subscription can be removed by calling <code>Session.unsubscribe</code>.
   * All subscriptions are automatically removed when the associated
   * service terminates. Thus, it is not required to manually unsubscribe
   * everything when a service is shut down.
   *
   * @param zone         the zone name.
   * @param channelName  the channel name.
   * @return  a subscriber object.
   */
  public Subscriber subscribe(String zone, String channelName)
  {
    if (channelName==null)
      channelName="*";
    Subscriber s=new Subscriber(getChannel(zone, channelName));


    subscriptions.add(s);
    return s;
  }
  /**
   * Subscribes to a channel. This method automically subscribes to the specified
   * channel, sets the receiver callback and enables the subscription.
   *
   * The subscription can be removed by calling <code>Session.unsubscribe</code>.
   * All subscriptions are automatically removed when the associated
   * service terminates. Thus, it is not required to manually unsubscribe
   * everything when a service is shut down.
   * 
   * If the specified channel object is not owned by this session, then a new
   * channel object within this session is created. The new channel object
   * inherits the protocol stack from this session and not from the channel
   * object specified as parameter.
   *
   * @param ch   the channel object.
   * @param rcv  the receiver callback that will receive messages.
   * @return  a subscriber object
   */
  public Subscriber subscribe(Channel ch, IReceiver rcv)
  {
    if (ch.getSession()==this)
    {
      Subscriber s=new Subscriber(ch);
      s.setReceiver(rcv);


      subscriptions.add(s);
      Mundo.bcl.subscribe(s);
      return s;
    }
    return subscribe(ch.getZone(), ch.getName(), rcv);
  }
  /**
   * Subscribes to a channel. This method automically subscribes to the specified
   * channel and enables the subscription.
   *
   * The subscription can be removed by calling <code>Session.unsubscribe</code>.
   * All subscriptions are automatically removed when the associated
   * service terminates. Thus, it is not required to manually unsubscribe
   * everything when a service is shut down.
   * 
   * If the specified channel object is not owned by this session, then a new
   * channel object within this session is created. The new channel object
   * inherits the protocol stack from this session and not from the channel
   * object specified as parameter.
   *
   * @param ch   the channel object.
   * @return  a subscriber object
   */
  public Subscriber subscribe(Channel ch)
  {
    if (ch.getSession()==this)
    {
      Subscriber s=new Subscriber(ch);


      subscriptions.add(s);
      return s;
    }
    return subscribe(ch.getZone(), ch.getName());
  }
  /**
   * Subscribes to a local anonymous channel. This operation is used
   * to create connections to local message routing services. This subscription
   * is only useful in conjunction with <code>SubscriptionParameters</code>.
   */
  public Subscriber subscribe()
  {
    return subscribe("rt", new GUID().toString());
  }
  /**
   * Unsubscribes from a channel immediately. By calling this method, the client
   * expresses that it no longer wants to receive messages from the associated
   * channel. This operation takes effect immediately.
   * @param s  the subscription to unsubscribe.
   */
  public synchronized void unsubscribe(Subscriber s)
  {
    // Make sure that no more messages are delivered
    s.setReceiver(null);
    Mundo.bcl.unsubscribe(s);
    subscriptions.remove(s);
  }
  /**
   * Unsubscribes from a channel. By calling this method, the client expresses
   * that it no longer wants to receive messages from the associated channel.
   * This operation stops enqueuing messages. The subscription is removed as
   * soon as all asynchronously enqueued messages have been delivered.
   * @param s  the subscription to unsubscribe.
   */
  public synchronized void unsubscribeDelayed(Subscriber s)
  {
    Mundo.bcl.unsubscribe(s);
    subscriptions.remove(s);
  }
  /**
   * Unsubscribes all subscriptions of this session.
   */
  public synchronized void unsubscribeAll()
  {




    for (Iterator iter=subscriptions.iterator(); iter.hasNext();)
      Mundo.bcl.unsubscribe((Subscriber)iter.next());
    subscriptions.clear();
  }
  /**
   * Shuts down the session. Unsubscribes all subscriptions of this session
   * and shuts down the message dispatch thread, if one is running.
   */  
  public synchronized void shutdown()
  {
    unsubscribeAll();
    publishers.clear();

    // Make sure that the dispatch thread is not immediately started again,
    // triggered by some incoming message.
    dispatchMode=DISPATCH_DISABLED;

    // Shut down the dispatch thread
    if (dispatchThread!=null)
    {
      dispatchThread.shutdown();
      dispatchThread=null;
    }
  }
  /**
   * Registers to publish to a channel. This operation is also often called
   * "advertise". By calling this method, the client expresses that it has
   * interest in publishing to the specified channel.
   * <code>publish</code> creates a <code>Publisher</code> object
   * that permits to send messages to the specified channel.
   * 
   * The registration can be removed by calling <code>Session.unpublish</code>.
   * All publishers are automatically released when the associated
   * service terminates. Thus, it is not required to manually unpublish
   * everything when a service is shut down.
   *
   * @param zone         the zone name.
   * @param channelName  the channel name.
   * @return  a publisher object.
   */
  public Publisher publish(String zone, String channelName)
  {
    Publisher p=Mundo.bcl.publish(getChannel(zone, channelName), null);


    synchronized(publishers)
    {
      publishers.add(p);
    }
    return p;
  }
  /**
   * Registers to publish to a channel. This operation is also often called
   * "advertise". By calling this method, the client expresses that it has
   * interest in publishing to the specified channel.
   * <code>publish</code> creates a <code>Publisher</code> object
   * that permits to send messages to the specified channel.
   * 
   * The registration can be removed by calling <code>Session.unpublish</code>.
   * All publishers are automatically released when the associated
   * service terminates. Thus, it is not required to manually unpublish
   * everything when a service is shut down.
   *
   * If the specified channel object is not owned by this session, then a new
   * channel object within this session is created. The new channel object
   * inherits the protocol stack from this session and not from the channel
   * object specified as parameter.
   *
   * @param ch  the channel object.
   * @return  a publisher object.
   */
  public Publisher publish(Channel ch)
  {
    if (ch.getSession()==this)
    {
      Publisher p=Mundo.bcl.publish(ch, null);


      synchronized(publishers)
      {
        publishers.add(p);
      }
      return p;
    }
    return publish(ch.getZone(), ch.getName());
  }
  /**
   * Unregisters a publisher. By calling this method, the client expresses
   * that it has no longer interest in publishing to the associated channel.
   *
   * @param p  the <code>Publisher</code> object to unregister.
   */
  public void unpublish(Publisher p)
  {


    synchronized(publishers)
    {
      publishers.remove(p);
    }
    Mundo.bcl.unadvertise(p);
  }
  /**
   * Returns the GUID of this session.
   * @return  the GUID of this session.
   */
  public GUID getId()
  {
    return guid;
  }
/*
  public void subscribe(String zone, String channelName, Class cls, Object obj) throws RMCException
  {
    ObjExportService svc=(ObjExportService)Mundo.getServiceByType(ObjExportService.class);
    try
    {
      ServerStub.forName(className);
    }
    catch(Exception x)
    {
      throw new RMCException("can't instantiate ServerStub for "+obj.getClass().getName(), x);
    }
    svc.exportObject(obj, this, channelName);
  }
  public void subscribe(String zone, String channelName, ServerStub srvStub, Object obj) throws RMCException
  {
    ObjExportService svc=(ObjExportService)Mundo.getServiceByType(ObjExportService.class);
    String stubName=srvStub.getClass().getName();
    String className=stubName.substring(stubName.lastIndexOf('.')+6);

    // FIXME: use the fully qualified classname as key
    svc.addServerStub(className, srvStub);
    svc.exportObject(obj, this, channelName);
  }
*/
  /**
   * Subscribes an object to a channel. The specified object is attached to
   * the specified channel via server stubs that will be dynamically chosen
   * at the time of a remote method call.
   *
   * @param zone         the zone name.
   * @param channelName  the channel name.
   * @param obj          the object to subscribe.
  public void subscribe(String zone, String channelName, Object obj) throws RMCException
  {
    ObjExportService svc=(ObjExportService)Mundo.getServiceByType(ObjExportService.class);
    svc.exportObject(obj, this, channelName);
  }
   */

/*
   * Binds a stub to a channel.
  public Publisher publish(String zone, String channelName, DoObject stub)
  {
    Publisher p=publish(zone, channelName);
    stub._setPublisher(p);
    return p;
  }
*/
  /**
   * Adds a call object to the session. The call object is add before the
   * remote method is invoked. The session can then notify the corresponding
   * <code>AsyncCall</code> object once a result is returned.
   */
  void addCall(AsyncCall call)
  {
    calls.put(call.getId(), call);
    if (subscriber==null)
    {
      subscriber=subscribe("lan", guid.toString());
//      ChannelSubscription p=new ChannelSubscription();
//      p.activation=false;
//      subscriber.setParam(p);
      subscriber.setReceiver(this);
      subscriber.enable();
    }
  }
  /**
   * Removes a call object from the session. This is called by the call object
   * once it is no longer interested in receiving results.
   */
  void removeCall(AsyncCall call)
  {
    calls.remove(call.getId());
  }
  
  /**
   * Sends the specified message to the specified target. This method
   * should not be used directly. It is typically used by server stubs
   * to send reply messages to sessions.
   * targetId  the GUID of the target channel.
   * msg       the message to send.
   */
  public void send(GUID targetId, Message msg)
  {
//  	System.out.println("send to: "+targetId);
//  	System.out.println(msg);
    Publisher p=publish("lan", targetId.toString());
    p.send(msg);
    unpublish(p);
  }
  /**
   * This callback is called when a RMC originated from this session
   * returns a result.
   * @see IReceiver
   */
  public void received(Message msg, MessageContext ctx) // IReceiver
  {
    TypedMap map=msg.getMap("main", "passive");
    // local call
    if (map==null)
      map=msg.getMap();
    GUID callId=map.getGUID("callId");
    log.finer("received RMC reply for callId="+callId.shortString());
    AsyncCall call=(AsyncCall)calls.get(callId);
    if (call!=null)
    {
      call.returned(msg);
    }
    else
    {
      log.severe("unexpected RMC reply: "+map.getString("request"));
    }
  }

  /**
   * Dispatches a message.
   * @param sub  the subscriber object.
   * @param msg  the message to dispatch.
   * @param ctx  the message context.
   */
  public synchronized void dispatch(Subscriber sub, Message msg, MessageContext ctx)
  {
    if (sub!=null && sub.getReceiver()==this)
    {
      // Results from RMC calls are always dispatched directly
      received(msg, ctx);
      return;
    }
  
    if (dispatchMode==DISPATCH_SYNC)
    {
      sub.dispatch(msg, ctx);
    }
    else if (dispatchMode==DISPATCH_ASYNC)
    {
      if (dispatchThread==null)
      {
        dispatchThread=new DispatchThread();
        dispatchThread.start();
      }
      dispatchThread.enqueue(sub, msg, ctx);
    }
  }
  /**
   * Sets the message dispatch mode. The default is <code>DISPATCH_ASYNC</code>.
   * On CLDC, the default is <code>DISPATCH_SYNC</code>.
   */
  public void setDispatchMode(int m)
  {
    if (!(m==DISPATCH_SYNC || m==DISPATCH_ASYNC))
      throw new IllegalArgumentException("invalid mode");
    dispatchMode=m;
  }
  /**
   * Returns the message dispatch mode.
   */
  public int getDispatchMode()
  {
    return dispatchMode;
  }
  /**
   * Sets the RMC dispatch mode. The default is <code>DISPATCH_SYNC</code>.
   */
  public void setRMCDispatchMode(int m)
  {
    if (!(m==DISPATCH_SYNC || m==DISPATCH_ASYNC))
      throw new IllegalArgumentException("invalid mode");
    rmcDispatchMode=m;
  }
  /**
   * Returns the RMC dispatch mode.
   */
  public int getRMCDispatchMode()
  {
    return rmcDispatchMode;
  }
  /**
   * Returns the subscriptions managed by this session.
   */





  public HashSet<Subscriber> getSubscribers()
  {
    return subscriptions;
  }





  /**
   * Returns the advertisements managed by this session.
   */





  public HashSet<Publisher> getPublishers()
  {
    return publishers;
  }





  /**
   * Returns the DoObject of the specified class for the specified object.
   */











  DoObject getDoObject(Class stubClass, Object obj)
  {
    synchronized(stubs)
    {
      HashMap<Object,DoObject> map=stubs.get(stubClass);
      if (map==null)
        return null;
      return map.get(obj);
    }








  }
  /**
   * Stores the specified DoObject for the specified object.
   */
  void putDoObject(Object obj, DoObject stub)
  {
    synchronized(stubs)
    {
      HashMap<Object,DoObject> map=stubs.get(stub.getClass());
      if (map==null)
      {
        map=new HashMap<Object,DoObject>();
        stubs.put(stub.getClass(), map);
      }
      map.put(obj, stub);
    }
























  }
  /**
   * Returns a string representation of this Session object.
   */
  public String toString()
  {
    return "service={"+service.toString()+"}";
  }

  /**
   * Use synchronous dispatch. In this mode, on reception of a message, the
   * appropriate message handler is called directly. This has the following
   * consequences:
   * <ul>
   *   <li>Messages are dispatched with lower latency.</li>
   *   <li>A blocking message handler stalls other services.</li>
   *   <li>Nested remote method calls are not possible, if the callee
   *       calls a method of the caller.</li>
   * </ul>
   */
  public static final int DISPATCH_SYNC = 1;
  /**
   * Use decoupled dispatch. In this mode, received messages are queued
   * and dispatched by a separate thread to the appropriate message
   * hander. The disadvantage of this mode is a higher requirement of system
   * resources, since each session creates an additional thread.
   * However, decoupled dispatch will improve performance on multiprocessor
   * machines.
   */
  public static final int DISPATCH_ASYNC = 2;
  /**
   * Dispatch is disabled. This mode is used internally to disable dispatch
   * after shutdown.
   */
  public static final int DISPATCH_DISABLED = 3;

  // Must be visible inside package for debugging purposes.
  class DispatchThread extends Thread
  {
    DispatchThread()
    {
      super(Mundo.getThreadGroup(), "session.dispatch");
    }
    Session getSession()
    {
      return Session.this;
    }
    /**
     * Enqueues a new message.
     * @param sub  the subscriber object.
     * @param msg  the message to dispatch.
     * @param ctx  the message context.
     */
    synchronized void enqueue(Subscriber sub, Message msg, MessageContext ctx)
    {
      queue.enqueue(new QEntry(sub, msg, ctx));
      notify();
    }
    /**
     * Requests termination of the thread by inserting an empty element
     * into the message queue.
     */
    synchronized void shutdown()
    {
      queue.enqueue(new QEntry());
      notify();
    }
    /**
     * Reads messages from the dispatch queue and dispatches messages.
     */
    public void run() // Thread
    {
      QEntry entry;
      for(;;)
      {
        for(;;)
        {
          entry=null;
          synchronized(this)
          {
            if (!queue.isEmpty())
              entry=(QEntry)queue.dequeue();
          }
          if (entry==null)
            break;
          if (entry.isShutdownRequest())
            return;
          // Speed optimization: notifications from RMCService have ctx==null
          if (entry.ctx==null)
          {
            TypedMap map=entry.msg.getMap("RMCService", "active");
            if (map!=null)
            {
              try
              {
                DoObject cs=(DoObject)map.getObject("stub");
                String req=map.getString("request");
                log.fine("DispatchThread.run: stub.request="+req);
                DoObject.IConn handler=cs._getConnHandler();
                if (handler!=null)
                {
                  if ("objectConnected".equals(req))
                    handler.objectConnected();
                  else if ("objectDisconnected".equals(req))
                    handler.objectDisconnected();
                }
              }
              catch(Exception x)
              {
                log.exception(x);
              }
            }
            else
              entry.sub.dispatch(entry.msg, entry.ctx);
          }
          else
            entry.sub.dispatch(entry.msg, entry.ctx);
        }
        try
        {
          synchronized(this)
          {
            wait();
          }
        }
        catch(InterruptedException x)
        {
          return;
        }
      }
    }
    /**
     * The queue holding the messages to dispatch. Entries are instances
     * of <code>QEntry</code>.
     */
    Queue<QEntry> queue=new Queue<QEntry>();


  }

  private static class QEntry
  {
    QEntry()
    {
      msg=null;
    }
    QEntry(Subscriber s, Message m, MessageContext c)
    {
      sub=s;
      msg=m;
      ctx=c;
    }
    boolean isShutdownRequest()
    {
      return msg==null;
    }
    Subscriber sub;
    Message msg;
    MessageContext ctx;
  }

  /**
   * The dispatch mode, which is one of <code>DISPATCH_*</code>.
   */
  private int dispatchMode = DISPATCH_ASYNC;
  private int rmcDispatchMode = DISPATCH_SYNC;
  private Service service;
  private GUID guid;
  private Subscriber subscriber;
  private DispatchThread dispatchThread = null;






  private HashMap<String,Channel> channels = new HashMap<String,Channel>();
  private HashSet<Subscriber> subscriptions = new HashSet<Subscriber>();
  private HashSet<Publisher> publishers = new HashSet<Publisher>();
  private HashMap<GUID,AsyncCall> calls = new HashMap<GUID,AsyncCall>();
  private HashMap<Class,HashMap<Object,DoObject>> stubs = new HashMap<Class,HashMap<Object,DoObject>>();






  private static Logger log=Logger.getLogger("session");
}
