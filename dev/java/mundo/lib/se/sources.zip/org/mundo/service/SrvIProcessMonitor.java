package org.mundo.service;


/**
 * Automatically generated server stub for <code>IProcessMonitor</code>
 * @see org.mundo.service.IProcessMonitor
 */
public class SrvIProcessMonitor extends org.mundo.rt.ServerStub
{
  public SrvIProcessMonitor()
  {
  }
  private static org.mundo.rt.ServerStub _obj;
  public static org.mundo.rt.ServerStub _getObject()
  {
    if (_obj==null)
    {
      _obj=new SrvIProcessMonitor();
    }
    return _obj;
  }
  public void invoke(Object o, org.mundo.rt.TypedMap m, org.mundo.rt.TypedMap r)
  {
    String n=m.getString("request");
    IProcessMonitor p=(IProcessMonitor)o;
    try
    {
      if (n.equals("startProcess") && m.getString("ptypes").equals("s,s"))
      {
        r.putObject("value", p.startProcess(m.getString("p0"), m.getString("p1")));
        return;
      }
      if (n.equals("findProcess") && m.getString("ptypes").equals("s"))
      {
        r.putObject("value", p.findProcess(m.getString("p0")));
        return;
      }
      if (n.equals("uploadFile") && m.getString("ptypes").equals("s,s"))
      {
        r.putBoolean("value", p.uploadFile(m.getString("p0"), m.getString("p1")));
        return;
      }
      if (n.equals("_getMethods") && m.getString("ptypes").equals(""))
      {
        r.putString("value",
        "org.mundo.service.IProcess startProcess(s,s)\n"+
        "org.mundo.service.IProcess findProcess(s)\n"+
        "t uploadFile(s,s)\n"+
        "");
        return;
      }
    }
    catch(Exception x)
    {
      exceptionOccured(x, o, m, r);
    }
  }
}