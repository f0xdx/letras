package org.mundo.service;


/**
 * Automatically generated distributed object class for <code>IProcessSignal</code>.
 * @see org.mundo.service.IProcessSignal
 */
public class DoIProcessSignal extends org.mundo.rt.DoObject implements org.mundo.service.IProcessSignal
{
  public DoIProcessSignal()
  {
  }
  public DoIProcessSignal(org.mundo.rt.Session session, Object obj) throws org.mundo.rt.RMCException
  {
    _bind(session, obj);
  }
  public DoIProcessSignal(org.mundo.rt.Channel channel) throws org.mundo.rt.RMCException
  {
    _setPublisher(channel.getSession().publish(channel.getZone(), channel.getName()));
  }
  public DoIProcessSignal(org.mundo.rt.DoObject o)
  {
    _assign(o);
  }
  public org.mundo.rt.ServerStub _getServerStub()
  {
    return SrvIProcessSignal._getObject();
  }
  public static DoIProcessSignal _of(org.mundo.rt.Session session, Object obj)
  {
    DoIProcessSignal cs=(DoIProcessSignal)_getDoObject(session, DoIProcessSignal.class, obj);
    if (cs==null)
    {
      cs=new DoIProcessSignal(session, obj);
      _putDoObject(session, obj, cs);
    }
    return cs;
  }
  public static DoIProcessSignal _of(org.mundo.rt.Service s)
  {
    return _of(s.getSession(), s);
  }
  public String _getInterfaceName()
  {
    return "org.mundo.service.IProcessSignal";
  }
  public static IProcessSignal _localObject(IProcessSignal obj)
  {
    if (obj instanceof org.mundo.rt.DoObject)
    {
      return (IProcessSignal)((org.mundo.rt.DoObject)obj)._getLocalObject();
    }
    else
    {
      return obj;
    }
  }
  public void processIdentified(org.mundo.rt.GUID p0)
  {
    if (localObj!=null) 
    {
      ((org.mundo.service.IProcessSignal)localObj).processIdentified(p0);
      return;
    }
    processIdentified(p0, SYNC);
  }
  public org.mundo.rt.AsyncCall processIdentified(org.mundo.rt.GUID p0, Options opt) 
  {
    org.mundo.rt.TypedMap m=new org.mundo.rt.TypedMap();
    m.putString("ptypes", "g");
    m.putString("rtype", "");
    m.putObject("p0", p0);
    org.mundo.rt.AsyncCall call=new org.mundo.rt.AsyncCall(this, "org.mundo.service.IProcessSignal", "processIdentified", m);
    if (opt==ONEWAY)
    {
      call.invokeOneWay();
    }
    else if (opt==SYNC || opt==ASYNC)
    {
      call.invoke();
    }
    if (opt==SYNC)
    {
      try
      {
        if (!call.waitForReply())
        {
          throw call.getException();
        }
      }
      catch(RuntimeException x)
      {
        throw x;
      }
      catch(Exception x)
      {
        throw new org.mundo.rt.RMCException("unexpected exception", x);
      }
    }
    return call;
  }
  
  public void processTerminated()
  {
    if (localObj!=null) 
    {
      ((org.mundo.service.IProcessSignal)localObj).processTerminated();
      return;
    }
    processTerminated(SYNC);
  }
  public org.mundo.rt.AsyncCall processTerminated(Options opt) 
  {
    org.mundo.rt.TypedMap m=new org.mundo.rt.TypedMap();
    m.putString("ptypes", "");
    m.putString("rtype", "");
    org.mundo.rt.AsyncCall call=new org.mundo.rt.AsyncCall(this, "org.mundo.service.IProcessSignal", "processTerminated", m);
    if (opt==ONEWAY)
    {
      call.invokeOneWay();
    }
    else if (opt==SYNC || opt==ASYNC)
    {
      call.invoke();
    }
    if (opt==SYNC)
    {
      try
      {
        if (!call.waitForReply())
        {
          throw call.getException();
        }
      }
      catch(RuntimeException x)
      {
        throw x;
      }
      catch(Exception x)
      {
        throw new org.mundo.rt.RMCException("unexpected exception", x);
      }
    }
    return call;
  }
  
  public void processOutput(String p0, int p1)
  {
    if (localObj!=null) 
    {
      ((org.mundo.service.IProcessSignal)localObj).processOutput(p0, p1);
      return;
    }
    processOutput(p0, p1, SYNC);
  }
  public org.mundo.rt.AsyncCall processOutput(String p0, int p1, Options opt) 
  {
    org.mundo.rt.TypedMap m=new org.mundo.rt.TypedMap();
    m.putString("ptypes", "s,i");
    m.putString("rtype", "");
    m.putString("p0", p0);
    m.putInt("p1", p1);
    org.mundo.rt.AsyncCall call=new org.mundo.rt.AsyncCall(this, "org.mundo.service.IProcessSignal", "processOutput", m);
    if (opt==ONEWAY)
    {
      call.invokeOneWay();
    }
    else if (opt==SYNC || opt==ASYNC)
    {
      call.invoke();
    }
    if (opt==SYNC)
    {
      try
      {
        if (!call.waitForReply())
        {
          throw call.getException();
        }
      }
      catch(RuntimeException x)
      {
        throw x;
      }
      catch(Exception x)
      {
        throw new org.mundo.rt.RMCException("unexpected exception", x);
      }
    }
    return call;
  }
  
}