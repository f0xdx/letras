/*
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is MundoCore Java.
 *
 * The Initial Developer of the Original Code is Telecooperation Group,
 * Department of Computer Science, Darmstadt University of Technology.
 * Portions created by the Initial Developer are
 * Copyright (C) 2001-2008 the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 * Erwin Aitenbichler
 */

package org.mundo.reflect;

import java.io.IOException;

import org.mundo.reflect.MInterface;
import org.mundo.reflect.MMethod;
import org.mundo.reflect.MCIFParser;
import org.mundo.rt.AsyncCall;
import org.mundo.rt.DoObject;
import org.mundo.rt.Message;
import org.mundo.rt.ServerStub;
import org.mundo.rt.RMCException;
import org.mundo.rt.TypedMap;
import org.mundo.rt.TypedArray;

/**
 * A generic DoObject supporting dynamic invocations.
 */
public class GenericClientStub extends DoObject
{
  /**
   * Initializes a new stub.
   */
  public GenericClientStub()
  {
  }
  /**
   * Initializes a new stub.
   */
  public GenericClientStub(MInterface ifc)
  {
    this.ifc=ifc;
  }
  /**
   * Initializes a new stub.
   */
  public GenericClientStub(DoObject o)
  {
    _assign(o);
  }
  @Override
  public String _getInterfaceName()
  {
    if (ifc==null)
      return null;
    return ifc.getName();
  }
  @Override
  public ServerStub _getServerStub()
  {
    return null;
  }
  /**
   * Sets whether errors during processing of the reply message should
   * lead to exceptions or not. This option is useful when calling remote
   * methods via reflection and objects in the reply message may be unknown.
   */
  public void setIgnoreClientErrors(boolean b)
  {
    ignoreClientErrors = b;
  }
  /**
   * Query interface information from the server.
   * @param interfaceName  name of the interface to query.
   * @return  an <code>MInterface</code> object describing the interface.
   */
  public MInterface queryInterface(String interfaceName) throws RMCException
  {
    ifc = new MInterface(interfaceName);
    String text;
    try
    {
      text = _getMethods();
    }
    catch(RuntimeException x)
    {
      ifc = null;
      throw x;
    }
    ifc = null;
    try
    {
      MCIFParser parser = new MCIFParser();
      ifc = parser.parseInterface(interfaceName, text);
      return ifc;
    }
    catch(IOException x)
    {
      throw new RMCException("can't parse interface", x);
    }
  }
  /**
   * Query information about all supported interfaces by the server object.
   * @return  an array of <code>MInterface</code> objects describing the interfaces.
   */
  public MInterface[] queryInterfaces() throws RMCException
  {
    TypedArray ifNames = _getInterfaces();
    int i, s=ifNames.size();
    MInterface[] ifcs = new MInterface[s];
    for (i=0; i<s; i++)
      ifcs[i] = queryInterface(ifNames.getString(i));
    return ifcs;
  }
  /**
   * Query class information from the server.
   * @param className  name of the class to query.
   * @return  an <code>MClass</code> object describing the class.
   */
  public MClass queryClass(String className) throws RMCException
  {
    String text;
    try
    {
      text = _getFields(className);
    }
    catch(RuntimeException x)
    {
      throw x;
    }
    if (text==null)
      return null;
    try
    {
      MCIFParser parser = new MCIFParser();
      MClass cls = parser.parseClass(className, text);
      return cls;
    }
    catch(IOException x)
    {
      throw new RMCException("can't parse class", x);
    }
  }
  /**
   * Invokes the specified remote method with the specified parameters.
   * @param mtd  the method to call.
   * @param params  the call parameters.
   * @param opt  synchronization; one of <code>SYNC</code>, <code>ASYNC</code>,
   *             <code>ONEWAY</code>, or <code>CREATEONLY</code>.
   * @return  the call object.
   */
  public AsyncCall invoke(MMethod mtd, Object[] params, Options opt)
  {
    if (ifc==null)
    {
      ifc = mtd.getInterface();
      if (ifc==null)
        throw new IllegalStateException("interface not specified");
    }
    else if (ifc!=mtd.getInterface())
      throw new IllegalStateException("method does not belong to interface");

    TypedMap m = new TypedMap();
    m.putString("ptypes", mtd.getParamTypeCode());
    m.putString("rtype", mtd.getReturnTypeCode());
    if (params!=null)
    {
      for (int i=0; i<params.length; i++)
        m.put("p"+i, params[i]);
    }
    AsyncCall call = new AsyncCall(this, ifc.getName(), mtd.getName(), m);
    call.setIgnoreClientErrors(ignoreClientErrors);
    call.setOptions(opt);
    if (opt.test(ONEWAY))
      call.invokeOneWay();
    else if (opt.test(SYNC) || opt.test(ASYNC))
      call.invoke();
    if (opt.test(SYNC))
    {
      try
      {
        if (!call.waitForReply())
          throw call.getException();
      }
      catch(RuntimeException x)
      {
        throw x;
      }
      catch(Exception x)
      {
        throw new RMCException("unexpected exception", x);
      }
    }
    return call;
  }
  /**
   * Invokes the specified remote method with the specified parameters.
   * @param mtd  the method to call.
   * @param params  the call parameters.
   * @param opt  synchronization; one of <code>SYNC</code>, <code>ASYNC</code>,
   *             <code>ONEWAY</code>, or <code>CREATEONLY</code>.
   * @return  the call object.
   */
  public AsyncCall invoke(MMethod mtd, TypedMap params, Options opt)
  {
    if (ifc==null)
    {
      ifc = mtd.getInterface();
      if (ifc==null)
        throw new IllegalStateException("interface not specified");
    }
    else if (ifc!=mtd.getInterface())
      throw new IllegalStateException("method does not belong to interface");

    TypedMap m = new TypedMap(params);
    m.putString("ptypes", mtd.getParamTypeCode());
    m.putString("rtype", mtd.getReturnTypeCode());
    AsyncCall call = new AsyncCall(this, ifc.getName(), mtd.getName(), m);
    call.setIgnoreClientErrors(ignoreClientErrors);
    call.setOptions(opt);
    if (opt.test(ONEWAY))
      call.invokeOneWay();
    else if (opt.test(SYNC) || opt.test(ASYNC))
      call.invoke();
    if (opt.test(SYNC))
    {
      try
      {
        if (!call.waitForReply())
          throw call.getException();
      }
      catch(RuntimeException x)
      {
        throw x;
      }
      catch(Exception x)
      {
        throw new RMCException("unexpected exception", x);
      }
    }
    return call;
  }
  public Object invoke(MMethod mtd, Object[] params)
  {
    AsyncCall ac=invoke(mtd, params, SYNC);
    return ac.getObj();
  }

  private MInterface ifc;
  private boolean ignoreClientErrors = false;
}
