/*
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is MundoCore Java.
 *
 * The Initial Developer of the Original Code is Telecooperation Group,
 * Department of Computer Science, Darmstadt University of Technology.
 * Portions created by the Initial Developer are
 * Copyright (C) 2001-2008 the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 * Erwin Aitenbichler
 */

package org.mundo.xml;

import org.mundo.rt.Blob;
import org.mundo.rt.GUID;
import org.mundo.rt.TypedArray;
import org.mundo.rt.TypedContainer;
import org.mundo.rt.TypedMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Vector;

/**
* TypeName is an enumeration of all xsd type names recognized by MundoCore.
*
* @author AHa
*/
public enum TypeName {

















  Byte  ("byte", Byte.class, 1),
  UByte  ("unsignedByte", TypedContainer.UnsignedByte.class, 1),
  Short  ("short", Short.class, 2),
  UShort  ("unsignedShort", TypedContainer.UnsignedShort.class, 2),
  Int  ("int", Integer.class, 4),
  UInt  ("unsignedInt", TypedContainer.UnsignedInteger.class, 4),
  Long  ("long", Long.class, 8),
  ULong  ("unsignedLong", TypedContainer.UnsignedLong.class, 8),
  Float  ("float", Float.class, 4),
  Char  ("char", Character.class, 2),
  String  ("string", String.class, -1),
  ID  ("ID", GUID.class, GUID.GUID_SIZE),
  JavaXDR  ("JavaXDR", TypedContainer.JavaXDR.class, -1),
  Array  ("array", TypedArray.class, -1),
  Map  ("map", TypedMap.class, -1),
  Blob  ("blob", Blob.class, -1)
  ,
  Double  ("double", Double.class, 8),
  Boolean  ("boolean", Boolean.class, 1)
  ;

  private final String typename;
  private final Class clazz;
  private final int bytes;
  
  private TypeName(String name, Class clazz, int bytes) {







    this.typename = name;
    this.clazz = clazz;
    this.bytes = bytes;
  }
  
  public String toString() {
    return typename;
  }
  
  /**
  * Retrieves the name used in XSD for the type. The name is without the namespace prefix.
  * 
  *  @return the XSD name
  */
  public String xsdName() {
    return typename;
  }
  
  /**
  * Retrieves the class this type stands for.
  * 
  * @return a Java class used in the type
  */
  public Class type() {
    return clazz;
  }
  
  /**
   * Retrieves the size of the type in bytes. Classes that do not have
   * a fixed size - i.e. all compound classes like String, Array, Map, Blob -
   * return -1 for this method
   */
  public int sizeOf() {
    return bytes;
  }
















}
