package org.mundo.agent;


/**
 * Automatically generated server stub for <code>IMobility</code>
 * @see org.mundo.agent.IMobility
 */
public class SrvIMobility extends org.mundo.rt.ServerStub
{
  public SrvIMobility()
  {
  }
  private static org.mundo.rt.ServerStub _obj;
  public static org.mundo.rt.ServerStub _getObject()
  {
    if (_obj==null)
    {
      _obj=new SrvIMobility();
    }
    return _obj;
  }
  public void invoke(Object o, org.mundo.rt.TypedMap m, org.mundo.rt.TypedMap r)
  {
    String n=m.getString("request");
    IMobility p=(IMobility)o;
    try
    {
      if (n.equals("moveTo") && m.getString("ptypes").equals("s"))
      {
        p.moveTo(m.getString("p0"));
        return;
      }
      if (n.equals("moveTo") && m.getString("ptypes").equals("s,s"))
      {
        p.moveTo(m.getString("p0"), m.getString("p1"));
        return;
      }
      if (n.equals("_getMethods") && m.getString("ptypes").equals(""))
      {
        r.putString("value",
        "v moveTo(s)\n"+
        "v moveTo(s,s)\n"+
        "");
        return;
      }
    }
    catch(Exception x)
    {
      exceptionOccured(x, o, m, r);
    }
  }
}