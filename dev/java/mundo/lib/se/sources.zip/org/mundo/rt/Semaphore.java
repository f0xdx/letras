/*
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is MundoCore Java.
 *
 * The Initial Developer of the Original Code is Telecooperation Group,
 * Department of Computer Science, Darmstadt University of Technology.
 * Portions created by the Initial Developer are
 * Copyright (C) 2001-2008 the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 * Erwin Aitenbichler
 */

package org.mundo.rt;


/**
 * Extended semaphore class with deadlock detection.
 * @author Erwin Aitenbichler
 */
public class Semaphore
{
  private static final int timeout=5000;

  /**
   * Initializes a <code>Semaphore</code> with the specified number of permits.
   */
  public Semaphore(int p)
  {
    permits=p;
    value=p;
  }
  /**
   *
   */
  public synchronized void acquire()
  {
    while (value<1)
    {
      try
      {
        long startTime=System.currentTimeMillis();
        wait(timeout);
        if (value<1 && System.currentTimeMillis()-startTime>timeout-100)
        {
          System.out.println("DEADLOCK? trying to acquire:");
          try
          {
            throw new Exception();
          }
          catch(Exception x)
          {
            printTrace(x.getStackTrace());
          }
          System.out.println("locked by:");
          printTrace(stackTrace);
        }


      }
      catch(InterruptedException x)
      {
        throw new RuntimeException("interrupted", x);
      }
    }










    try
    {
      throw new Exception();
    }
    catch(Exception x)
    {
      stackTrace=x.getStackTrace();
    }
    value--;
    owner=Thread.currentThread();
  }
  private static void printTrace(StackTraceElement[] list)
  {
    for (int i=0; i<list.length; i++)
    {
      String s=list[i].toString();
      if (!s.startsWith("org.mundo.rt.Semaphore"))
        System.out.println(s);
    }
  }
  /**
   *
   */
  public synchronized void release()
  {
    value++;
    owner=null;
    notify();
  }
  /**
   *
   */
  public synchronized boolean tryAcquire()
  {
    if (value>0)
    {
      value--;
      owner=Thread.currentThread();
      return true;
    }
    return false;
  }
  /**
   * This debugging method asserts that the semaphore has been acquired by the
   * current thread.
   */
  public synchronized void assertAcquired()
  {
    if (permits!=1)
      throw new AssertionError("assertAcquired is only supported for permits==1");
    if (owner!=Thread.currentThread())
      throw new AssertionError("assertAcquired failed");
  }




  
  private int permits;
  private int value;
  private StackTraceElement[] stackTrace;
  private Thread owner;
}
