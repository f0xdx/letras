/*
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is MundoCore Java.
 *
 * The Initial Developer of the Original Code is Telecooperation Group,
 * Department of Computer Science, Darmstadt University of Technology.
 * Portions created by the Initial Developer are
 * Copyright (C) 2001-2008 the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 * Erwin Aitenbichler
 */

package org.mundo.xml.xquery;

import org.mundo.filter.TypedMapFilter;

import java.util.HashMap;
import java.util.ArrayList;

/**
 * Builder for TypedMapFilters.
 */
class XQMapBuilder
{
  XQMapBuilder()
  {
    paths.put(new XQVar("msg"), new ArrayList<XQNode>());


  }
  ArrayList<XQNode> expandPath(XQPathExpr pathHead) throws XQuery.BuildException
  {
    ArrayList<XQNode> nodeList = new ArrayList<XQNode>();




    XQPathExpr pathElem=pathHead;
    while (pathElem!=null)
    {
      XQObject step=pathElem.step;
      if (step instanceof XQNode)
        nodeList.add((XQNode)step);
      else if (step instanceof XQVar)
      {
        ArrayList<XQNode> l = paths.get((XQVar)step);


        if (l==null)
          throw new XQuery.BuildException("variable "+((XQVar)step).name+" not bound");
        nodeList.addAll(l);
      }
      pathElem=pathElem.next;
    }
    return nodeList;
  }
  void bindPath(XQVar var, XQPathExpr pathHead) throws XQuery.BuildException
  {
    paths.put(var, expandPath(pathHead));
  }
  TypedMapFilter getOrCreateMap(TypedMapFilter parent, String name)
  {
    TypedMapFilter f=(TypedMapFilter)parent.get(name);
    if (f==null)
    {
      f=new TypedMapFilter();
      parent.putMapFilter(name, f);
    }
    return f;
  }
  TypedMapFilter mf = new TypedMapFilter();
  TypedMapFilter currentMap;
  HashMap<XQVar,ArrayList<XQNode>> paths = new HashMap<XQVar,ArrayList<XQNode>>();


}
