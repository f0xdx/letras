package org.mundo.service;


/**
 * Automatically generated distributed object class for <code>IConfigure</code>.
 * @see org.mundo.service.IConfigure
 */
public class DoIConfigure extends org.mundo.rt.DoObject implements org.mundo.service.IConfigure
{
  public DoIConfigure()
  {
  }
  public DoIConfigure(org.mundo.rt.Session session, Object obj) throws org.mundo.rt.RMCException
  {
    _bind(session, obj);
  }
  public DoIConfigure(org.mundo.rt.Channel channel) throws org.mundo.rt.RMCException
  {
    _setPublisher(channel.getSession().publish(channel.getZone(), channel.getName()));
  }
  public DoIConfigure(org.mundo.rt.DoObject o)
  {
    _assign(o);
  }
  public org.mundo.rt.ServerStub _getServerStub()
  {
    return SrvIConfigure._getObject();
  }
  public static DoIConfigure _of(org.mundo.rt.Session session, Object obj)
  {
    DoIConfigure cs=(DoIConfigure)_getDoObject(session, DoIConfigure.class, obj);
    if (cs==null)
    {
      cs=new DoIConfigure(session, obj);
      _putDoObject(session, obj, cs);
    }
    return cs;
  }
  public static DoIConfigure _of(org.mundo.rt.Service s)
  {
    return _of(s.getSession(), s);
  }
  public String _getInterfaceName()
  {
    return "org.mundo.service.IConfigure";
  }
  public static IConfigure _localObject(IConfigure obj)
  {
    if (obj instanceof org.mundo.rt.DoObject)
    {
      return (IConfigure)((org.mundo.rt.DoObject)obj)._getLocalObject();
    }
    else
    {
      return obj;
    }
  }
  public void setServiceConfig(Object p0)
  {
    if (localObj!=null) 
    {
      ((org.mundo.service.IConfigure)localObj).setServiceConfig(p0);
      return;
    }
    setServiceConfig(p0, SYNC);
  }
  public org.mundo.rt.AsyncCall setServiceConfig(Object p0, Options opt) 
  {
    org.mundo.rt.TypedMap m=new org.mundo.rt.TypedMap();
    m.putString("ptypes", "Object");
    m.putString("rtype", "");
    m.putObject("p0", p0);
    org.mundo.rt.AsyncCall call=new org.mundo.rt.AsyncCall(this, "org.mundo.service.IConfigure", "setServiceConfig", m);
    if (opt==ONEWAY)
    {
      call.invokeOneWay();
    }
    else if (opt==SYNC || opt==ASYNC)
    {
      call.invoke();
    }
    if (opt==SYNC)
    {
      try
      {
        if (!call.waitForReply())
        {
          throw call.getException();
        }
      }
      catch(RuntimeException x)
      {
        throw x;
      }
      catch(Exception x)
      {
        throw new org.mundo.rt.RMCException("unexpected exception", x);
      }
    }
    return call;
  }
  
  public Object getServiceConfig()
  {
    if (localObj!=null) 
    {
      return ((org.mundo.service.IConfigure)localObj).getServiceConfig();
    }
    org.mundo.rt.AsyncCall call=getServiceConfig(SYNC);
    return (Object)call.getObj();
  }
  public org.mundo.rt.AsyncCall getServiceConfig(Options opt) 
  {
    org.mundo.rt.TypedMap m=new org.mundo.rt.TypedMap();
    m.putString("ptypes", "");
    m.putString("rtype", "Object");
    org.mundo.rt.AsyncCall call=new org.mundo.rt.AsyncCall(this, "org.mundo.service.IConfigure", "getServiceConfig", m);
    if (opt==ONEWAY)
    {
      call.invokeOneWay();
    }
    else if (opt==SYNC || opt==ASYNC)
    {
      call.invoke();
    }
    if (opt==SYNC)
    {
      try
      {
        if (!call.waitForReply())
        {
          throw call.getException();
        }
      }
      catch(RuntimeException x)
      {
        throw x;
      }
      catch(Exception x)
      {
        throw new org.mundo.rt.RMCException("unexpected exception", x);
      }
    }
    return call;
  }
  
  public void setServiceConfigMap(org.mundo.rt.TypedMap p0)
  {
    if (localObj!=null) 
    {
      ((org.mundo.service.IConfigure)localObj).setServiceConfigMap(p0);
      return;
    }
    setServiceConfigMap(p0, SYNC);
  }
  public org.mundo.rt.AsyncCall setServiceConfigMap(org.mundo.rt.TypedMap p0, Options opt) 
  {
    org.mundo.rt.TypedMap m=new org.mundo.rt.TypedMap();
    m.putString("ptypes", "org.mundo.rt.TypedMap");
    m.putString("rtype", "");
    m.putObject("p0", p0);
    org.mundo.rt.AsyncCall call=new org.mundo.rt.AsyncCall(this, "org.mundo.service.IConfigure", "setServiceConfigMap", m);
    if (opt==ONEWAY)
    {
      call.invokeOneWay();
    }
    else if (opt==SYNC || opt==ASYNC)
    {
      call.invoke();
    }
    if (opt==SYNC)
    {
      try
      {
        if (!call.waitForReply())
        {
          throw call.getException();
        }
      }
      catch(RuntimeException x)
      {
        throw x;
      }
      catch(Exception x)
      {
        throw new org.mundo.rt.RMCException("unexpected exception", x);
      }
    }
    return call;
  }
  
  public org.mundo.rt.TypedMap getServiceConfigMap()
  {
    if (localObj!=null) 
    {
      return ((org.mundo.service.IConfigure)localObj).getServiceConfigMap();
    }
    org.mundo.rt.AsyncCall call=getServiceConfigMap(SYNC);
    return (org.mundo.rt.TypedMap)call.getObj();
  }
  public org.mundo.rt.AsyncCall getServiceConfigMap(Options opt) 
  {
    org.mundo.rt.TypedMap m=new org.mundo.rt.TypedMap();
    m.putString("ptypes", "");
    m.putString("rtype", "org.mundo.rt.TypedMap");
    org.mundo.rt.AsyncCall call=new org.mundo.rt.AsyncCall(this, "org.mundo.service.IConfigure", "getServiceConfigMap", m);
    if (opt==ONEWAY)
    {
      call.invokeOneWay();
    }
    else if (opt==SYNC || opt==ASYNC)
    {
      call.invoke();
    }
    if (opt==SYNC)
    {
      try
      {
        if (!call.waitForReply())
        {
          throw call.getException();
        }
      }
      catch(RuntimeException x)
      {
        throw x;
      }
      catch(Exception x)
      {
        throw new org.mundo.rt.RMCException("unexpected exception", x);
      }
    }
    return call;
  }
  
}