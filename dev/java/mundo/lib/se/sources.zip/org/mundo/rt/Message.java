/*
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is MundoCore Java.
 *
 * The Initial Developer of the Original Code is Telecooperation Group,
 * Department of Computer Science, Darmstadt University of Technology.
 * Portions created by the Initial Developer are
 * Copyright (C) 2001-2008 the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 * Erwin Aitenbichler
 */

package org.mundo.rt;

import org.mundo.rt.Blob;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.util.Enumeration;
import java.util.NoSuchElementException;
import java.util.Iterator;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;

/**
 * <p>A message consists of a number of chunks. Chunks store the main message
 * payload in different representations, optional (binary) attachments and
 * additional information ("headers") e.g. for routing and transport services.
 * A chunk is a tuple of <code>(name, type, content)</code>. The content is
 * stored in a <code>TypedMap</code> or in a <code>Blob</code>. A <code>TypedMap</code>
 * contains active or passive object trees and <code>Blob</code>s contain
 * e.g. binary attachments, like audio data.</p>
 *
 * <p>MundoCore is based on the concept of a <em>protocol heap</em> rather than
 * a <em>protocol stack</em>. Thus, services are permitted random-access to
 * the message data structure and information stays available on all levels.</p>
 *
 * <p>Typically, applications create <code>Message</code> objects from a
 * <code>TypedMap</code> or an <code>Object</code> (to serialize). In this
 * case, the only chunk that the application has to worry about is the following:</p>
 *
 * <table border='1'>
 *  <tr><td><b><code>name</code></b></td>
 *  <td><b><code>type</code></b></td>
 *  <td><b><code>content</code></b></td>
 *  <td><b>Description</b></td></tr>
 *  <tr><td><code>main</code></td><td><code>active</code></td>
 *   <td><code>TypedMap</code></td><td>Contains the message payload</td></tr>
 * </table>
 *
 * <p>When the message is transported to a remote node, various services
 * act on the contents of the message. A message received from a remote node
 * might look like:</p>
 *
 * <table border='1'>
 *  <tr><td><b><code>name</code></b></td>
 *  <td><b><code>type</code></b></td>
 *  <td><b><code>content</code></b></td>
 *  <td><b>Description</b></td></tr>
 *  <tr><td><code>main</code></td><td><code>active</code></td>
 *   <td><code>TypedMap</code></td><td>Contains the message payload as an active
 *   object tree. In most cases, this is the only chunk interesting to the
 *   application level.</td></tr>
 *  <tr><td><code>main</code></td><td><code>passive</code></td>
 *   <td><code>TypedMap</code></td><td>Contains the message payload as a passive
 *   object tree. Routing services create this chunk from the chunk containing
 *   the active representation.</td></tr>
 *  <tr><td><code>ers</code></td><td><code>passive</code></td>
 *   <td><code>TypedMap</code></td><td>Contains header information, like channel
 *   names and zone information, or control messages for the
 *   <code>EventRoutingService</code>.</td></tr>
 *  <tr><td><code>rs</code></td><td><code>passive</code></td>
 *   <td><code>TypedMap</code></td><td>Contains header information or control
 *   messages for the <code>RoutingService</code>.</td></tr>
 *  <tr><td><code>ipts</code></td><td><code>passive</code></td>
 *   <td><code>TypedMap</code></td><td>Contains header information or control
 *   messages for the <code>IPTransportService</code>.</td></tr>
 *  <tr><td><code>all</code></td><td><code>binser</code></td>
 *   <td><code>Blob</code></td><td>Contains all other chunks of the message
 *   in a binary-serialized form. This chunk is created at the level of
 *   transport services.</td></tr>
 * </table>
 *
 * @author Erwin Aitenbichler
 */
public final class Message implements Cloneable
                                    , Iterable<Message.Chunk>
{
  /**
   * Initializes an empty message.
   */
  public Message()
  {
  }
  /**
   * Initializes a new message from a <code>TypedMap</code>. This constructor
   * creates a new chunk <code>("main", "active", map)</code>.
   * @param map  the map to put into the message.
   */
  public Message(TypedMap map)
  {
    chunks.put("main:active", new Chunk("main", "active", map));
  }
  /**
   * Initializes a message with the specified request and map.
   * This constructor is deprecated, since it is no longer required to specify
   * a SOAP request for ordinary messages. For compatibility, the specified
   * request is written into the map with <code>map.putString("request", request);</code>.
   *
   * @param request  the request.
   * @param map      the message payload.
   * @deprecated
   */
  public Message(String request, TypedMap map)
  {
    map.putString("request", request);
    chunks.put("main:active", new Chunk("main", "active", map));
  }
  /**
   * Initializes a new message from a <code>TypedMap</code>.
   * @param name  the chunk name.
   * @param type  the chunk type.
   * @param map   the <code>TypedMap</code> containing a structured payload.
   */
  public Message(String name, String type, TypedMap map)
  {
    chunks.put(name+":"+type, new Chunk(name, type, map));
  }
  /**
   * Initializes a new message from a <code>Blob</code>.
   * @param name  the chunk name.
   * @param type  the chunk type.
   * @param blob  the <code>Blob</code> containing an unstructured payload.
   */
  public Message(String name, String type, Blob blob)
  {
    chunks.put(name+":"+type, new Chunk(name, type, blob));
  }
  /**
   * Creates a new message from an <code>Object</code>. This named constructor
   * creates a new chunk <code>("main", "active", map)</code> and associates
   * the object with the key <code>object</code> in <code>map</code>.
   * @param obj  the object to put into the message.
   */
  public static Message fromObject(Object obj)
  {
    TypedMap map=new TypedMap();
    map.put("object", obj);
    return new Message("main", "active", map);
  }
  /**
   * Returns a deep copy of this message.
   * @return  a deep copy of this message; and <code>null</code> in case of an error.
   */
  public Object clone()
  {
    Message msg=new Message();
    msg.chunks=chunks;
    msg.stack=stack;
    msg.curHandler=curHandler;
    msg.deepenCopy();
    return msg;
  }
  /**
   * Returns a shallow copy of this message. This operation does not copy anything
   * of the content, only the protocol stack and processing state.
   * @return  a shallow copy of this message.
   */
  public Message shallowCopy()
  {
    Message msg=new Message();
    msg.chunks=chunks;
    msg.stack=stack;
    msg.curHandler=curHandler;
    return msg;
  }
  /**
   * Returns a shallow copy of this message with an own chunks list and address
   * chunk. New chunks can be added to the copy without side-effects on the original.
   * The protocol stack and the current handler is also copied.
   * @return  a shallow copy of this message.
   */
  public Message copyFrame()
  {
    Message msg=new Message();
    msg.stack=stack;
    msg.curHandler=curHandler;
    msg.chunks=new HashMap<String,Chunk>(chunks);


    TypedMap map=getMap("address", "passive");
    if (map!=null)
      msg.put("address", "passive", (TypedMap)map.clone());
    return msg;
  }
  /**
   * Clones mutable aggregated objects.
   */
  private void deepenCopy()
  {
    HashMap<String,Chunk> srcChunks=chunks;
    chunks=new HashMap<String,Chunk>();
    for (Map.Entry<String,Chunk> e : srcChunks.entrySet())
      chunks.put(e.getKey(), (Chunk)e.getValue().clone());








  }
  /**
   * Returns the hash code value for this chunk.
   */
  @Override
  public int hashCode()
  {
    return chunks.hashCode()+
           System.identityHashCode(stack)+
           System.identityHashCode(curHandler);
  }
  /**
   * Creates or replaces a chunk. The method associates the specified
   * <code>name</code> and <code>type</code> with the specified <code>map</code>.
   * If a chunk with the same <code>name</code> and <code>type</code> already
   * exists, the existing chunk is replaced.
   * @param name  the chunk name.
   * @param type  the chunk type.
   * @param map   the <code>TypedMap</code> containing a structured payload.
   */
  public void put(String name, String type, TypedMap map)
  {
    chunks.put(name+":"+type, new Chunk(name, type, map));
  }
  /**
   * Creates or replaces a chunk. The method associates the specified
   * <code>name</code> and <code>type</code> with the specified <code>blob</code>.
   * If a chunk with the same <code>name</code> and <code>type</code> already
   * exists, the existing chunk is replaced.
   * @param name  the chunk name.
   * @param type  the chunk type.
   * @param blob  the <code>Blob</code> containing an unstructured payload.
   */
  public void put(String name, String type, Blob blob)
  {
    chunks.put(name+":"+type, new Chunk(name, type, blob));
  }
  /**
   * Returns the content to which the specified chunk <code>name</code>
   * and <code>type</code> is mapped.
   * @param name  the chunk name.
   * @param type  the chunk type.
   * @return  the <code>Blob</code> object in the requested chunk; or
   *          <code>null</code> if no mapping for the specified <code>name</code>
   *          and <code>type</code> exists.
   * @throws ClassCastException  if the specified chunk does not contain
   *         a <code>Blob</code>.
   */
  public Blob getBlob(String name, String type)
  {
    Chunk chunk=(Chunk)chunks.get(name+":"+type);
    if (chunk==null)
      return null;
    return (Blob)chunk.content;
  }
  /**
   * Returns the content to which the specified chunk <code>name</code>
   * is mapped. The method finds the first chunk with a matching <code>name</code>.
   * The <code>type</code> is ignored.
   * @param name  the chunk name.
   * @return  the <code>Blob</code> object in the requested chunk; or
   *          <code>null</code> if no mapping for the specified <code>name</code>
   *          exists.
   */
  public Blob getBlob(String name)
  {
    Iterator iter=iterator();
    while (iter.hasNext())
    {
      Chunk c=(Chunk)iter.next();
      if (c.name.equals(name))
        return (Blob)c.content;
    }
    return null;
  }
  /**
   * Returns the content to which the specified chunk <code>name</code>
   * and <code>type</code> is mapped.
   * @param name  the chunk name.
   * @param type  the chunk type.
   * @return  the <code>TypedMap</code> object in the requested chunk; or
   *          <code>null</code> if no mapping for the specified <code>name</code>
   *          and <code>type</code> exists.
   * @throws ClassCastException  if the specified chunk does not contain
   *         a <code>TypedMap</code>.
   */
  public TypedMap getMap(String name, String type)
  {
    Chunk chunk=(Chunk)chunks.get(name+":"+type);
    if (chunk==null)
      return null;
    return (TypedMap)chunk.content;
  }
  /**
   *
   */
  public TypedMap getOrCreateMap(String name, String type)
  {
    Chunk chunk=(Chunk)chunks.get(name+":"+type);
    if (chunk==null)
    {
      TypedMap map=new TypedMap();
      put(name, type, map);
      return map;
    }
    return (TypedMap)chunk.content;
  }
  /**
   * Returns the main payload stored in the message. This is the content of the
   * chunk <code>("main", "active", TypedMap)</code>.
   * @return  the content of the chunk <code>("main", "active", TypedMap)</code>;
   *          or <code>null</code> if the chunk does not exist.
   */
  public TypedMap getMap()
  {
    Chunk chunk=(Chunk)chunks.get("main:active");
    if (chunk==null)
      return null;
    return (TypedMap)chunk.content;
  }
  /**
   * Returns the object stored in the message. This is the object associated
   * with the key <code>object</code> in the message's main payload.
   * @return  the object stored in the message.
   * @throws  NoSuchElementException if the chunk does not exist or the
   *          mapping for <code>object</code> does not exist.
   */
  public Object getObject() throws NoSuchElementException
  {
    TypedMap map=getMap("main", "active");
    if (map==null)
      throw new NoSuchElementException("chunk main:active does not exist");
    return map.getObject("object");
  }
  /**
   * Returns the request string. This is the string <code>request</code> in the
   * chunk <code>main:active</code>.
   * @deprecated
   */
  public String getRequest() throws NoSuchElementException
  {
    TypedMap map=getMap("main", "active");
    if (map==null)
      throw new NoSuchElementException("chunk main:active does not exist");
    return map.getString("request");
  }
  /**
   * Returns whether the message is empty.
   * @return  <code>true</code> if the message does not contain any chunks;
   *          or <code>false</code> otherwise.
   */
  public boolean isEmpty()
  {
    return chunks.size()==0;
  }
  /**
   * Removes the chunk associated with the specified <code>name</code> and
   * <code>type</code> from the message.
   * @param name  the name of the chunk to remove.
   * @param type  the type of the chunk to remove.
   */
  public void remove(String name, String type)
  {
    chunks.remove(name+":"+type);
  }
  /**
   * Removes all but the chunk associated with the specified <code>name</code>
   * and <code>type</code> from the message.
   * @param name  the name of the chunk to keep.
   * @param type  the type of the chunk to keep.
   */
  public void retain(String name, String type)
  {
    Chunk chunk=(Chunk)chunks.get(name+":"+type);
    chunks.clear();
    if (chunk!=null)
      chunks.put(chunk.name+":"+chunk.type, chunk);
  }
  /**
   * Returns all chunks matching the specified type.
   * @param typeFilter  the type name to use as filter.
   * @return  a <code>TypedArray</code> containing all chunks that match the
   *          specified type. The chunks are of class <code>Message.Chunk</code>.
   */
  public TypedArray getChunks(String typeFilter)
  {
    TypedArray list=new TypedArray();
    Iterator<Chunk> iter=chunks.values().iterator();
    while (iter.hasNext())
    {
      Chunk c=iter.next();
      if (c.type.equals(typeFilter))
        list.add(c);
    }
    return list;
  }













  /**
   * Returns an iterator over all chunks of a certain type.
   * @param typeFilter  the type name to use as filter.
   * @return  an iterator over all chunks of a certain type. The iterator provides
   *          objects of class <code>Message.Chunk</code>.
   */
  private Iterator iterator(String typeFilter)
  {
    return getChunks(typeFilter).iterator();
  }
  /**
   * Returns an iterator over the chunks in this message.
   * @return  an iterator over all chunks of the message. The iterator provides
   *          objects of class <code>Message.Chunk</code>.
   */
  public Iterator<Chunk> iterator()
  {
    return chunks.values().iterator();
  }





  /**
   * Passivates the message. For each chunk with type <code>active</code>, a
   * chunk with the same name and type <code>passive</code> is created.
   * The content of the active chunk is passivated, i.e. externalized and
   * converted to base types, and written to the corresponding passive chunk.
   * @see TypedContainer#passivate(Object)
   */
  public void passivate() throws Exception
  {
    for (Iterator iter=iterator("active"); iter.hasNext();)
    {
      Chunk c=(Chunk)iter.next();
      put(c.name, "passive", (TypedMap)TypedContainer.passivate(c.content));
    }
  }
  /**
   * Activates the message. For each chunk with type <code>passive</code>, a
   * chunk with the same name and type <code>active</code> is created.
   * The content of the passive chunk is activated, i.e. objects are
   * instantiated from their external representations, and written to the
   * active chunk.
   * @see TypedContainer#activate(Object)
   */
  public void activate() throws Exception
  {
    for (Iterator iter=iterator("passive"); iter.hasNext();)
    {
      Chunk c=(Chunk)iter.next();
      put(c.name, "active", (TypedMap)TypedContainer.activate(c.content));
    }
  }
  /**
   * Returns a string representation of the message.
   */
  public String toString()
  {
    if (chunks.size()==0)
      return "(empty)";
    StringBuffer sb=new StringBuffer();
    for (Iterator iter=iterator(); iter.hasNext();)
    {
      Chunk chunk=(Chunk)iter.next();
      sb.append(chunk.name+":"+chunk.type+":");
      if (chunk.content instanceof TypedMap)
        sb.append(chunk.content.toString());
      else
        sb.append(((Blob)chunk.content).toASCIIString());
      sb.append("\n");
    }
    return sb.toString();
  }

  /**
   * Returns the next message handler for this message while traversing
   * the communication stack downwards.
   */
/*
  public ProtocolStack.Handler nextDown()
  {
    if (stack==null)
      throw new IllegalStateException("no communication stack defined");
    return stack.get(++curHandler);
  }
*/
  /**
   * Returns the next message handler for this message while traversing
   * the communication stack downwards.
   */
/*
  public ProtocolStack.Handler nextUp()
  {
    if (stack==null)
      throw new IllegalStateException("no communication stack defined");
    if (curHandler<1)
      return null;
    return stack.get(--curHandler);
  }
*/
  /**
   * Returns the current handler object for this message.
   */
  public ProtocolStack.Handler getHandler()
  {
    return curHandler;
  }
  /**
   * Sets the current handler object for this message.
   */
  public void setHandler(ProtocolStack.Handler h)
  {
    curHandler = h;
  }
  /**
   * Sets the protocol stack for this message.
   */
  public void setStack(ProtocolStack s)
  {
    stack = s;
    curHandler = stack.get(0);
  }
  /**
   * Sets the protocol stack for this message. Advance the current handler
   * to the first handler that implements the specified class or interface.
   */
  public void setStack(ProtocolStack s, Class c)
  {
    stack = s;
    curHandler = stack.findHandler(c);
    if (curHandler==null)
      throw new IllegalArgumentException("handler not found: "+c.getName());
  }
  public void setStack(ProtocolStack s, ProtocolStack.Handler h)
  {
    stack = s;
    curHandler = h;
  }
  /**
   *
   */
/*
  public void setStackPos(Class c)
  {
    for (int i=0; i<stack.size(); i++)
    {
      Object obj=stack.get(i).getHandler();
      if (c.isAssignableFrom(obj.getClass()))
      {
        curHandler=i;
        return;
      }
    }
  }
*/
  /**
   * Returns the protocol stack for this message.
   */
  public ProtocolStack getStack()
  {
    return stack;
  }
  /**
   * Copies the protocol stack and processing state from the specified Message.
   */
  public void copyStackFrom(Message m)
  {
    stack = m.stack;
    curHandler = m.curHandler;
  }
  /**
   *
   */
  public void setType(String t)
  {
    TypedMap map = getMap("address", "passive");
    if (map==null)
    {
      map = new TypedMap();
      put("address", "passive", map);
    }
    map.putString("mimeType", t);
  }
  /**
   *
   */
  public String getType()
  {
    TypedMap map = getMap("address", "passive");
    if (map==null)
      return null;
    return map.getString("mimeType");    
  }

  /**
   * This class encapsulates a chunk of the message.
   * @author Erwin Aitenbichler
   */
  public static class Chunk implements Cloneable
  {
    /**
     * Initializes an empty chunk.
     */
    private Chunk()
    {
    }
    /**
     * Initializes a new chunk from the specified name, type and content.
     */
    Chunk(String name, String type, Object content)
    {
      this.name = name;
      this.type = type;
      this.content = content;
    }
    /**
     * Creates a deep copy of the chunk.
     */
    @Override
    public Object clone()
    {
      Chunk c = new Chunk();
      c.name = name;
      c.type = type;
      if (content instanceof TypedMap)
        c.content = ((TypedMap)content).clone();
      else if (content instanceof Blob)
        c.content = ((Blob)content).clone();
      return c;
    }
    /**
     * Returns a string representation of the chunk.
     */
    @Override
    public String toString()
    {
      return name+":"+type+":"+content;
    }
    /**
     * Returns the hash code value for this chunk.
     */
    @Override
    public int hashCode()
    {
      int hc=0;
      if (name!=null)
        hc += name.hashCode();
      if (type!=null)
        hc += type.hashCode();
      if (content!=null)
        hc += content.hashCode();
      return hc;
    }
    /**
     * the chunk name.
     */
    public String name;
    /**
     * the chunk type.
     */
    public String type;
    /**
     * the chunk content. content is either of class <code>TypedMap</code>
     * or <code>Blob</code>.
     */
    public Object content;
  }

  private HashMap<String,Chunk> chunks = new HashMap<String,Chunk>();


  private ProtocolStack stack;
  private ProtocolStack.Handler curHandler;
}
