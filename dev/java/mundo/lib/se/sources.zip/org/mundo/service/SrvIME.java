package org.mundo.service;


/**
 * Automatically generated server stub for <code>IME</code>
 * @see org.mundo.service.IME
 */
public class SrvIME extends org.mundo.rt.ServerStub
{
  public SrvIME()
  {
  }
  private static org.mundo.rt.ServerStub _obj;
  public static org.mundo.rt.ServerStub _getObject()
  {
    if (_obj==null)
    {
      _obj=new SrvIME();
    }
    return _obj;
  }
  public void invoke(Object o, org.mundo.rt.TypedMap m, org.mundo.rt.TypedMap r)
  {
    String n=m.getString("request");
    IME p=(IME)o;
    try
    {
      if (n.equals("getName") && m.getString("ptypes").equals(""))
      {
        r.putString("value", p.getName());
        return;
      }
      if (n.equals("getZoneName") && m.getString("ptypes").equals(""))
      {
        r.putString("value", p.getZoneName());
        return;
      }
      if (n.equals("_getMethods") && m.getString("ptypes").equals(""))
      {
        r.putString("value",
        "s getName()\n"+
        "s getZoneName()\n"+
        "");
        return;
      }
    }
    catch(Exception x)
    {
      exceptionOccured(x, o, m, r);
    }
  }
}