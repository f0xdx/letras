/*
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is MundoCore Java.
 *
 * The Initial Developer of the Original Code is Telecooperation Group,
 * Department of Computer Science, Darmstadt University of Technology.
 * Portions created by the Initial Developer are
 * Copyright (C) 2001-2008 the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 * Erwin Aitenbichler
 */

package org.mundo.net.broker;

import java.util.ArrayList;
import java.util.Iterator;

import org.mundo.rt.IBCLProvider;
import org.mundo.rt.IReceiver;
import org.mundo.rt.Message;
import org.mundo.rt.MessageContext;
import org.mundo.rt.Mundo;
import org.mundo.rt.Service;
import org.mundo.rt.Signal;
import org.mundo.rt.Subscriber;
import org.mundo.rt.Publisher;
import org.mundo.rt.TypedMap;

/**
 * A message routing service that supports content-based Publish/Subscribe.
 * @author Erwin Aitenbichler
 */
public class ContentBroker
       extends Service
       implements IBCLProvider.ISignal, IReceiver
{
  /**
   * Initializes a new <code>ContentRoutingService</code>.
   */
  public ContentBroker()
  {
  }
  /**
   * Initializes this service.
   */
  public void init()
  {
    // watch new subscriptions in the local runtime
    Signal.connect("rt", IBCLProvider.ISignal.class, this);
    
    getSession().subscribe("lan", "ContentSubscription", this);
  }
  public void publisherAdded(Publisher p) /* IBCLProvider.ISignal */
  {
  }
  public void publisherRemoved(Publisher p) /* IBCLProvider.ISignal */
  {
  }
  public void subscriberAdded(Subscriber s) /* IBCLProvider.ISignal */
  {
    if (!(s.getParam() instanceof ContentSubscription))
      return;
    ContentSubscription cs=(ContentSubscription)s.getParam();
    subscriptions.add(s);
  }
  public void subscriberRemoved(Subscriber s) /* IBCLProvider.ISignal */
  {
  }
  public void received(Message msg, MessageContext ctx)
  {
    TypedMap map=msg.getMap("main", "passive");
    if (map==null)
    {
      try
      {
        msg.passivate();
      }
      catch(Exception x)
      {
        x.printStackTrace();
        return;
      }
    }
    map=msg.getMap("main", "passive");
    
    Iterator iter=subscriptions.iterator();
    Subscriber s;
    while (iter.hasNext())
    {
      s=(Subscriber)iter.next();
      if (((ContentSubscription)s.getParam()).getFilter().matches(map))
      {
        if (ctx.channel.getSession()!=s.getChannel().getSession() ||
            (ctx.publisher!=null && ctx.publisher.getLocalLoopback()))
        {
          Mundo.bcl.send(s, msg, ctx);
        }
      }
    }
  }
  private ArrayList<Subscriber> subscriptions = new ArrayList<Subscriber>();


}
