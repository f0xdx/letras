/*
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is MundoCore Java.
 *
 * The Initial Developer of the Original Code is Telecooperation Group,
 * Department of Computer Science, Darmstadt University of Technology.
 * Portions created by the Initial Developer are
 * Copyright (C) 2001-2008 the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 * Erwin Aitenbichler
 */

package org.mundo.rt;

import java.util.Enumeration;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.Collection;
import java.util.List;
import java.util.ListIterator;

/**
 * <code>TypedArray</code> is a list class that provides access methods for
 * boxing/unboxing of base types.
 *
 * @author Erwin Aitenbichler
 */
public final class TypedArray extends TypedContainer implements List
<Object>
{
  /**
   * Creates an empty array.
   */
  public TypedArray()
  {
  }
  /**
   * Creates an empty array with the specified active class name.
   * @param acName  the active class name.
   */
  public TypedArray(String acName)
  {
    activeClassName=acName;
  }
  /**
   * Constructs a new @code{TypedArray} with the same entries as the specified array.
   */
  public TypedArray(TypedArray a)
  {
    addAll(a);
  }
  /**
   * Inserts the specified element at the specified position in this list.
   * Shifts the element currently at that position
   * (if any) and any subsequent elems to the right (adds one to their
   * indices). 
   * @param index  index at which the specified element is to be inserted.
   * @param obj    object to be inserted.
   * @throws  IndexOutOfBoundsException if index is out of range
   *          <code>(index < 0 || index > size())</code>.
   * @see java.util.List#add(int,Object)
   */
  public void add(int index, Object obj) // List
  {


    elems.add(index, obj);
  }
  /**
   * Appends the specified element to the end of this list.
   * @param obj    object to be inserted.
   * @return  <code>true</code> (as per the general contract of Collection.add).
   * @see java.util.List#add(Object)
   */
  public boolean add(Object obj) // List
  {



    return elems.add(obj);
  }
  /**
   * Appends all of the elems in the specified collection to the end of
   * this list, in the order that they are returned by the specified collection's
   * iterator. The behavior of this operation is unspecified if the specified
   * collection is modified while the operation is in progress.
   * @param c  the elems to be inserted into this list.
   * @return  <code>true</code> if this list changed as a result of the call.
   * @throws NullPointerException  if the specified collection is <code>null.</code>
   * @see java.util.List#addAll(Collection)
   */










  public boolean addAll(Collection<? extends Object> c) // List


  {
    return elems.addAll(c);
  }
  /**
   * Inserts all of the elems in the specified Collection into this list,
   * starting at the specified position. Shifts the element currently at that
   * position (if any) and any subsequent elems to the right (increases their
   * indices). The new elems will appear in the list in the order that they
   * are returned by the specified Collection's iterator.
   * @param index  index at which to insert first element from the specified collection.
   * @param c  elems to be inserted into this list.
   * @return  <code>true</code> if this list changed as a result of the call.
   * @throws IndexOutOfBoundsException  if index out of range
   *         <code>(index < 0 || index > size()).</code>
   * @throws NullPointerException  if the specified collection is <code>null.</code>
   * @see java.util.List#addAll(int,Collection)
   */
  public boolean addAll(int index, Collection<? extends Object> c) // List


  {
    return elems.addAll(index, c);
  }
  /**
   * Removes all of the elems from this list. The list will be empty after
   * this call returns.
   * @see java.util.List#clear()
   */
  public void clear() // List
  {


    elems.clear();
  }
  /**
   * Returns <code>true</code> if this list contains the specified element.
   * @param o  element whose presence in this List is to be tested.
   * @return  <code>true</code> if the specified element is present;
   *          <code>false</code> otherwise.
   * @see java.util.List#contains(Object)
   */
  public boolean contains(Object o) // List
  {
    return elems.contains(o);
  }
  /**
   * Returns <code>true</code> if this collection contains all of the elems
   * in the specified collection.
   * @param c  collection to be checked for containment in this collection.
   * @return  <code>true</code> if this collection contains all of the elems
   *          in the specified collection.
   * @throws  <code>NullPointerException</code> if the specified collection
   *          is <code>null</code>.
   * @see java.util.List#containsAll(Collection)
   */
  public boolean containsAll(Collection c) // List
  {
    return elems.containsAll(c);
  }
  /**
   * Compares the specified object with this array for equality. Returns
   * <code>true</code> if the given object is also a <code>TypedArray</code>
   * and the two arrays contain equal elems. Furthermore, the represented
   * active class has to be identical.
   * @return  <code>true</code> if the objects are equal; and
   *          <code>false</code> otherwise.
   * @see java.lang.Object#equals(Object)
   */
  public boolean equals(Object obj) // List
  {
    TypedArray array=(TypedArray)obj;
    if (!elems.equals(array.elems))
      return false;
    if (activeClassName==array.activeClassName)
      return true;
    if (activeClassName==null || array.activeClassName==null)
      return false;
    return activeClassName.equals(array.activeClassName);
  }
  /**
   * Returns the element at the specified position in this list.
   * @param index  index of element to return.
   * @return  the element at the specified position in this list.
   * @throws IndexOutOfBoundsException  if index is out of range
   *         <code>(index < 0 || index >= size())</code>.
   * @see java.util.List#get(int)
   */
  public Object get(int index) // List
  {


    return elems.get(index);
  }
  /**
   * Returns the hash code value for this list.
   * @return  the hash code value for this list.
   * @see  java.util.List#hashCode()
   */
  public int hashCode() // List
  {
    return elems.hashCode();
  }
  /**
   * Searches for the first occurence of the given argument, testing for equality
   * using the <code>equals</code> method.
   * @param o  an object.
   * @return  the index of the first occurrence of the argument in this list;
   *          returns <code>-1</code> if the object is not found.
   * @see java.util.List#indexOf(Object)
   */
  public int indexOf(Object o) // List
  {
    return elems.indexOf(o);
  }
  /**
   * Tests if this list has no elems.
   * @return  <code>true</code> if this list has no elems;
   *          <code>false</code> otherwise.
   * @see java.util.List#isEmpty()
   */
  public boolean isEmpty() // List
  {
    return elems.isEmpty();
  }
  /**
   * Returns an iterator over the elems in this list in proper sequence.
   * @return  an iterator over the elems in this list in proper sequence.
   * @see java.util.List#iterator()
   */
  public Iterator<Object> iterator() // List


  {


    return elems.iterator();
  }









  /**
   * Returns the index in this list of the last occurence of the specified
   * element, or <code>-1</code> if the list does not contain this element.
   * @param o  element to search for.
   * @return  the index in this list of the last occurence of the specified
   *          element, or <code>-1</code> if the list does not contain this element.
   * @see java.util.List#lastIndexOf(Object)
   */
  public int lastIndexOf(Object o) // List
  {
    return elems.lastIndexOf(o);
  }
  /**
   * Returns an iterator of the elems in this list (in proper sequence).
   * @return  an iterator of the elems in this list (in proper sequence).
   * @see java.util.List#listIterator()
   */
  public ListIterator<Object> listIterator() // List


  {
    return elems.listIterator();
  }
  /**
   * Returns a list iterator of the elems in this list (in proper sequence),
   * starting at the specified position in the list.
   * @param index  index of the first element to be returned from the list iterator
   *               (by a call to the next method).
   * @see java.util.List#listIterator(int)
   */
  public ListIterator<Object> listIterator(int index) // List


  {
    return elems.listIterator(index);
  }
  /**
   * Removes the element at the specified position in this list. Shifts any
   * subsequent elems to the left (subtracts one from their indices).
   * @param index  the index of the element to removed.
   * @return  the element that was removed from the list.
   * @throws IndexOutOfBoundsException  if index out of range
   *         <code>(index < 0 || index >= size())</code>.
   * @see java.util.List#remove(int)
   */
  public Object remove(int index) // List
  {




    return elems.remove(index);
  }
  /**
   * Removes a single instance of the specified element from this collection,
   * if it is present.
   * @param o  element to be removed from this collection, if present.
   * @return  <code>true</code> if the collection contained the specified element.
   * @see java.util.List#remove(Object)
   */
  public boolean remove(Object o) // List
  {


    return elems.remove(o);
  }
  /**
   * Removes from this collection all of its elems that are contained
   * in the specified collection.
   * @param c  elems to be removed from this collection.
   * @return  <code>true</code> if this collection changed as a result of the call.
   * @throws NullPointerException  if the specified collection is <code>null</code>.
   * @see java.util.List#removeAll(Collection)
   */
  public boolean removeAll(Collection c) // List
  {
    return elems.removeAll(c);
  }
  /**
   * Retains only the elems in this collection that are contained in the
   * specified collection.
   * @param c  elems to be retained in this collection.
   * @return  <code>true</code> if this collection changed as a result of the call.
   * @throws NullPointerException  if the specified collection is <code>null</code>.
   * @see java.util.List#retainAll(Collection)
   */
  public boolean retainAll(Collection c) // List
  {
    return elems.retainAll(c);
  }
  /**
   * Replaces the element at the specified position in this list with the
   * specified element.
   * @param index  index of element to replace.
   * @param o  element to be stored at the specified position.
   * @return  the element previously at the specified position.
   * @throws IndexOutOfBoundsException  if index out of range
   *         <code>(index < 0 || index >= size())</code>.
   * @see java.util.List#set(int,Object)
   */
  public Object set(int index, Object o) // List
  {




    return elems.set(index, o);
  }
  /**
   * Returns the number of elems in this list.
   * @return  the number of elems in this list.
   * @see java.util.List#size()
   */
  public int size() // List
  {
    return elems.size();
  }
  /**
   * Returns a view of the portion of this list between fromIndex, inclusive,
   * and toIndex, exclusive.
   * @param fromIndex  low endpoint (inclusive) of the subList.
   * @param toIndex  high endpoint (exclusive) of the subList.
   * @return  a view of the specified range within this list.
   * @throws IndexOutOfBoundsException  if index out of range
   *         <code>(index < 0 || index >= size())</code>.
   * @throws IllegalArgumentException  endpoint indices out of order
   *         <code>(fromIndex > toIndex)</code>.
   * @see java.util.List#subList(int,int)
   */
  public List<Object> subList(int fromIndex, int toIndex) // List


  {
    return elems.subList(fromIndex, toIndex);
  }
  /**
   * Returns an array containing all of the elems in this list in the
   * correct order.
   * @return  an array containing the elems of the list.
   * @see java.util.List#toArray()
   */
  public Object[] toArray() // List
  {






    return elems.toArray();
  }
  /**
   * Returns an array containing all of the elems in this list in the correct
   * order; the runtime type of the returned array is that of the specified array.
   * If the list fits in the specified array, it is returned therein. Otherwise,
   * a new array is allocated with the runtime type of the specified array and the
   * size of this list.
   * @param a  the array into which the elems of the list are to be stored,
   *           if it is big enough; otherwise, a new array of the same runtime
   *           type is allocated for this purpose.
   * @throws ArrayStoreException  if the runtime type of a is not a supertype
   *         of the runtime type of every element in this list.
   * @see java.util.List#toArray(Object[])
   */
  public <T> T[] toArray(T[] a)


  {
    return elems.toArray(a);
  }
  /**
   * Appends a <code>byte</code> at the end of the array.
   * The value is internally stored using the <code>Byte</code> wrapper class.
   * @param b  the value to append.
   */
  public void addByte(byte b)
  {
    add(new Byte(b));
  }
  /**
   * Appends a <code>short</code> at the end of the array.
   * The value is internally stored using the <code>Short</code> wrapper class.
   * @param s  the value to append.
   */
  public void addShort(short s)
  {
    add(new Short(s));
  }
  /**
   * Appends an <code>int</code> at the end of the array.
   * The value is internally stored using the <code>Integer</code> wrapper class.
   * @param i  the value to append.
   */
  public void addInt(int i)
  {
    add(new Integer(i));
  }
  /**
   * Appends an <code>long</code> at the end of the array.
   * The value is internally stored using the <code>Long</code> wrapper class.
   * @param l  the value to append.
   */
  public void addLong(long l)
  {
    add(new Long(l));
  }
  /**
   * Appends an <code>float</code> at the end of the array.
   * The value is internally stored using the <code>Float</code> wrapper class.
   * @param f  the value to append.
   */
  public void addFloat(float f)
  {
    add(new Float(f));
  }
  /**
   * Appends an <code>double</code> at the end of the array.
   * The value is internally stored using the <code>Double</code> wrapper class.
   * @param d  the value to append.
   */
  public void addDouble(double d)
  {
    add(new Double(d));
  }
  /**
   * Appends an <code>char</code> at the end of the array.
   * The value is internally stored using the <code>Character</code> wrapper class.
   * @param c  the value to append.
   */
  public void addChar(char c)
  {
    add(new Character(c));
  }
  /**
   * Appends an <code>boolean</code> at the end of the array.
   * The value is internally stored using the <code>Boolean</code> wrapper class.
   * @param b  the value to append.
   */
  public void addBoolean(boolean b)
  {
    add(new Boolean(b));
  }
  /**
   * Appends an <code>String</code> at the end of the array.
   * @param s  the string to append.
   */
  public void addString(String s)
  {
    add(s);
  }
  /**
   * Appends a <code>GUID</code> at the end of the array.
   * @param g  the <code>GUID</code> to append.
   */
  public void addGUID(GUID g)
  {
    add(g);
  }

  /**
   * Returns the <code>byte</code> element at the specified position in this array.
   * @param i  the element index.
   * @return  the value at the specified index.
   * @throws IndexArrayOutOfBoundsException  if the specified index is out of range.
   * @throws NullPointerException  if the element at the specified index is <code>null</code>.
   * @throws ClassCastException  if the element at the specified index is not
   *         a <code>Byte</code> wrapper object.
   */
  public byte getByte(int i)
  {
    return ((Byte)get(i)).byteValue();
  }
  /**
   * Returns the <code>short</code> element at the specified position in this array.
   * @param i  the element index.
   * @return  the value at the specified index.
   * @throws IndexArrayOutOfBoundsException  if the specified index is out of range.
   * @throws NullPointerException  if the element at the specified index is <code>null</code>.
   * @throws ClassCastException  if the element at the specified index is not
   *         a <code>Short</code> wrapper object.
   */
  public short getShort(int i)
  {
    return ((Short)get(i)).shortValue();
  }
  /**
   * Returns the <code>int</code> element at the specified position in this array.
   * @param i  the element index.
   * @return  the value at the specified index.
   * @throws IndexArrayOutOfBoundsException  if the specified index is out of range.
   * @throws NullPointerException  if the element at the specified index is <code>null</code>.
   * @throws ClassCastException  if the element at the specified index is not
   *         a <code>Integer</code> wrapper object.
   */
  public int getInt(int i)
  {
    return ((Integer)get(i)).intValue();
  }
  /**
   * Returns the <code>long</code> element at the specified position in this array.
   * @param i  the element index.
   * @return  the value at the specified index.
   * @throws IndexArrayOutOfBoundsException  if the specified index is out of range.
   * @throws NullPointerException  if the element at the specified index is <code>null</code>.
   * @throws ClassCastException  if the element at the specified index is not
   *         a <code>Long</code> wrapper object.
   */
  public long getLong(int i)
  {
    return ((Long)get(i)).longValue();
  }
  /**
   * Returns the <code>float</code> element at the specified position in this array.
   * @param i  the element index.
   * @return  the value at the specified index.
   * @throws IndexArrayOutOfBoundsException  if the specified index is out of range.
   * @throws NullPointerException  if the element at the specified index is <code>null</code>.
   * @throws ClassCastException  if the element at the specified index is not
   *         a <code>Float</code> wrapper object.
   */
  public float getFloat(int i)
  {
    return ((Float)get(i)).floatValue();
  }
  /**
   * Returns the <code>double</code> element at the specified position in this array.
   * @param i  the element index.
   * @return  the value at the specified index.
   * @throws IndexArrayOutOfBoundsException  if the specified index is out of range.
   * @throws NullPointerException  if the element at the specified index is <code>null</code>.
   * @throws ClassCastException  if the element at the specified index is not
   *         a <code>Double</code> wrapper object.
   */
  public double getDouble(int i)
  {
    return ((Double)get(i)).doubleValue();
  }
  /**
   * Returns the <code>char</code> element at the specified position in this array.
   * @param i  the element index.
   * @return  the value at the specified index.
   * @throws IndexArrayOutOfBoundsException  if the specified index is out of range.
   * @throws NullPointerException  if the element at the specified index is <code>null</code>.
   * @throws ClassCastException  if the element at the specified index is not
   *         a <code>Character</code> wrapper object.
   */
  public char getChar(int i)
  {
    return ((Character)get(i)).charValue();
  }
  /**
   * Returns the <code>boolean</code> element at the specified position in this array.
   * @param i  the element index.
   * @return  the value at the specified index.
   * @throws IndexArrayOutOfBoundsException  if the specified index is out of range.
   * @throws NullPointerException  if the element at the specified index is <code>null</code>.
   * @throws ClassCastException  if the element at the specified index is not
   *         a <code>Boolean</code> wrapper object.
   */
  public boolean getBoolean(int i)
  {
    return ((Boolean)get(i)).booleanValue();
  }
  /**
   * Returns the <code>String</code> element at the specified position in this array.
   * @param i  the element index.
   * @return  the value at the specified index.
   * @throws IndexArrayOutOfBoundsException  if the specified index is out of range.
   * @throws NullPointerException  if the element at the specified index is <code>null</code>.
   * @throws ClassCastException  if the element at the specified index is not
   *         a <code>String</code>.
   */
  public String getString(int i)
  {
    return (String)get(i);
  }
  /**
   * Returns the <code>GUID</code> element at the specified position in this array.
   * @param i  the element index.
   * @return  the value at the specified index.
   * @throws IndexArrayOutOfBoundsException  if the specified index is out of range.
   * @throws NullPointerException  if the element at the specified index is <code>null</code>.
   * @throws ClassCastException  if the element at the specified index is not
   *         a <code>GUID</code>.
   */
  public GUID getGUID(int i)
  {
    return (GUID)get(i);
  }
  /**
   * Returns the TypedMap object at the specified position in this array.
   * @param i  the element index.
   * @return  the value at the specified index.
   * @throws IndexArrayOutOfBoundsException  if the specified index is out of range.
   * @throws ClassCastException  if the element at the specified index is not
   *         a <code>TypedMap</code>.
   */
  public TypedMap getMap(int i)
  {
    return (TypedMap)get(i);
  }
  /**
   * Returns the TypedArray object at the specified position in this array.
   * @param i  the element index.
   * @return  the value at the specified index.
   * @throws IndexArrayOutOfBoundsException  if the specified index is out of range.
   * @throws ClassCastException  if the element at the specified index is not
   *         a <code>TypedArray</code>.
   */
  public TypedArray getArray(int i)
  {
    return (TypedArray)get(i);
  }

  /**
   * Passivates the specified object and appends it to the array.
   * @param obj  the object to passivate and append.
   */
  public void addPassivated(Object obj)
  {
    try
    {
      add(TypedMap.passivate(obj));
    }
    catch(Exception x)
    {
      x.printStackTrace();
    }
  }
  /**
   * Retrieves and activates the object at the specified index and returns
   * the activated object.
   * @param i    the array index.
   * @param ctx  the activation context.
   */
  public Object getActivated(int i, TypedMap ctx)
  {
    Object pas=get(i);
    Object act=null;
    try
    {
      act=TypedMap.activate(pas, ctx);
    }
    catch(Exception x)
    {
      x.printStackTrace();
    }
    return act;
  }
  /**
   * Returns a string representation of this array.
   * @see java.lang.Object#toString()
   */
  public String toString()
  {
    StringBuffer sb=new StringBuffer();
    sb.append("[");
    if (activeClassName!=null)
    {
      sb.append(activeClassName);
      sb.append(": ");
    }
    Object obj;




    for (Iterator iter=elems.iterator(); iter.hasNext();)
    {
      obj=iter.next();
      if (obj!=null)
        sb.append(obj.toString());
      else
        sb.append("(null)");


      if (iter.hasNext())
        sb.append(", ");
    }
    sb.append("]");
    return sb.toString();
  }

  /**
   * Compares if two given arrays are equal. Java's arrays do not override
   * the equals operation from Object. Therefore, the default operation
   * is not very useful.
   * @return  true, if the arrays have the same type, all lengths are equal
   *          and all elements are equal.
   */
  public static boolean arrayEquals(Object oa, Object ob)
  {
    if (!oa.getClass().equals(ob.getClass()))
      return false;
    String className=oa.getClass().getName();
    if (className.charAt(0)!='[')
      return oa.equals(ob);
    switch (className.charAt(1))
    {
      case 'B':
      {
        byte[] a=(byte[])oa;
        byte[] b=(byte[])ob;
        if (a.length!=b.length)
          return false;
        for (int i=0; i<a.length; i++)
          if (a[i]!=b[i])
            return false;
        return true;
      }
      case 'C':
      {
        char[] a=(char[])oa;
        char[] b=(char[])ob;
        if (a.length!=b.length)
          return false;
        for (int i=0; i<a.length; i++)
          if (a[i]!=b[i])
            return false;
        return true;
      }
      case 'D':
      {
        double[] a=(double[])oa;
        double[] b=(double[])ob;
        if (a.length!=b.length)
          return false;
        for (int i=0; i<a.length; i++)
          if (a[i]!=b[i])
            return false;
        return true;
      }
      case 'F':
      {
        float[] a=(float[])oa;
        float[] b=(float[])ob;
        if (a.length!=b.length)
          return false;
        for (int i=0; i<a.length; i++)
          if (a[i]!=b[i])
            return false;
        return true;
      }
      case 'I':
      {
        int[] a=(int[])oa;
        int[] b=(int[])ob;
        if (a.length!=b.length)
          return false;
        for (int i=0; i<a.length; i++)
          if (a[i]!=b[i])
            return false;
        return true;
      }
      case 'J':
      {
        long[] a=(long[])oa;
        long[] b=(long[])ob;
        if (a.length!=b.length)
          return false;
        for (int i=0; i<a.length; i++)
          if (a[i]!=b[i])
            return false;
        return true;
      }
      case 'S':
      {
        short[] a=(short[])oa;
        short[] b=(short[])ob;
        if (a.length!=b.length)
          return false;
        for (int i=0; i<a.length; i++)
          if (a[i]!=b[i])
            return false;
        return true;
      }
      case 'Z':
      {
        boolean[] a=(boolean[])oa;
        boolean[] b=(boolean[])ob;
        if (a.length!=b.length)
          return false;
        for (int i=0; i<a.length; i++)
          if (a[i]!=b[i])
            return false;
        return true;
      }
      case 'L':
      case '[':
      {
        Object[] a=(Object[])oa;
        Object[] b=(Object[])ob;
        if (a.length!=b.length)
          return false;
        for (int i=0; i<a.length; i++)
        {
          if ( (a[i]!=b[i]) &&
               (a[i]==null || b[i]==null || !arrayEquals(a[i], b[i])) )
            return false;
        }
        return true;
      }
      default:
        throw new IllegalStateException("Can't compare "+className);
    }
  }









































  public ArrayList<Object> elems = new ArrayList<Object>();


}
