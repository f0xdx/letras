/*
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is MundoCore Java.
 *
 * The Initial Developer of the Original Code is Telecooperation Group,
 * Department of Computer Science, Darmstadt University of Technology.
 * Portions created by the Initial Developer are
 * Copyright (C) 2001-2008 the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 * Erwin Aitenbichler
 * Stefan Radomski
 */

package org.mundo.net.broker;

import org.mundo.rt.SubscriptionParameters;
import org.mundo.rt.Subscriber;
import org.mundo.rt.Publisher;
import org.mundo.rt.Session;
import org.mundo.filter.IFilter;

/**
 * This class is an exact copy of the ContentSubscription, with the sole exception,
 * that we use a general IFilter object and no TypedMapFilter.
 */
public class FilteredSubscription extends SubscriptionParameters
{
  /**
   * Initializes a new <code>ContentSubscription</code> with a map filter.
   * @param f  a map filter.
   */
  public FilteredSubscription(IFilter f)
  {
    filter=f;
  }
  /**
   * Returns the map filter.
   * @return  the map filter.
   */
  public IFilter getFilter()
  {
    return filter;
  }
  /**
   * Creates a content-based subscription.
   * @param session  the session object.
   * @param filter  a map filter.
   * @return  a subscriber object.
   */  
  public static Subscriber subscribe(Session session, IFilter filter)
  {
    Subscriber subscriber=session.subscribe();
    subscriber.setParam(new FilteredSubscription(filter));
    return subscriber;
  }
  /**
   * Creates a content-based publisher.
   * @param session  the session object.
   * @return  a publisher object.
   */  
  public static Publisher publish(Session session)
  {
    return session.publish("lan", "ContentSubscription");
  }
  
  /**
   * Returns a string representation of the <code>ContentSubscription</code> object.
   * @return  the string representation.
   */
  public String toString()
  {
    return filter.toString();
  }
  private IFilter filter;
}
