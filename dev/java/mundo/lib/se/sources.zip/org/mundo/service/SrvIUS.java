package org.mundo.service;


/**
 * Automatically generated server stub for <code>IUS</code>
 * @see org.mundo.service.IUS
 */
public class SrvIUS extends org.mundo.rt.ServerStub
{
  public SrvIUS()
  {
  }
  private static org.mundo.rt.ServerStub _obj;
  public static org.mundo.rt.ServerStub _getObject()
  {
    if (_obj==null)
    {
      _obj=new SrvIUS();
    }
    return _obj;
  }
  public void invoke(Object o, org.mundo.rt.TypedMap m, org.mundo.rt.TypedMap r)
  {
    String n=m.getString("request");
    IUS p=(IUS)o;
    try
    {
      if (n.equals("getName") && m.getString("ptypes").equals(""))
      {
        r.putString("value", p.getName());
        return;
      }
      if (n.equals("associate") && m.getString("ptypes").equals("DoIME"))
      {
        p.associate((DoIME)m.getObject("p0"));
        return;
      }
      if (n.equals("deassociate") && m.getString("ptypes").equals("DoIME"))
      {
        p.deassociate((DoIME)m.getObject("p0"));
        return;
      }
      if (n.equals("_getMethods") && m.getString("ptypes").equals(""))
      {
        r.putString("value",
        "s getName()\n"+
        "v associate(DoIME)\n"+
        "v deassociate(DoIME)\n"+
        "");
        return;
      }
    }
    catch(Exception x)
    {
      exceptionOccured(x, o, m, r);
    }
  }
}