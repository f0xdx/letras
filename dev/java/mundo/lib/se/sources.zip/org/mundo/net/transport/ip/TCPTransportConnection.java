/*
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is MundoCore Java.
 *
 * The Initial Developer of the Original Code is Telecooperation Group,
 * Department of Computer Science, Darmstadt University of Technology.
 * Portions created by the Initial Developer are
 * Copyright (C) 2001-2008 the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 * Erwin Aitenbichler
 */

package org.mundo.net.transport.ip;

//#define TRACE_MODULE

import org.mundo.rt.GUID;
import org.mundo.rt.IReceiver;
import org.mundo.rt.Blob;
import org.mundo.rt.Signal;
import org.mundo.rt.Message;
import org.mundo.rt.TypedMap;
import org.mundo.rt.Mundo;
import org.mundo.rt.IntegerMonitor;
import org.mundo.rt.Mutex;
import org.mundo.rt.Queue;
import org.mundo.rt.Logger;
import org.mundo.net.transport.TransportLink;
import org.mundo.net.transport.ip.IPLink;
import org.mundo.service.DebugService;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.EOFException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketException;
import java.util.Iterator;









/**
 * Implements a transport connection using TCP/IP.
 * @author Erwin Aitenbichler
 */
public class TCPTransportConnection
       implements IIPTransportConnection
{
  TCPTransportConnection(IPLink l)
  {
    route = l;
    InetSocketAddress a = route.getPeerExtAddress();
    if (a!=null)
    {
      remoteAddr = a.getAddress();
      remotePort = a.getPort();
    }
    service = route.ipts;


    protocolVersion = 900;
  }
  TCPTransportConnection(IPTransportService svc, IPLink l, Socket s)
  {
    service = svc;
    route = l;
    InetSocketAddress a = route.getPeerExtAddress();
    if (a!=null)
    {
      remoteAddr = a.getAddress();
      remotePort = a.getPort();
    }


    protocolVersion = 900;
    sock=s;
    try
    {
      sock.setTcpNoDelay(true);
    }
    catch(Exception x)
    {
      log.exception(x);
    }
  }
  public void init(GUID d, InetAddress a, int p, TypedMap opts) // IIPTransportConnection
  {
    String name=opts.getString("name", null);
  
    // Route must be locked before Connection
//    IPLink r=null;
    try
    {
      mutex.lock();
      destId=d;
      remoteAddr=a;
      remotePort=p;
      if (sock!=null)
        state=STATE_CONNECTED;
      else
        state=STATE_CONNECTING_2;
//      r=route;
    }
    finally
    {
      mutex.unlock();
    }
/*
    if (r!=null)
    {
      r.remoteId=d;
      r.remoteName=name;
      r.set(a, p, IPLink.PROTO_TCP);
    }
*/
    if (opts.getBoolean("keep-open", false))
    {
      log.fine("peer requests keep-open");
      setKeepOpen(true);
    }
  }
  /**
   * Returns the node identifier of the remote peer.
   * @return  the node GUID of the remote peer.
   */
  public GUID getRemoteId() /*ITransportConnection*/
  {
    GUID id;
    mutex.lock();
    id=destId;
    mutex.unlock();
    return id;
  }
  /**
   * Returns the IP address of the remote peer.
   * @return  the IP address of the remote peer.
   */
  public InetAddress getRemoteAddress()
  {
    InetAddress addr;
    mutex.lock();
    addr=remoteAddr;
    mutex.unlock();
    return addr;
  }
  
  public InetAddress getLocalAddress()
  {
    InetAddress addr = null;
    mutex.lock();
    if (sock!=null)
      addr = sock.getLocalAddress();
    mutex.unlock();
    return addr;
  }
  /**
   * Checks if the remote address is a loopback address.
   * @return  <code>true</code> if the remote address is a loopback address;
   *          <code>false</code> otherwise.
   */
  public boolean isLoopback()
  {
    boolean b;
    mutex.lock();
    // InetAddress.isLoopbackAddress() is available only in 1.4
    byte[] a=remoteAddr.getAddress();
    b=(a[0]==127 && a[1]==0 && a[2]==0);
    mutex.unlock();
    return b;
  }
  /**
   * Returns the remote port number.
   * @return  the remote port number.
   */
  public int getRemotePort() // IIPTransportConnection
  {
    int port;
    mutex.lock();
    port=remotePort;
    mutex.unlock();
    return port;
  }
  /**
   * Returns the timeout value. The connection is automatically
   * closed after the timeout period.
   * @return  the timeout value in seconds.
   */
  public int getTimeout()
  {
/*
    int t;
    mutex.lock();
    t=timeout;
    mutex.unlock();
    return t;
*/
    return timeout;
  }
  /**
   * Sets the timeout reset value. The timeout counter is reset to the specified
   * value each time a read or write operation on the connection is performed.
   * @param t  the timeout reset value in seconds. <code>TIMEOUT_INFINITE</code>
   *           indicates that the connection should never time out.
   */
  public void setTimeoutReset(int t)
  {
    mutex.lock();
    if (!keepOpen)
    {
      timeoutReset=t;
      if (timeoutReset==-1)
        timeout=-1;
    }
    mutex.unlock();
  }
  /**
   *
   */
  void setKeepOpen(boolean b)
  {
    mutex.lock();
    keepOpen=b;
    if (keepOpen)
    {
      timeoutReset=-1;
      timeout=-1;
    }
    mutex.unlock();
  }
  /**
   * Returns the state of this connection.
   */
  public int getState() // IIPTransportConnection
  {
    int s;
    mutex.lock();
    s=state;
    mutex.unlock();
    return s;
  }
  /**
   * Returns the associated route object.
   */
  public IPLink getLink() // ITransportConnection


  {
    IPLink l;
    mutex.lock();
    l = route;
    mutex.unlock();
    return l;
  }
  /**
   * Sets the route associated with this connection.
   */
  public void setRoute(IPLink l)
  {
    mutex.lock();
    route = l;
    mutex.unlock();
  }
  /**
   * Periodically called by a routing service to update the timeout counters
   * and to close idle connections.
   * @return  true if the connection is still open, false if not.
   */
  public boolean checkTimeout(int elapsed) // ITransportConnection
  {
    if (!mutex.tryLock())
      return true;
    
    // check disconnect timeout
    int t=disconnectTimeout.get();
    if (t>=0)
    {
      if (t>0)
        disconnectTimeout.add(-1);
      else
      {
        log.severe("disconnect timeout");
        mutex.unlock();
        service.connectionClosed(this);
        if (sock!=null)
        {
          new CloseThread(sock).start();









          sock=null;
        }
        return false;
      }
    }
    
    try
    {
      // check send timeout
      t=sendTimeout.get();
      if (t>=0)
      {
        if (t>0)
          sendTimeout.add(-1);
        else
        {
          log.warning("send timeout");
          timeout=0;
        }
      }
        
      if (state==STATE_DISCONNECT_REQUESTED)
      {
        if (disconnectTimeout.get()<0)
          disconnectTimeout.set(DISCONNECT_TIMEOUT);
        if (!(sendThread!=null && sendThread.isAlive()))
        {
          try
          {
            disconnectNow();
          }
          catch(IllegalStateException x)
          {
            log.exception(x);
          }
          return state<STATE_DISCONNECTED;
        }
      }
      if (state>=STATE_DISCONNECTED)
        return false;
        
      if (timeout==TransportLink.TIMEOUT_INFINITE)
        return true;
      timeout-=elapsed;
      if (timeout<=0)
      {
        timeout=0;
        state=STATE_DISCONNECT_REQUESTED;
        disconnectTimeout.set(DISCONNECT_TIMEOUT);
        try
        {
          disconnectNow();
        }
        catch(IllegalStateException x)
        {
          log.exception(x);
        }
      }
      return state<STATE_DISCONNECTED;
    }
    finally
    {
      mutex.unlock();
    }
  }
  /**
   * Returns the metric value of this connection. The routing service
   * always trys to use the connection with the lowest value. This method
   * always returns a valid value. If the connection is closed, the
   * returned value is as if the connection were open (or only minimally
   * different).
   * 
   * <table><tr><td><b>Metric</b></td><td><b>Description<b></td></tr>
   * <tr><td><code>9</code></td><td>Connections to <code>127.0.0.1:PRIMARY_PORT</code>. Because
   * connections to the primary port never time out, they should always
   * be used for data transfers when they are present.</td></tr>
   * <tr><td><code>10</code></td><td>Connections to <code>127.0.0.1</code>. Connections via the
   * loopback network interface are cheaper than real network connections.</td></tr>
   * <tr><td><code>20</code></td><td>Network connections.</td></tr>
   * <tr><td><code>999</code></td><td>If the connection object has not been initialized
   * with the address of the remote endpoint.</td></tr>
   * </table>
   */
  public int getMetric() // ITransportConnection
  {
    mutex.lock();
    try
    {
      if (sock!=null && sock.getLocalPort()==IPTransportService.primaryPort)
        return 9;
      if (remoteAddr==null)
        return 999;
      byte[] a=remoteAddr.getAddress();
      if (a[0]==127 && a[1]==0 && a[2]==0)
      {
        if (remotePort==IPTransportService.primaryPort)
          return 9;
        return 10;
      }
      return 20;
    }
    finally
    {
      mutex.unlock();
    }
  }
  /**
   * Opens the connection. The following preconditions are possible:
   *
   *    address+port   peer-id       socket    status
   * 1) initialized    initialized   closed    STATE_CONNECTING_2
   * 2) initialized    initialized   open      STATE_CONNECTED
   * 3) initialized    -             closed    STATE_NULL
   * 4) -              -             open      STATE_NULL
   *
   * Depending on these conditions, the following actions are performed:
   *
   * 1) The socket is opened and the communication thread is started.
   *    New state: STATE_CONNECTED
   * 2) The communication thread is started.
   * 3) The socket is opened, a NodeAdd message sent and the thread started.
   *    New state: STATE_CONNECTING_1   
   * 4) address+port is initialized and the thread is started.
   *    New state: STATE_CONNECTING_1
   */  
  public boolean connect() throws Exception // ITransportConnection
  {
    if (service.getState()>=service.STATE_SHUTDOWN)
      throw new IllegalStateException("node is shutting down");
    boolean connOpened_flag=false;
    IPLink connOpenFailed_route=null;
    long startTime=System.currentTimeMillis();
    //.start();
    //.before("mutex.lock");
    mutex.lock();
    //.after("mutex.lock");
    try
    {
      if (state==STATE_DISCONNECT_REQUESTED || state==STATE_SELF_DISCONNECTING)
        throw new IllegalStateException("disconnect requested");
      timeout=timeoutReset;
      if (state<STATE_CONNECTED)
      {
        if (sock==null)
        {
          InetAddress addr=remoteAddr;
          int port=remotePort;
          mutex.unlock();
          Socket s=null;
          //.before("new Socket");
          try
          {
            s=new Socket(addr, port);
            try
            {
              s.setTcpNoDelay(true);
            }
            catch(Exception x)
            {
              log.exception(x);
            }
          }
          catch(Exception x)
          {
//            x.printStackTrace();
            state=STATE_DISCONTINUED;
            connOpenFailed_route=route;
          }
          //.after("new Socket");
          mutex.lock();
          sock=s;
        }
        else
        {
          remoteAddr=sock.getInetAddress();
          remotePort=sock.getPort();
          state=STATE_CONNECTING_1;
        }
      }
      if (state<=STATE_CONNECTED)
      {
        try
        {
          if (thread==null)
          {
            os=sock.getOutputStream();
            //.before("new ConnThread");
            thread=new ConnThread();
            //.before("thread.start");
            thread.start();
            //.after("thread.start");
          }
          //.before("sendThread.start");
          sendThread.start();
          //.after("sendThread.start");
          if (state==STATE_NULL && destId==null)
          {
            TypedMap doc=new TypedMap();
            doc.put("request", "NodeAdd");
            doc.putInt("version", IPTransportService.CURRENT_PROTOCOL_VERSION);
            int localPort=service.getLocalPort();
            if (localPort>0)
              doc.putInt("port", localPort);
            doc.put("vpId", Mundo.getNodeId());
            doc.put("name", Mundo.getNodeName());
            if (keepOpen)
              doc.putBoolean("keep-open", true);
            log.fine("NodeAdd "+Mundo.getNodeId().shortString()+" >");
            //.before("send NodeAdd");
            Message msg = new Message("ipts", "passive", doc);
            msg.setType("message/mc-ipts");
            service.serialize(msg);
            send(msg);
            //.after("send NodeAdd");
            state=STATE_CONNECTING_1;
          }
          else if (state==STATE_CONNECTING_2)
          {
            // DEAD CODE ???
            TypedMap doc=new TypedMap();
            doc.put("request", "NodeAddReply");
            doc.putInt("version", IPTransportService.CURRENT_PROTOCOL_VERSION);
            int localPort=service.getLocalPort();
            if (localPort>0)
              doc.putInt("port", localPort);
            doc.put("vpId", Mundo.getNodeId());
            doc.put("name", Mundo.getNodeName());
            if (keepOpen)
              doc.putBoolean("keep-open", true);
            doc.put("intAddr", sock.getLocalAddress().getHostAddress());
            doc.put("extAddr", remoteAddr.getHostAddress());
            doc.putInt("extPort", remotePort);
            log.fine("NodeAddReply "+Mundo.getNodeId().shortString()+" >");
            //.before("send NodeAddReply");
            Message msg = new Message("ipts", "passive", doc);
            msg.setType("message/mc-ipts");
            service.serialize(msg);
            send(msg);
            //.after("send NodeAddReply");
            state=STATE_CONNECTED;
            connOpened_flag=true;
          }
          else if (state<=STATE_CONNECTED)
          {
            state=STATE_CONNECTED;
          }
        }
        catch(Exception x)
        {
          log.exception(x);
          state=STATE_DISCONTINUED;
          connOpenFailed_route=route;
        }
      }
    }
    finally
    {
      mutex.unlock();
      //.stop();
      long dt=System.currentTimeMillis()-startTime;
      if (dt>5000)
      {
        log.severe("connect to "+route+" took "+dt+"ms and "+(connOpenFailed_route!=null ? "failed" : "succeeded"));
      }
    }
    if (connOpenFailed_route!=null)
    {
      // The connection object must not be locked here
      service.connectionOpenFailed(connOpenFailed_route);
      return false;
    }
    if (connOpened_flag)
      service.connectionOpened(this);
    return true;
  }
  /**
   * Starts the disconnect operation.
   */
  public void disconnect() /*ITransportConnection*/
  {
    mutex.lock();
    if (state<STATE_DISCONNECT_REQUESTED)
      state=STATE_DISCONNECT_REQUESTED;
    if (sendThread!=null)
      sendThread.shutdown();
    mutex.unlock();
  }
  /**
   * Waits until all messages in the send queue have been sent and closes
   * the socket.
   * @return  <code>true</code> if it was a clean shutdown, or
   *          <code>false</code> otherwise.
   */
  public boolean disconnectWait() // IIPTransportConnection
  {
    log.finest("disconnectWait"+(destId!=null ? "; destId: "+destId.shortString() : ""));
    boolean clean=true;
    mutex.lock();
    try
    {
      if (state<STATE_DISCONNECT_REQUESTED)
        throw new IllegalStateException("disconnect not requested");
      if (sendThread!=null)
      {
        try
        {
          sendThread.join(JOIN_TIMEOUT_MS);
          if (sendThread.isAlive())
          {
            sendThread.interrupt();
            clean=false;
          }
        }
        catch(InterruptedException x)
        {
          log.exception(x);
        }
        sendThread=null;
      }
      if (sock!=null)
      {
        new CloseThread(sock).start();









        sock=null;
      }
    }
    finally
    {
      mutex.unlock();
    }
    return clean;
  }
  /**
   * Forces an immediate disconnect.
   */
  public void disconnectNow()
  {
    log.finest("disconnectNow"+(destId!=null ? "; destId: "+destId.shortString() : ""));
    mutex.lock();
    try
    {
      if (sendThread!=null)
        sendThread.shutdown();
      if (thread==null)
      {
        state=STATE_SELF_DISCONNECTED;
        return;
      }
      if (sock==null)
      {
        if (state<STATE_SELF_DISCONNECTING)
          throw new IllegalStateException("Connection has no socket while trying to disconnect");
        return;
      }
      synchronized(useCnt)
      {
        if (useCnt.get()!=0)
          throw new IllegalStateException("Can't disconnect while a read or write is pending");
        state=STATE_SELF_DISCONNECTING;
        new CloseThread(sock).start();









        sock=null;
      }
    }
    finally
    {
      mutex.unlock();
    }
  }
  public boolean isConnected() /*ITransportConnection*/
  {
    boolean b;
    mutex.lock();
    b=(state==STATE_CONNECTED);
    mutex.unlock();
    return b;
  }


  public boolean send(Message msg) // ITransportConnection
  {
    if (state>STATE_CONNECTED)
    {
      log.fine("attempting to send after disconnect");
      return false;
    }
    mutex.lock();
    try
    {
      if (state>STATE_CONNECTED)
      {
        log.fine("attempting to send after disconnect");
        return false;
      }
      if (sendThread==null)
      {
        log.severe("no sendThread");
        return false;
      }
//      service.serialize(msg);
      sendThread.enqueue(msg);
      timeout=timeoutReset;
      return true;
    }
    catch(Exception x)
    {
      log.exception(x);
    }
    finally
    {
      mutex.unlock();
    }
    return false;
  }
  /**
   *
   */
  public void setCrippleBlockSends()
  {
    crippleBlockSends=true;
  }

  /**
   * Returns a string representation of this object.
   * @return  a string representation of this object.
   */
  public String toString()
  {
    String s;
    mutex.lock();
    s="TCP: "+destId.toString()+", "+remoteAddr.toString();
    mutex.unlock();
    return s;
  }


  class ConnThread extends Thread
  {
    ConnThread()
    {
      super(Mundo.getThreadGroup(), "iptc.rcv");
    }
    public void run()
    {
      int newState=-1;
      try
      {
        InetSocketAddress remoteAddr = new InetSocketAddress(sock.getInetAddress(), sock.getPort());
//        RoutingService rs = (RoutingService)Mundo.getServiceByType(RoutingService.class);
        DataInputStream is = new DataInputStream(sock.getInputStream());
        byte[] b;
        for(;;)
        {
          int n = readInt(is);
//          System.out.println("msgType: "+n);
          if (n<=0)
          {
            // polling request: send empty message as reply
            if (n==-1)
            {
              synchronized(os)
              {
                writeInt(os, 0);
                os.flush();
              }
            }
            continue;
          }

          int msgType = IPTransportService.MSGTYPE_08;
          if (n <= IPTransportService.MSGTYPE_MAX)
            msgType = n;

          // read MIME type
          String mimeType = null;
          if (msgType == IPTransportService.MSGTYPE_DATA)
          {
            int l = is.read();
            if (l<0)
              throw new IllegalStateException("protocol error: strlen of type < 0");
            b = new byte[l];
            is.readFully(b, 0, l);
            mimeType = new String(b);
          }

          if (n <= IPTransportService.MSGTYPE_MAX)
            n = readInt(is);
//          System.out.println("length: "+n);

          // read n bytes from stream and create Message
          b = new byte[n];
          is.readFully(b, 0, n);
          Blob blob = new Blob();
          blob.write(b);
          Message msg = new Message();
          msg.put("all", "bin", blob);
          if (mimeType != null)
            msg.setType(mimeType);
//          System.out.println("rcv: "+msg.getBlob("all").toASCIIString());

          timeout = timeoutReset;
          useCnt.add(1);
          if (state <= STATE_CONNECTED)
          {
            try
            {
              if (msgType == IPTransportService.MSGTYPE_08)
              {
                log.finest("rcvd V0.8 msg: "+n+" bytes");


























                log.warning("protocol V0.8 not supported - use CFG_COMPAT");
                break;
              }
              else if (msgType == IPTransportService.MSGTYPE_DATA)
              {






                log.finest("rcvd data msg: "+n+" bytes");
                service.messageReceived(TCPTransportConnection.this, remoteAddr, msg);
              }
              else if (msgType == IPTransportService.MSGTYPE_CTRL_BIN)
              {






                log.finest("rcvd control msg: "+n+" bytes");
                service.iptsControlPacket(TCPTransportConnection.this, remoteAddr, msg);
              }
            }
            catch(Exception x)
            {
//              System.err.println(msg);
              log.exception(x);
            }
          }
          else
          {
//            System.err.println("connection was closed while waiting for lock (rcv)");
//            System.err.println("discarded message: "+ser);
            useCnt.add(-1);
            break;
          }
          useCnt.add(-1);
        }
      }
      catch(EOFException x)
      {
        // happens when the other side closes the connection
        newState = STATE_PEER_DISCONNECTED;
        log.finest("connection closed by peer"+(destId!=null ? "; destId: "+destId.shortString() : ""));
      }
      catch(SocketException x)
      {
        // happens when the socket is closed by the main thread
        newState = STATE_SELF_DISCONNECTED;
        String msg = x.getMessage().toLowerCase();
        if ("socket closed".equals(msg) ||
            "connection reset".equals(msg))
        {
          log.finest("socket closed while receive"+(destId!=null ? "; destId: "+destId.shortString() : ""));
        }
        else
        {
          log.finest("socket exception while receive"+(destId!=null ? "; destId: "+destId.shortString() : ""));
          log.exception(x);
        }
      }
      catch(IllegalStateException x)
      {
        // No error if the node is shutting down.
        if (service.getState() < service.STATE_SHUTDOWN)
        {
          log.exception(x);
        }
        newState=STATE_SELF_DISCONNECTED;
      }
      catch(NullPointerException x)
      {
        // Happens when the connection has been concurrently closed
        // before we have started up everything.
        log.exception(x);
      }
      catch(Exception x)
      {
        // IOException, SAXException
        log.exception(x);
      }
      mutex.lock();
      if (sendThread!=null)
        sendThread.shutdown();
      if (sock!=null)
      {
//        System.out.println("closing socket");
        new CloseThread(sock).start();









        sock=null;
      }
      thread=null;
      if (newState>=0)
        state=newState;
      mutex.unlock();
      service.connectionClosed(TCPTransportConnection.this);
//      System.out.println("IPTC: connThread terminated");
    }
  }

  private class SendThread extends Thread
  {
    SendThread()
    {
      super(Mundo.getThreadGroup(), "iptc.send");
    }
    synchronized void enqueue(Message msg)
    {
      if (msg.getBlob("all")==null)
        throw new IllegalStateException("message not serialized");
      if (msg.getType()==null)
        throw new IllegalStateException("message has no type");
      queue.enqueue(msg);
      if (started)
        notify();
    }
    synchronized void shutdown()
    {
      queue.enqueue(SHUTDOWN_REQUEST);
      crippleBlockSends=false;
      notify();
    }
    public synchronized void start()
    {
      if (started)
        return;
      started=true;
      super.start();
    }
    public void run()
    {
      for(;;)
      {
        for(;;)
        {
          Message msg;
          synchronized(this)
          {
            msg=(Message)queue.poll();
          }
          if (msg==null)
            break;
          if (msg==SHUTDOWN_REQUEST)
            return;
          send(msg);
        }
        try
        {
          synchronized(this)
          {
            wait();
          }
        }
        catch(InterruptedException x)
        {
          return;
        }
      }
    }
    private boolean send(Message msg)
    {
      sendTimeout.set(TIMEOUT_INIT);
      try
      {
        synchronized(os)
        {
          if (crippleBlockSends)
          {
            while (crippleBlockSends)
              Thread.sleep(500);
            return false;
          }
          else
          {
//          System.out.println("send: "+msg.getBlob("all").toASCIIString());
            byte[] b = msg.getBlob("all").getBuffer();
            if (protocolVersion>=900)
            {
              if ("message/mc-ipts".equals(msg.getType()))
              {
                log.finest("send control msg: "+b.length+" bytes");
                writeInt(os, IPTransportService.MSGTYPE_CTRL_BIN);
              }
              else
              {
                log.finest("send data msg: "+b.length+" bytes");
                writeInt(os, IPTransportService.MSGTYPE_DATA);
                writeString(os, msg.getType());
              }
            }
            writeInt(os, b.length);
            os.write(b);
            os.flush();
          }
        }
        DebugService.rawSent(msg);
        return true;
//        System.out.println("sending a data packet");
      }
      catch(SocketException x)
      {
        // Typically the peer caused a connection abort
        if ("socket closed".equals(x.getMessage().toLowerCase()))
        {
          log.finest("socket closed while send"+(destId!=null ? "; destId: "+destId.shortString() : ""));
        }
        else
        {
          log.finest("socket exception while send"+(destId!=null ? "; destId: "+destId.shortString() : ""));
          log.exception(x);
        }
      }
      catch(Exception x)
      {
        log.severe("send failed (unexpectedly) state="+state);
        log.exception(x);
      }
      finally
      {
        sendTimeout.set(-1);
      }
      return false;
    }

    private boolean started=false;
    private Queue<Message> queue=new Queue<Message>();


  }

  static class CloseThread extends Thread
  {
    CloseThread(Socket s)
    {
      sock = s;
      threadCount.add(1);
    }
    @Override
    public void run()
    {
      long t = System.currentTimeMillis();
      try
      {
        sock.close();
      }
      catch(IOException x)
      {
        log.exception(x);
      }
      long d = System.currentTimeMillis() - t;
      if (d>1000)
        log.warning("close socket took "+d+" ms");
      else
        log.fine("close socket took "+d+" ms");
      threadCount.add(-1);
    }
    public static int getThreadCount()
    {
//      System.out.println(threadCount.get());
      return threadCount.get();
    }
    private Socket sock;
    private static IntegerMonitor threadCount = new IntegerMonitor(0);
  }
  
  private static Message SHUTDOWN_REQUEST = new Message();

  private static int readInt(DataInputStream is) throws IOException
  {
    byte[] b=new byte[4];
    is.readFully(b);
    int v=(b[0]&0xff)|((b[1]&0xff)<<8)|((b[2]&0xff)<<16)|((b[3]&0xff)<<24);
    return v;
  }
  private static void writeInt(OutputStream os, int i) throws IOException
  {
    byte[] a = { (byte)i, (byte)(i>>8), (byte)(i>>16), (byte)(i>>24) };
    os.write(a);
  }
  private static void writeString(OutputStream os, String s) throws IOException
  {
    int l = s.length();
    byte[] a = new byte[l+1];
    a[0] = (byte)l;
    for (int i=0; i<l; i++)
      a[i+1] = (byte)s.charAt(i);
    os.write(a);
  }

  private final int TIMEOUT_INIT = 10;
  private final int DISCONNECT_TIMEOUT = 10;
  private final int JOIN_TIMEOUT_MS = 3000;

  // internal
  private GUID destId;
  private ConnThread thread;
  private SendThread sendThread = new SendThread();
  private InetAddress remoteAddr;
  private int remotePort;
  private Socket sock;
  private IPTransportService service;
  private int timeout = TIMEOUT_INIT;
  private int timeoutReset = TIMEOUT_INIT;
  private IPLink route;
  private Mutex mutex = new Mutex();
  private boolean keepOpen = false;
  private boolean crippleBlockSends = false;
  private OutputStream os;
  private int protocolVersion;
  private static Logger log = Logger.getLogger("ipts.tcp");
  private static Logger sendLog = Logger.getLogger("ipts.tcp.send");



  // We permit disconnects only when useCnt==0. Read and write operations
  // increment this value to ensure that nobody is closing the connection
  // in parallel.
  private IntegerMonitor useCnt = new IntegerMonitor(0);
  private IntegerMonitor sendTimeout = new IntegerMonitor(-1);
  private IntegerMonitor disconnectTimeout = new IntegerMonitor(-1);
  
  private int state = STATE_NULL;
}
