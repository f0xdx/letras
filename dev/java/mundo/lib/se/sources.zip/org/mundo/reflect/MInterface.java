/*
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is MundoCore Java.
 *
 * The Initial Developer of the Original Code is Telecooperation Group,
 * Department of Computer Science, Darmstadt University of Technology.
 * Portions created by the Initial Developer are
 * Copyright (C) 2001-2008 the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 * Erwin Aitenbichler
 */

package org.mundo.reflect;

import java.io.IOException;
import java.io.StringReader;
import java.io.StreamTokenizer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

/**
 * Objects of this class represent interfaces.
 */
public class MInterface extends MMeta
{
  /**
   * Initializes a new interface.
   * @param name  the interface name.
   */
  public MInterface(String name)
  {
    this.name=name;
  }
  /**
   * Returns the name of this interface.
   * @return  the interface name.
   */
  public String getName()
  {
    return name;
  }
  /**
   * Sets the package containing this interface.
   */
  public void setPackage(MPackage pkg)
  {
    this.pkg=pkg;
  }
  /**
   * Returns the package containing this interface.
   */
  public MPackage getPackage()
  {
    return pkg;
  }
  /**
   * Adds a method to this interface.
   * @param mtd  the method to add.
   */
  public void addMethod(MMethod mtd)
  {
    mtd.setInterface(this);
    methods.add(mtd);
    methodHash.put(mtd.getName(), mtd);
  }
  /**
   * Returns the method with the specified name.
   * @param name  the method name.
   */
  public MMethod getMethod(String name)
  {
    return (MMethod)methodHash.get(name);
  }
  /**
   * Returns a string representation of this object.
   */
  public String toString()
  {
    StringBuffer sb=new StringBuffer();
    sb.append("interface ").append(name).append(" {\n");
    for (MMethod mtd : methods)
    {




      sb.append(mtd.toString());
      sb.append("\n");
    }
    sb.append("}");
    return sb.toString();
  }

  public ArrayList<MMethod> getMethods()


  {
    return methods;
  }

  private MPackage pkg;
  private String name;
  private ArrayList<MMethod> methods=new ArrayList<MMethod>();
  private HashMap<String,MMethod> methodHash=new HashMap<String,MMethod>();



}
