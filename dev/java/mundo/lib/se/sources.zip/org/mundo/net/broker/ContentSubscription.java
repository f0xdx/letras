/*
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is MundoCore Java.
 *
 * The Initial Developer of the Original Code is Telecooperation Group,
 * Department of Computer Science, Darmstadt University of Technology.
 * Portions created by the Initial Developer are
 * Copyright (C) 2001-2008 the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 * Erwin Aitenbichler
 */

package org.mundo.net.broker;

import org.mundo.rt.SubscriptionParameters;
import org.mundo.rt.Subscriber;
import org.mundo.rt.Publisher;
import org.mundo.rt.Session;
import org.mundo.filter.TypedMapFilter;

/**
 * <p><code>ContentSubscription</code> is used to specify options for subscriptions
 * at the <code>ContentRoutingService</code>.</p>
 *
 * <p>The following example shows how to create a subscription with a content-based
 * filter:</p>
 * <pre>
 * TypedMapFilter filter=new TypedMapFilter();
 * filter.putInt("room", "==", 15);
 *
 * subscriber=ContentSubscription.subscribe(getSession(), filter);
 * subscriber.setReceiver(this);
 * subscriber.enable();</pre>
 *
 * <p>A publisher is created as follows:</p>
 *
 * <pre>
 * publisher=ContentSubscription.publish(getSession());</pre>
 *
 * @see ContentBroker
 * @author Erwin Aitenbichler
 */
public class ContentSubscription extends SubscriptionParameters
{
  /**
   * Initializes a new <code>ContentSubscription</code> with a map filter.
   * @param f  a map filter.
   */
  public ContentSubscription(TypedMapFilter f)
  {
    filter=f;
  }
  /**
   * Returns the map filter.
   * @return  the map filter.
   */
  public TypedMapFilter getFilter()
  {
    return filter;
  }
  /**
   * Creates a content-based subscription.
   * @param session  the session object.
   * @param filter  a map filter.
   * @return  a subscriber object.
   */  
  public static Subscriber subscribe(Session session, TypedMapFilter filter)
  {
    Subscriber subscriber=session.subscribe();
    subscriber.setParam(new ContentSubscription(filter));
    return subscriber;
  }
  /**
   * Creates a content-based publisher.
   * @param session  the session object.
   * @return  a publisher object.
   */  
  public static Publisher publish(Session session)
  {
    return session.publish("lan", "ContentSubscription");
  }
  
  /**
   * Returns a string representation of the <code>ContentSubscription</code> object.
   * @return  the string representation.
   */
  public String toString()
  {
    return filter.toString();
  }
  private TypedMapFilter filter;
}
