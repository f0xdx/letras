/*
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is MundoCore Java.
 *
 * The Initial Developer of the Original Code is Telecooperation Group,
 * Department of Computer Science, Darmstadt University of Technology.
 * Portions created by the Initial Developer are
 * Copyright (C) 2001-2008 the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 * Erwin Aitenbichler
 */

package org.mundo.xml;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Iterator;
import java.util.Hashtable;
import java.util.NoSuchElementException;

import org.mundo.rt.TypedMap;
import org.mundo.rt.TypedArray;
import org.mundo.rt.Message;
import org.mundo.rt.Blob;
import org.mundo.rt.GUID;

/**
 * Transforms a passive object tree to a SOAP message.
 * @author Erwin Aitenbichler
 */
public class XMLSerializer
{
  public XMLSerializer()
  {
  }
/*
  public static String serialize(Object obj) throws IOException
  {
    return serialize("object", obj);
  }
  public static String serialize(String elementName, Object obj) throws IOException
  {
    if (obj==null)
    {
      if (elementName!=null)
        return "<"+elementName+" null=\"1\"/>";
      return "";
    }
    StringBuffer sb=new StringBuffer();
    try
    {
      SOAPSerializer ser=forClass(obj.getClass());
      if (elementName!=null)
      {
        sb.append("<"+elementName+" xsi:type=\"");
        sb.append(ser.getTypeName());
        sb.append("\"");
        if (obj instanceof TypedMap && ((TypedMap)obj).getActiveClassName()!=null)
          sb.append(" activeClass=\""+((TypedMap)obj).getActiveClassName()+"\"");
        else if (obj instanceof TypedArray && ((TypedArray)obj).getActiveClassName()!=null)
          sb.append(" activeClass=\""+((TypedArray)obj).getActiveClassName()+"\"");
        sb.append(">");
      }
      sb.append(ser.toString(obj));
      if (elementName!=null)
        sb.append("</"+elementName+">");
      return sb.toString();
    }
    catch(NoSuchElementException x)
    {
      x.printStackTrace();
      throw new IOException("serialization error");
    }
  }
*/
  public String serializeMap(String elementName, TypedMap map) throws IOException
  {
    blob=new Blob();
    doSerializeObject(elementName, map, null);
    return blob.toString();
  }
  public String serializeMap(String elementName, TypedMap map, String nsDecls) throws IOException
  {
    blob=new Blob();
    doSerializeObject(elementName, map, nsDecls);
    return blob.toString();
  }
/*
  public String serializeObject(String elementName, Object obj) throws IOException
  {
    blob=new Blob();
    doSerializeObject(elementName, obj);
    return blob.toString();
  }
*/
  public void serialize(Message msg) throws IOException
  {
    blob=new Blob();
    blob.write("<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>\n");
    blob.write("<message>");

    // Serialize the main chunk. This one is just handled separately so that it
    // appears first in the output document.
    TypedMap map=msg.getMap("main", "passive");
    if (map!=null)
    {
      blob.write("<chunk name=\"main\" type=\"passive\">");
      serializeMap(map);
      blob.write("</chunk>");
    }

    // Serialize all other passive and binary chunks.
    for (Iterator iter=msg.iterator(); iter.hasNext();)
    {
      Message.Chunk c=(Message.Chunk)iter.next();
      if (c.name.equals("main"))
        continue;
      boolean isPassive=c.type.equals("passive");
      if (isPassive || c.type.equals("bin"))
      {
        blob.write("<chunk name=\""+c.name+"\" type=\""+c.type+"\">");
        if (isPassive)
          serializeMap((TypedMap)c.content);
        else
          serializeBlob((Blob)c.content);
        blob.write("</chunk>");
      }
    }
    blob.write("</message>\n");
    msg.put("all", "xmlser", blob);
  }
  
  private void doSerializeObject(String elementName, Object obj, String nsDecls) throws IOException
  {
    if (obj==null)
    {
      if (elementName!=null)
      {
        blob.write("<"+elementName);
        if (nsDecls!=null)
        {
          blob.write(" ");
          blob.write(nsDecls);
        }
        blob.write(" null=\"1\"/>");
      }
      return;
    }
    try
    {
      ItemSerializer ser=forClass(obj.getClass());
      if (elementName!=null)
      {
        blob.write("<"+elementName+" xsi:type=\""+ser.getTypeName()+"\"");
        if (obj instanceof TypedMap && ((TypedMap)obj).getActiveClassName()!=null)
          blob.write(" activeClass=\""+((TypedMap)obj).getActiveClassName()+"\"");
        else if (obj instanceof TypedArray && ((TypedArray)obj).getActiveClassName()!=null)
          blob.write(" activeClass=\""+((TypedArray)obj).getActiveClassName()+"\"");
        if (nsDecls!=null)
        {
          blob.write(" ");
          blob.write(nsDecls);
        }
        blob.write(">");
      }
      ser.serialize(this, obj);
      if (elementName!=null)
        blob.write("</"+elementName+">");
    }
    catch(NoSuchElementException x)
    {
      x.printStackTrace();
      throw new IOException("can't serialize "+obj.getClass());
    }
  }
  
  private static ItemSerializer forClass(Class c) throws NoSuchElementException
  {
    ItemSerializer ser=(ItemSerializer)ht.get(c);
    if (ser==null)
      throw new NoSuchElementException("no serializer for '"+c.getName()+"'");
    return ser;
  }

  private void serializeMap(TypedMap map) throws IOException
  {
    Map.Entry e;
    Object key, value;
    for (Iterator i=map.entrySet().iterator(); i.hasNext();)
    {
      e=(Map.Entry)i.next();
      key=e.getKey();
      value=e.getValue();
      doSerializeObject((String)key, value, null);
    }       
  }

  private void serializeBlob(Blob b)
  {
    new Base64Codec().encode(blob, b);
  }

  static abstract class ItemSerializer
  {
    public abstract void serialize(XMLSerializer s, Object obj) throws IOException;
    public abstract String getTypeName();
  }

  static class CharSerializer extends ItemSerializer
  {
    public CharSerializer()
    {
      xsdTypeName="xsd:char";
    }
    public void serialize(XMLSerializer s, Object o)
    {
      char c=((Character)o).charValue();
      if (c>=32 && c<=127)
        s.blob.write(String.valueOf(c));
      else
        s.blob.write("&#x"+Integer.toHexString(c)+";");
    }
    public String getTypeName()
    {
      return xsdTypeName;
    }
    private String xsdTypeName;
  }

  static class StringSerializer extends ItemSerializer
  {
    public StringSerializer(String typeName)
    {
      xsdTypeName="xsd:"+typeName;
    }
    public void serialize(XMLSerializer ser, Object o)
    {
      String s=o.toString();
      for (int i=0; i<s.length(); i++)
      {
        char c=s.charAt(i);
        if (c=='<')
          ser.blob.write("&lt;");
        else if (c=='&')
          ser.blob.write("&amp;");
        else if (c>=32 && c<=127)
          ser.blob.write(c);
        else
          ser.blob.write("&#x"+Integer.toHexString(c)+";");
      }
    }
    public String getTypeName()
    {
      return xsdTypeName;
    }
    private String xsdTypeName;
  }

  static class JavaXDRSerializer extends ItemSerializer
  {
    public void serialize(XMLSerializer s, Object o)
    {
      s.blob.write(o.toString());
    }
    public String getTypeName()
    {
      return "JavaXDR";
    }
  }

  static class ArraySerializer extends ItemSerializer
  {
    public void serialize(XMLSerializer s, Object o) throws IOException
    {
      Iterator iter;
      try
      {
        iter=((TypedArray)o).iterator();
      }
      catch(ClassCastException x)
      {
        throw new IOException("expected PassiveArray, but got "+o.getClass().getName());
      }
      while (iter.hasNext())
        s.doSerializeObject("object", iter.next(), null);
    }
    public String getTypeName()
    {
      return "array";
    }
  }

  private static class MapSerializer extends ItemSerializer
  {
    public void serialize(XMLSerializer s, Object o) throws IOException
    {
      s.serializeMap((TypedMap)o);
    }
    public String getTypeName()
    {
      return "map";
    }
  }

  private static class BlobSerializer extends ItemSerializer
  {
    public void serialize(XMLSerializer s, Object o) throws IOException
    {
      s.serializeBlob((Blob)o);
    }
    public String getTypeName()
    {
      return "blob";
    }
  }

  private Blob blob;

  static Hashtable<Class,ItemSerializer> ht=new Hashtable<Class,ItemSerializer>();


  static
  {
    ht.put(Byte.class, new StringSerializer("byte"));
    ht.put(TypedMap.UnsignedByte.class, new StringSerializer("unsignedByte"));
    ht.put(Short.class, new StringSerializer("short"));
    ht.put(TypedMap.UnsignedShort.class, new StringSerializer("unsignedShort"));
    ht.put(Integer.class, new StringSerializer("int"));
    ht.put(TypedMap.UnsignedInteger.class, new StringSerializer("unsignedInt"));
    ht.put(Long.class, new StringSerializer("long"));
    ht.put(TypedMap.UnsignedLong.class, new StringSerializer("unsignedLong"));
    ht.put(Float.class, new StringSerializer("float"));
    ht.put(Double.class, new StringSerializer("double"));
    ht.put(Boolean.class, new StringSerializer("boolean"));
    ht.put(Character.class, new CharSerializer());
    ht.put(String.class, new StringSerializer("string"));
    ht.put(GUID.class, new StringSerializer("ID"));
    ht.put(TypedMap.JavaXDR.class, new JavaXDRSerializer());
    ht.put(TypedArray.class, new ArraySerializer());
    ht.put(TypedMap.class, new MapSerializer());
    ht.put(Blob.class, new BlobSerializer());
  }
}
