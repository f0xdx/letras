/*
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is MundoCore Java.
 *
 * The Initial Developer of the Original Code is Telecooperation Group,
 * Department of Computer Science, Darmstadt University of Technology.
 * Portions created by the Initial Developer are
 * Copyright (C) 2001-2008 the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 * Erwin Aitenbichler
 */

package org.mundo.rt;

import org.mundo.net.RMCService;




/**
 * An object adapter is the glue between subscribers and target objects.
 * Object adapters are necessary on the server side when using remote
 * method calls.
 * @author Erwin Aitenbichler
 */
public class ObjectAdapter implements IReceiver
{
  /**
   * Initializes a new object adapter.
   * @param sub     the subscriber object that defines where requests to the object
   *                come from. The subscriber must not be already enabled.
   * @param target  the local target object.
   */
  public ObjectAdapter(Subscriber sub, Object target)
  {
    session=sub.getChannel().getSession();
    this.target=target;
    subscriber=sub;
    subscriber.setReceiver(this);
//    ChannelSubscription p=new ChannelSubscription();
//    p.activation=false;
//    subscriber.setParam(p);
    RMCService svc=RMCService.getInstance();
    if (svc!=null)
      svc.exportObject(this);
    subscriber.enable();
  }
  /**
   * Returns the associated channel name.
   */
  public String getName()
  {
    return subscriber.getChannel().getName();
  }
  /**
   * Returns the target object.
   */
  public Object getTarget()
  {
    return target;
  }
  /**
   * Returns a string representation for this object.
   */
  public String toString()
  {
    return getName()+", "+target.toString();
  }
  /**
   * This callback is called on an incoming RMC request. The method finds a
   * suitable server stub and invokes the method specified in the request
   * on the target object.
   * @param msg     the RMC request message.
   * @param msgCtx  the message context.
   */
  public void received(Message msg, MessageContext msgCtx) // IReceiver
  {
    TypedMap m = msg.getMap("main", "passive");
    // local call
    if (m==null)
    {
      log.finest("local call: " + msg.getMap());
      m = msg.getMap();
    }
    else
    {
      log.finest("remote call: " + msg.getMap());
      try
      {
        TypedMap actCtx = new TypedMap();
        actCtx.put("session", session);
        m = m.activateMap(actCtx);
      }
      catch(Exception x)
      {
        x.printStackTrace();
      }
    }
    String sysRequest = m.getString("sysRequest", null);
    if (sysRequest!=null)
    {
      HandleSysRequest(m);
      return;
    }
    try
    {
      String ifName = m.getString("interface");
      ServerStub stub=ServerStub.forName(ifName, target.getClass().getClassLoader());


//    System.out.println("request: '"+msg.getRequest()+"'");
//    System.out.println(m);
      if (session.getRMCDispatchMode()==session.DISPATCH_ASYNC)
      {
        new InvokeThread(stub, m.getString("request"), m).start();
      }
      else
      {
        TypedMap r=new TypedMap();
        if (m.getBoolean("oneWay", false))
          stub.invoke(target, m, r);
        else
        {
          r.put("callId", m.get("callId"));
          r.put("request", m.get("request")+"Reply");
          stub.invoke(target, m, r);
          session.send(m.getGUID("sessionId"), new Message(r));
        }
      }
    }
    catch(Exception x)
    {
      x.printStackTrace();
    }
  }
  private void HandleSysRequest(TypedMap m)
  {
    String sysRequest = m.getString("sysRequest", null);
    TypedMap r = new TypedMap();
    r.put("callId", m.get("callId"));
    if (sysRequest.equals("testCompatibility"))
      HandleTestCompatibility(r, m);
    else if (sysRequest.equals("getFields"))
      HandleGetFields(r, m);
    else if (sysRequest.equals("getInterfaces"))
      HandleGetInterfaces(r, m);
    Message rm = new Message(r);
    session.send(m.getGUID("sessionId"), rm);
  }
  private void HandleTestCompatibility(TypedMap r, TypedMap m)
  {
    RMCException exc = null;
    String ifName = m.getString("interface");
    try
    {
      ServerStub stub = ServerStub.forName(ifName, target.getClass().getClassLoader());
      Class cls = Class.forName(ifName, false, target.getClass().getClassLoader());



      try
      {
        if (!cls.isAssignableFrom(target.getClass()))
          exc = new RMCException("target object does not implement "+ifName);
      }
      catch(Exception x)
      {
        exc = new RMCException("unknown interface "+ifName, x);
      }
    }
    catch(Exception x)
    {
      exc = new RMCException("no server stub for "+ifName, x);
    }
    if (exc!=null)
    {
      r.put("request", "ErrorResponse");
      r.put("exceptionClass", exc.getClass().getName());
      r.put("exceptionText", exc.toString());
      r.put("exceptionJavaObject", exc);
    }
    else
      r.put("request", "testCompatibilityReply");
  }
  private void HandleGetFields(TypedMap r, TypedMap m)
  {
    r.put("request", "getFieldsReply");
    Metaclass mc = Metaclass.forExtName(m.getString("className"));
    if (mc!=null)
      r.put("value", mc.getFields());
    else
    {
      r.put("value", null);
      log.warning("getFields: no metaclass for: "+m.getString("className"));
    }
  }
  private void HandleGetInterfaces(TypedMap r, TypedMap m)
  {
    r.put("request", "getInterfacesReply");
    try
    {
      Class[] ifcs = target.getClass().getInterfaces();
      TypedArray a = new TypedArray();
      try
      {
        Class c = target.getClass();
        ServerStub.forName(c.getName(), c.getClassLoader());
        log.fine("class "+c.getName()+" is remote");
        a.addString(c.getName());
      }
      catch(Exception x)
      {
        log.fine("class "+target.getClass().getName()+" is local");
      }
      for (Class c : ifcs)
      {
        try
        {
          ServerStub.forName(c.getName(), target.getClass().getClassLoader());
          log.fine("interface "+c.getName()+" is remote");
          a.addString(c.getName());
        }
        catch(Exception x)
        {
          log.fine("interface "+c.getName()+" is local");
        }
      }
      r.put("value", a);
    }
    catch(Exception x)
    {
      log.exception(x);
    }
  }
  /**
   * Performs the invocation specified by the map object.
   */
  public TypedMap invoke(TypedMap m)
  {
    String ifName;
    try
    {
      ifName = m.getString("interface");
    }
    catch(Exception x)
    {
      throw new IllegalArgumentException("interface not specified");
    }
    ServerStub stub;
    try
    {
      stub = ServerStub.forName(ifName, target.getClass().getClassLoader());


    }
    catch(ClassNotFoundException x)
    {
      throw new RMCException("no server stub for "+ifName);
    }
    catch(Exception x)
    {
      throw new RMCException("can't instantiate server stub for "+ifName, x);
    }
    TypedMap r=new TypedMap();
    r.put("callId", m.get("callId"));
    r.put("request", m.get("request")+"Reply");
    stub.invoke(target, m, r);
    return r;
  }
  
  private class InvokeThread extends Thread
  {
    InvokeThread(ServerStub stub, String request, TypedMap param)
    {
      super(Mundo.getThreadGroup(), "oa.invoke");
      this.stub=stub;
      this.request=request;
      this.param=param;
    }
    public void run()
    {
      TypedMap r=new TypedMap();
      if (param.getBoolean("oneWay", false))
        stub.invoke(target, param, r);
      else
      {
        r.put("callId", param.get("callId"));
        r.put("request", param.get("request")+"Reply");
        stub.invoke(target, param, r);
      }
      session.send(param.getGUID("sessionId"), new Message(r));
    }
    ServerStub stub;
    String request;
    TypedMap param;
  }

  private Session session;
  private Object target;
  private GUID guid;
  private Subscriber subscriber;
  private static Logger log = Logger.getLogger("oa");
}
