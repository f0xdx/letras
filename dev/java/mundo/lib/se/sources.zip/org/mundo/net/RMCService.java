/*
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is MundoCore Java.
 *
 * The Initial Developer of the Original Code is Telecooperation Group,
 * Department of Computer Science, Darmstadt University of Technology.
 * Portions created by the Initial Developer are
 * Copyright (C) 2001-2008 the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 * Erwin Aitenbichler
 */

package org.mundo.net;



import java.util.HashMap;

import org.mundo.rt.Service;
import org.mundo.rt.IRMCService;
import org.mundo.rt.IBCLProvider;
import org.mundo.rt.DoObject;
import org.mundo.rt.ObjectAdapter;
import org.mundo.rt.Publisher;
import org.mundo.rt.Subscriber;
import org.mundo.rt.Signal;
import org.mundo.rt.Logger;
import org.mundo.rt.Message;
import org.mundo.rt.TypedMap;




/**
 * A management service to enable Remote Method Calls.
 */
public class RMCService extends Service implements IRMCService, IBCLProvider.ISignal
{
  public RMCService()
  {
    singleton=this;
  }
  /**
   * Returns the singleton instance of this service.
   * @return  the singleton instance of this service, or <code>null</code> if this
   *          service has not been instantiated (from the configuration file).
   */
  public static RMCService getInstance()
  {
    return singleton;
  }
  /**
   * Initializes the service.
   */
  public void init()
  {
    setState(STATE_INITIALIZING);

    // watch new subscriptions in the local runtime
    Signal.connect("rt", IBCLProvider.ISignal.class, this);

    DoObject.rmcService=this;
    setState(STATE_INITIALIZED);
  }
  /**
   * Shuts down the service.
   */
  public void shutdown()
  {
    setState(STATE_SHUTDOWN);
    super.shutdown();
    setState(STATE_DOWN);
  }
  /**
   * Called when the specified client stub is connected to a publisher.
   * @param cs  the client stub.
   */
  public void importObject(DoObject cs) // IRMCService
  {
    log.fine("importObject: "+cs);
    Publisher pub=cs._getPublisher();
    if (pub.isRelevant())
    {
      log.fine("object is connected");
      cs._setState(cs.STATE_CONNECTED);
      postMessage(cs, "objectConnected");
    }
    else
    {
      log.fine("object is disconnected");
      cs._setState(cs.STATE_DISCONNECTED);
    }
    name2cs.put(pub.getChannel().getName(), cs);
  }
  /**
   * Called when a local server object is exported.
   */
  public void exportObject(ObjectAdapter oa)
  {
    log.fine("exportObject: "+oa);
    name2oa.put(oa.getName(), oa);
  }
  public void publisherAdded(Publisher p) /* IBCLProvider.ISignal */
  {
  }
  public void publisherRemoved(Publisher p)  /* IBCLProvider.ISignal */
  {
  }
  public void subscriberAdded(Subscriber s) /* IBCLProvider.ISignal */
  {
//    log.finest("subscriberAdded: "+s);
    DoObject cs = (DoObject)name2cs.get(s.getChannel().getName());
    if (cs==null)
      return;
    if (cs._getState()!=cs.STATE_CONNECTED)
    {
      log.fine("object connected: "+cs);
      cs._setState(cs.STATE_CONNECTED);
      postMessage(cs, "objectConnected");
    }
  }
  public void subscriberRemoved(Subscriber s) /* IBCLProvider.ISignal */
  {
//    log.finest("subscriberRemoved: "+s);
    DoObject cs = (DoObject)name2cs.get(s.getChannel().getName());
    if (cs==null)
      return;
    if (cs._getState()==cs.STATE_CONNECTED)
    {
      log.fine("object disconnected: "+cs);
      cs._setState(cs.STATE_DISCONNECTED);
      postMessage(cs, "objectDisconnected");
    }
  }
  /**
   * Returns the object adapter for the specified object name.
   * @param name  the object name.
   * @return  the object adapter, or <code>null</code> if no adapter for the specified
   *          name is registered.
   */
  public ObjectAdapter getObjectAdapter(String name)
  {
    ObjectAdapter oa = (ObjectAdapter)name2oa.get(name);
    if (oa!=null)
    {
      log.fine("getObjectAdapter: "+name+": success");
      return oa;
    }
    log.fine("getObjectAdapter: "+name+": no such object");
    return null;
  }
  private void postMessage(DoObject cs, String request)
  {
    Message msg=new Message();
    TypedMap map=new TypedMap();
    map.putString("request", request);
    map.put("stub", cs);
    msg.put("RMCService", "active", map);
    cs._getPublisher().getSession().dispatch(null, msg, null);
  }

  private HashMap<String,DoObject> name2cs = new HashMap<String,DoObject>();
  private HashMap<String,ObjectAdapter> name2oa = new HashMap<String,ObjectAdapter>();






  private static Logger log=Logger.getLogger("rmc");
  private static RMCService singleton;
}
