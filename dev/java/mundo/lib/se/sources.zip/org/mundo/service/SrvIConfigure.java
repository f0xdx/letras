package org.mundo.service;


/**
 * Automatically generated server stub for <code>IConfigure</code>
 * @see org.mundo.service.IConfigure
 */
public class SrvIConfigure extends org.mundo.rt.ServerStub
{
  public SrvIConfigure()
  {
  }
  private static org.mundo.rt.ServerStub _obj;
  public static org.mundo.rt.ServerStub _getObject()
  {
    if (_obj==null)
    {
      _obj=new SrvIConfigure();
    }
    return _obj;
  }
  public void invoke(Object o, org.mundo.rt.TypedMap m, org.mundo.rt.TypedMap r)
  {
    String n=m.getString("request");
    IConfigure p=(IConfigure)o;
    try
    {
      if (n.equals("setServiceConfig") && m.getString("ptypes").equals("Object"))
      {
        p.setServiceConfig((Object)m.getObject("p0"));
        return;
      }
      if (n.equals("getServiceConfig") && m.getString("ptypes").equals(""))
      {
        r.putObject("value", p.getServiceConfig());
        return;
      }
      if (n.equals("setServiceConfigMap") && m.getString("ptypes").equals("org.mundo.rt.TypedMap"))
      {
        p.setServiceConfigMap((org.mundo.rt.TypedMap)m.getObject("p0"));
        return;
      }
      if (n.equals("getServiceConfigMap") && m.getString("ptypes").equals(""))
      {
        r.putObject("value", p.getServiceConfigMap());
        return;
      }
      if (n.equals("_getMethods") && m.getString("ptypes").equals(""))
      {
        r.putString("value",
        "v setServiceConfig(Object)\n"+
        "Object getServiceConfig()\n"+
        "v setServiceConfigMap(org.mundo.rt.TypedMap)\n"+
        "org.mundo.rt.TypedMap getServiceConfigMap()\n"+
        "");
        return;
      }
    }
    catch(Exception x)
    {
      exceptionOccured(x, o, m, r);
    }
  }
}