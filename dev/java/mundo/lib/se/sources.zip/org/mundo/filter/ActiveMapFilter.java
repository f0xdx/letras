/*
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is MundoCore Java.
 *
 * The Initial Developer of the Original Code is Telecooperation Group,
 * Department of Computer Science, Darmstadt University of Technology.
 * Portions created by the Initial Developer are
 * Copyright (C) 2001-2008 the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 * Erwin Aitenbichler
 */

package org.mundo.filter;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.NoSuchElementException;

import org.mundo.rt.GUID;
import org.mundo.rt.TypedContainer;
import org.mundo.rt.ActiveMap;
import org.mundo.rt.TypedMap;
import org.mundo.filter.TypedMapFilter;

/**
 * A <code>ActiveMapFilter</code> holds a set of attribute filters
 * to be evaluated against passive <code>ActiveMap</code>s.
 *
 * @author Erwin Aitenbichler
 */
public final class ActiveMapFilter extends ActiveMap implements IFilter
{
  /**
   * Initializes an empty <code>ActiveMapFilter</code>.
   */
  public ActiveMapFilter()
  {
  }
  /**
   * Initializes a <code>ActiveMapFilter</code> from a <code>ActiveMap</code>.
   * All attributes are tested for equality.
   */
  public ActiveMapFilter(ActiveMap map)
  {
    Iterator iter=map.entryIterator();
    ActiveMap.Entry e;
    while (iter.hasNext())
    {
      e=(ActiveMap.Entry)iter.next();
      ht.put((String)e.getKey(), AttributeFilter.forValue(e.getValue()));
    }
  }
  /**
   * Returns a string representation of this filter. The string representation
   * consists of a list of key-value mappings in the order returned by the
   * map's entrySet view's iterator, enclosed in braces ("{}"). The active
   * class name is printed, if it is set, followed by a colon (":"). Adjacent
   * mappings are separated by the characters ", " (comma and space). Each
   * key-value mapping is rendered as the key followed by an equals sign ("=")
   * followed by the associated value.
   *
   * @see java.lang.Object#toString()
   */
  public String toString()
  {
    boolean first=true;
    StringBuffer sb=new StringBuffer();
    sb.append("{");
    Object key;
    AttributeFilter value;
    for (Iterator iter=keySet().iterator(); iter.hasNext();)
    {
      key=iter.next();
      value=(AttributeFilter)get(key);
      if (value.getOp()!=OP_IGNORE)
      {
        if (!first)
          sb.append(", ");
        sb.append(key.toString());
        sb.append(value.toString());
        first=false;
      }
    }
    sb.append("}");
    return sb.toString();
  }

  /**
   * Defines an attribute filter with operator <code>OP_EQUAL</code> and
   * comparison value <code>value</code> to be evaluated against
   * the attribute named <code>key</code>.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * The filter is internally stored using the <code>IntegerAttributeFilter</code> class.
   * @param key    key with which the specified filter is to be associated.
   * @param value  comparison value.
   * @see IntegerAttributeFilter
   */
  @Override
  public void putByte(String key, byte value)
  {
    put(key, new IntegerAttributeFilter(OP_EQUAL, value));
  }
  /**
   * Returns the comparison value to which the specified key is mapped.
   * @param key  the key whose associated comparison value is to be returned.
   * @return     the comparison value to which this map maps the specified key.
   * @throws NoSuchElementException  if there is no mapping for the specified key.
   * @throws NullPointerException    if the specified key is mapped to <code>null</code>.
   *   This exception can only happen in case of a type mismatch, i.e., the specified
   *   key has not previously been mapped by the <code>putInt</code> method.
   * @throws ClassCastException      if the specified key is not mapped to an <code>IntegerAttributeFilter</code>.
   *   This exception can only happen in case of a type mismatch, i.e., the specified
   *   key has not previously been mapped by the <code>putInt</code> method.
   */
  @Override
  public byte getByte(String key)
  {
    IntegerAttributeFilter f = (IntegerAttributeFilter)get(key);
    if (f==null)
      throw new NoSuchElementException("int '"+key+"' not found");
    return (byte)f.intValue();
  }
  /**
   * Returns the comparison value to which the specified key is mapped. In case of any
   * error, <code>defaultValue</code> is returned.
   * @param key  the key whose associated comparison value is to be returned.
   * @param defaultValue  the value to be returned if there is no or no valid
   *   mapping for the specified key.
   * @return     the comparison value to which this map maps the specified key.
   */
  @Override
  public byte getByte(String key, byte defaultValue)
  {
    IntegerAttributeFilter f = (IntegerAttributeFilter)get(key);
    if (f==null)
      return defaultValue;
    return (byte)f.intValue();
  }

  /**
   * Defines an attribute filter with operator <code>OP_EQUAL</code> and
   * comparison value <code>value</code> to be evaluated against
   * the attribute named <code>key</code>.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * The filter is internally stored using the <code>IntegerAttributeFilter</code> class.
   * @param key    key with which the specified filter is to be associated.
   * @param value  comparison value.
   * @see IntegerAttributeFilter
   */
  @Override
  public void putUByte(String key, short value)
  {
    put(key, new IntegerAttributeFilter(OP_EQUAL, value));
  }
  /**
   * Returns the comparison value to which the specified key is mapped.
   * @param key  the key whose associated comparison value is to be returned.
   * @return     the comparison value to which this map maps the specified key.
   * @throws NoSuchElementException  if there is no mapping for the specified key.
   * @throws NullPointerException    if the specified key is mapped to <code>null</code>.
   *   This exception can only happen in case of a type mismatch, i.e., the specified
   *   key has not previously been mapped by the <code>putInt</code> method.
   * @throws ClassCastException      if the specified key is not mapped to an <code>IntegerAttributeFilter</code>.
   *   This exception can only happen in case of a type mismatch, i.e., the specified
   *   key has not previously been mapped by the <code>putInt</code> method.
   */
  @Override
  public short getUByte(String key)
  {
    IntegerAttributeFilter f = (IntegerAttributeFilter)get(key);
    if (f==null)
      throw new NoSuchElementException("int '"+key+"' not found");
    return (short)f.intValue();
  }
  /**
   * Returns the comparison value to which the specified key is mapped. In case of any
   * error, <code>defaultValue</code> is returned.
   * @param key  the key whose associated comparison value is to be returned.
   * @param defaultValue  the value to be returned if there is no or no valid
   *   mapping for the specified key.
   * @return     the comparison value to which this map maps the specified key.
   */
  @Override
  public short getUByte(String key, short defaultValue)
  {
    IntegerAttributeFilter f = (IntegerAttributeFilter)get(key);
    if (f==null)
      return defaultValue;
    return (short)f.intValue();
  }

  /**
   * Defines an attribute filter with operator <code>OP_EQUAL</code> and
   * comparison value <code>value</code> to be evaluated against
   * the attribute named <code>key</code>.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * The filter is internally stored using the <code>IntegerAttributeFilter</code> class.
   * @param key    key with which the specified filter is to be associated.
   * @param value  comparison value.
   * @see IntegerAttributeFilter
   */
  @Override
  public void putShort(String key, short value)
  {
    put(key, new IntegerAttributeFilter(OP_EQUAL, value));
  }
  /**
   * Returns the comparison value to which the specified key is mapped.
   * @param key  the key whose associated comparison value is to be returned.
   * @return     the comparison value to which this map maps the specified key.
   * @throws NoSuchElementException  if there is no mapping for the specified key.
   * @throws NullPointerException    if the specified key is mapped to <code>null</code>.
   *   This exception can only happen in case of a type mismatch, i.e., the specified
   *   key has not previously been mapped by the <code>putInt</code> method.
   * @throws ClassCastException      if the specified key is not mapped to an <code>IntegerAttributeFilter</code>.
   *   This exception can only happen in case of a type mismatch, i.e., the specified
   *   key has not previously been mapped by the <code>putInt</code> method.
   */
  @Override
  public short getShort(String key)
  {
    IntegerAttributeFilter f = (IntegerAttributeFilter)get(key);
    if (f==null)
      throw new NoSuchElementException("int '"+key+"' not found");
    return (short)f.intValue();
  }
  /**
   * Returns the comparison value to which the specified key is mapped. In case of any
   * error, <code>defaultValue</code> is returned.
   * @param key  the key whose associated comparison value is to be returned.
   * @param defaultValue  the value to be returned if there is no or no valid
   *   mapping for the specified key.
   * @return     the comparison value to which this map maps the specified key.
   */
  @Override
  public short getShort(String key, short defaultValue)
  {
    IntegerAttributeFilter f = (IntegerAttributeFilter)get(key);
    if (f==null)
      return defaultValue;
    return (short)f.intValue();
  }

  /**
   * Defines an attribute filter with operator <code>OP_EQUAL</code> and
   * comparison value <code>value</code> to be evaluated against
   * the attribute named <code>key</code>.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * The filter is internally stored using the <code>IntegerAttributeFilter</code> class.
   * @param key    key with which the specified filter is to be associated.
   * @param value  comparison value.
   * @see IntegerAttributeFilter
   */
  @Override
  public void putUShort(String key, int value)
  {
    put(key, new IntegerAttributeFilter(OP_EQUAL, value));
  }
  /**
   * Returns the comparison value to which the specified key is mapped.
   * @param key  the key whose associated comparison value is to be returned.
   * @return     the comparison value to which this map maps the specified key.
   * @throws NoSuchElementException  if there is no mapping for the specified key.
   * @throws NullPointerException    if the specified key is mapped to <code>null</code>.
   *   This exception can only happen in case of a type mismatch, i.e., the specified
   *   key has not previously been mapped by the <code>putInt</code> method.
   * @throws ClassCastException      if the specified key is not mapped to an <code>IntegerAttributeFilter</code>.
   *   This exception can only happen in case of a type mismatch, i.e., the specified
   *   key has not previously been mapped by the <code>putInt</code> method.
   */
  @Override
  public int getUShort(String key)
  {
    IntegerAttributeFilter f = (IntegerAttributeFilter)get(key);
    if (f==null)
      throw new NoSuchElementException("int '"+key+"' not found");
    return f.intValue();
  }
  /**
   * Returns the comparison value to which the specified key is mapped. In case of any
   * error, <code>defaultValue</code> is returned.
   * @param key  the key whose associated comparison value is to be returned.
   * @param defaultValue  the value to be returned if there is no or no valid
   *   mapping for the specified key.
   * @return     the comparison value to which this map maps the specified key.
   */
  @Override
  public int getUShort(String key, int defaultValue)
  {
    IntegerAttributeFilter f = (IntegerAttributeFilter)get(key);
    if (f==null)
      return defaultValue;
    return f.intValue();
  }

  /**
   * Defines an attribute filter with operator <code>OP_EQUAL</code> and
   * comparison value <code>value</code> to be evaluated against
   * the attribute named <code>key</code>.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * The filter is internally stored using the <code>IntegerAttributeFilter</code> class.
   * @param key    key with which the specified filter is to be associated.
   * @param value  comparison value.
   * @see IntegerAttributeFilter
   */
  @Override
  public void putInt(String key, int value)
  {
    put(key, new IntegerAttributeFilter(OP_EQUAL, value));
  }
  /**
   * Returns the comparison value to which the specified key is mapped.
   * @param key  the key whose associated comparison value is to be returned.
   * @return     the comparison value to which this map maps the specified key.
   * @throws NoSuchElementException  if there is no mapping for the specified key.
   * @throws NullPointerException    if the specified key is mapped to <code>null</code>.
   *   This exception can only happen in case of a type mismatch, i.e., the specified
   *   key has not previously been mapped by the <code>putInt</code> method.
   * @throws ClassCastException      if the specified key is not mapped to an <code>IntegerAttributeFilter</code>.
   *   This exception can only happen in case of a type mismatch, i.e., the specified
   *   key has not previously been mapped by the <code>putInt</code> method.
   */
  @Override
  public int getInt(String key)
  {
    IntegerAttributeFilter f = (IntegerAttributeFilter)get(key);
    if (f==null)
      throw new NoSuchElementException("int '"+key+"' not found");
    return f.intValue();
  }
  /**
   * Returns the comparison value to which the specified key is mapped. In case of any
   * error, <code>defaultValue</code> is returned.
   * @param key  the key whose associated comparison value is to be returned.
   * @param defaultValue  the value to be returned if there is no or no valid
   *   mapping for the specified key.
   * @return     the comparison value to which this map maps the specified key.
   */
  @Override
  public int getInt(String key, int defaultValue)
  {
    IntegerAttributeFilter f = (IntegerAttributeFilter)get(key);
    if (f==null)
      return defaultValue;
    return f.intValue();
  }
  /**
   * Defines an attribute filter with operator <code>op</code> and
   * comparison value <code>value</code> to be evaluated against
   * the attribute named <code>key</code>.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * The filter is internally stored using the <code>IntegerAttributeFilter</code> class.
   * @param key    key with which the specified filter is to be associated.
   * @param op     operator. One of <code>OP_EQUAL</code>, <code>OP_NOT_EQUAL</code>,
   *               <code>OP_GREATER</code>, <code>OP_LESS</code>,
   *               <code>OP_LESS_EQUAL</code> or <code>OP_GREATER_EQUAL</code>.
   * @param value  comparison value.
   * @see IntegerAttributeFilter
   */
  public void putInt(String key, int op, int value)
  {
    put(key, new IntegerAttributeFilter(op, value));
  }
  /**
   * Defines an attribute filter with operator <code>op</code> and
   * comparison value <code>value</code> to be evaluated against
   * the attribute named <code>key</code>.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * The filter is internally stored using the <code>IntegerAttributeFilter</code> class.
   * @param key    key with which the specified filter is to be associated.
   * @param op     operator. One of <code>==</code>, <code>!=</code>,
   *               <code>&lt;</code>, <code>&lt;=</code>, <code>&gt;</code> or
   *               <code>&gt;=</code>.
   * @param value  comparison value.
   * @see IntegerAttributeFilter
   */
  public void putInt(String key, String op, int value)
  {
    put(key, new IntegerAttributeFilter(AttributeFilter.parseOp(op), value));
  }

  /**
   * Defines an attribute filter with operator <code>OP_EQUAL</code> and
   * comparison value <code>value</code> to be evaluated against
   * the attribute named <code>key</code>.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * The filter is internally stored using the <code>LongAttributeFilter</code> class.
   * @param key    key with which the specified filter is to be associated.
   * @param value  comparison value.
   * @see LongAttributeFilter
   */
  @Override
  public void putUInt(String key, long value)
  {
    put(key, new LongAttributeFilter(OP_EQUAL, value));
  }
  /**
   * Returns the comparison value to which the specified key is mapped.
   * @param key  the key whose associated comparison value is to be returned.
   * @return     the comparison value to which this map maps the specified key.
   * @throws NoSuchElementException  if there is no mapping for the specified key.
   * @throws NullPointerException    if the specified key is mapped to <code>null</code>.
   *   This exception can only happen in case of a type mismatch, i.e., the specified
   *   key has not previously been mapped by the <code>putInt</code> method.
   * @throws ClassCastException      if the specified key is not mapped to an <code>LongAttributeFilter</code>.
   *   This exception can only happen in case of a type mismatch, i.e., the specified
   *   key has not previously been mapped by the <code>putInt</code> method.
   */
  @Override
  public long getUInt(String key)
  {
    LongAttributeFilter f = (LongAttributeFilter)get(key);
    if (f==null)
      throw new NoSuchElementException("long '"+key+"' not found");
    return f.longValue();
  }
  /**
   * Returns the comparison value to which the specified key is mapped. In case of any
   * error, <code>defaultValue</code> is returned.
   * @param key  the key whose associated comparison value is to be returned.
   * @param defaultValue  the value to be returned if there is no or no valid
   *   mapping for the specified key.
   * @return     the comparison value to which this map maps the specified key.
   */
  @Override
  public long getUInt(String key, long defaultValue)
  {
    LongAttributeFilter f = (LongAttributeFilter)get(key);
    if (f==null)
      return defaultValue;
    return f.longValue();
  }

  /**
   * Defines an attribute filter with operator <code>OP_EQUAL</code> and
   * comparison value <code>value</code> to be evaluated against
   * the attribute named <code>key</code>.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * The filter is internally stored using the <code>LongAttributeFilter</code> class.
   * @param key    key with which the specified filter is to be associated.
   * @param value  comparison value.
   * @see LongAttributeFilter
   */
  @Override
  public void putLong(String key, long value)
  {
    put(key, new LongAttributeFilter(OP_EQUAL, value));
  }
  /**
   * Returns the comparison value to which the specified key is mapped.
   * @param key  the key whose associated comparison value is to be returned.
   * @return     the comparison value to which this map maps the specified key.
   * @throws NoSuchElementException  if there is no mapping for the specified key.
   * @throws NullPointerException    if the specified key is mapped to <code>null</code>.
   *   This exception can only happen in case of a type mismatch, i.e., the specified
   *   key has not previously been mapped by the <code>putInt</code> method.
   * @throws ClassCastException      if the specified key is not mapped to an <code>LongAttributeFilter</code>.
   *   This exception can only happen in case of a type mismatch, i.e., the specified
   *   key has not previously been mapped by the <code>putInt</code> method.
   */
  @Override
  public long getLong(String key)
  {
    LongAttributeFilter f = (LongAttributeFilter)get(key);
    if (f==null)
      throw new NoSuchElementException("long '"+key+"' not found");
    return f.longValue();
  }
  /**
   * Returns the comparison value to which the specified key is mapped. In case of any
   * error, <code>defaultValue</code> is returned.
   * @param key  the key whose associated comparison value is to be returned.
   * @param defaultValue  the value to be returned if there is no or no valid
   *   mapping for the specified key.
   * @return     the comparison value to which this map maps the specified key.
   */
  @Override
  public long getLong(String key, long defaultValue)
  {
    LongAttributeFilter f = (LongAttributeFilter)get(key);
    if (f==null)
      return defaultValue;
    return f.longValue();
  }
  /**
   * Defines an attribute filter with operator <code>op</code> and
   * comparison value <code>value</code> to be evaluated against
   * the attribute named <code>key</code>.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * The filter is internally stored using the <code>LongAttributeFilter</code> class.
   * @param key    key with which the specified filter is to be associated.
   * @param op     operator. One of <code>OP_EQUAL</code>, <code>OP_NOT_EQUAL</code>,
   *               <code>OP_GREATER</code>, <code>OP_LESS</code>,
   *               <code>OP_LESS_EQUAL</code> or <code>OP_GREATER_EQUAL</code>.
   * @param value  comparison value.
   * @see LongAttributeFilter
   */
  public void putLong(String key, int op, long value)
  {
    put(key, new LongAttributeFilter(op, value));
  }
  /**
   * Defines an attribute filter with operator <code>op</code> and
   * comparison value <code>value</code> to be evaluated against
   * the attribute named <code>key</code>.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * The filter is internally stored using the <code>LongAttributeFilter</code> class.
   * @param key    key with which the specified filter is to be associated.
   * @param op     operator. One of <code>==</code>, <code>!=</code>,
   *               <code>&lt;</code>, <code>&lt;=</code>, <code>&gt;</code> or
   *               <code>&gt;=</code>.
   * @param value  comparison value.
   * @see LongAttributeFilter
   */
  public void putLong(String key, String op, long value)
  {
    put(key, new LongAttributeFilter(AttributeFilter.parseOp(op), value));
  }

  /**
   * Defines an attribute filter with operator <code>OP_EQUAL</code> and
   * comparison value <code>value</code> to be evaluated against
   * the attribute named <code>key</code>.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * The filter is internally stored using the <code>LongAttributeFilter</code> class.
   * @param key    key with which the specified filter is to be associated.
   * @param value  comparison value.
   * @see LongAttributeFilter
   */
  @Override
  public void putULong(String key, long value)
  {
    put(key, new LongAttributeFilter(OP_EQUAL, value));
  }
  /**
   * Returns the comparison value to which the specified key is mapped.
   * @param key  the key whose associated comparison value is to be returned.
   * @return     the comparison value to which this map maps the specified key.
   * @throws NoSuchElementException  if there is no mapping for the specified key.
   * @throws NullPointerException    if the specified key is mapped to <code>null</code>.
   *   This exception can only happen in case of a type mismatch, i.e., the specified
   *   key has not previously been mapped by the <code>putInt</code> method.
   * @throws ClassCastException      if the specified key is not mapped to an <code>LongAttributeFilter</code>.
   *   This exception can only happen in case of a type mismatch, i.e., the specified
   *   key has not previously been mapped by the <code>putInt</code> method.
   */
  @Override
  public long getULong(String key)
  {
    LongAttributeFilter f = (LongAttributeFilter)get(key);
    if (f==null)
      throw new NoSuchElementException("long '"+key+"' not found");
    return f.longValue();
  }
  /**
   * Returns the comparison value to which the specified key is mapped. In case of any
   * error, <code>defaultValue</code> is returned.
   * @param key  the key whose associated comparison value is to be returned.
   * @param defaultValue  the value to be returned if there is no or no valid
   *   mapping for the specified key.
   * @return     the comparison value to which this map maps the specified key.
   */
  @Override
  public long getULong(String key, long defaultValue)
  {
    LongAttributeFilter f = (LongAttributeFilter)get(key);
    if (f==null)
      return defaultValue;
    return f.longValue();
  }

  /**
   * Defines an attribute filter with operator <code>OP_EQUAL</code> and
   * comparison value <code>value</code> to be evaluated against
   * the attribute named <code>key</code>.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * The filter is internally stored using the <code>BooleanAttributeFilter</code> class.
   * @param key    key with which the specified filter is to be associated.
   * @param value  comparison value.
   * @see BooleanAttributeFilter
   */
  @Override
  public void putBoolean(String key, boolean value)
  {
    put(key, new BooleanAttributeFilter(OP_EQUAL, value));
  }
  /**
   * Returns the comparison value to which the specified key is mapped.
   * @param key  the key whose associated comparison value is to be returned.
   * @return     the comparison value to which this map maps the specified key.
   * @throws NoSuchElementException  if there is no mapping for the specified key.
   * @throws NullPointerException    if the specified key is mapped to <code>null</code>.
   *   This exception can only happen in case of a type mismatch, i.e., the specified
   *   key has not previously been mapped by the <code>putInt</code> method.
   * @throws ClassCastException      if the specified key is not mapped to an <code>BooleanAttributeFilter</code>.
   *   This exception can only happen in case of a type mismatch, i.e., the specified
   *   key has not previously been mapped by the <code>putInt</code> method.
   */
  @Override
  public boolean getBoolean(String key)
  {
    BooleanAttributeFilter f = (BooleanAttributeFilter)get(key);
    if (f==null)
      throw new NoSuchElementException("boolean '"+key+"' not found");
    return f.booleanValue();
  }
  /**
   * Returns the comparison value to which the specified key is mapped. In case of any
   * error, <code>defaultValue</code> is returned.
   * @param key  the key whose associated comparison value is to be returned.
   * @param defaultValue  the value to be returned if there is no or no valid
   *   mapping for the specified key.
   * @return     the comparison value to which this map maps the specified key.
   */
  @Override
  public boolean getBoolean(String key, boolean defaultValue)
  {
    BooleanAttributeFilter f = (BooleanAttributeFilter)get(key);
    if (f==null)
      return defaultValue;
    return f.booleanValue();
  }
  /**
   * Defines an attribute filter with operator <code>op</code> and
   * comparison value <code>value</code> to be evaluated against
   * the attribute named <code>key</code>.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * The filter is internally stored using the <code>BooleanAttributeFilter</code> class.
   * @param key    key with which the specified filter is to be associated.
   * @param op     operator. One of <code>OP_EQUAL</code> or <code>OP_NOT_EQUAL</code>.
   * @param value  comparison value.
   * @see BooleanAttributeFilter
   */
  public void putBoolean(String key, int op, boolean value)
  {
    put(key, new BooleanAttributeFilter(op, value));
  }
  /**
   * Defines an attribute filter with operator <code>op</code> and
   * comparison value <code>value</code> to be evaluated against
   * the attribute named <code>key</code>.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * The filter is internally stored using the <code>BooleanAttributeFilter</code> class.
   * @param key    key with which the specified filter is to be associated.
   * @param op     operator. One of <code>==</code> or <code>!=</code>.
   * @param value  comparison value.
   * @see BooleanAttributeFilter
   */
  public void putBoolean(String key, String op, boolean value)
  {
    put(key, new BooleanAttributeFilter(AttributeFilter.parseOp(op), value));
  }

  /**
   * Defines an attribute filter with operator <code>OP_EQUAL</code> and
   * comparison value <code>value</code> to be evaluated against
   * the attribute named <code>key</code>.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * The filter is internally stored using the <code>CharAttributeFilter</code> class.
   * @param key    key with which the specified filter is to be associated.
   * @param value  comparison value.
   * @see CharAttributeFilter
   */
  @Override
  public void putChar(String key, char value)
  {
    put(key, new CharAttributeFilter(OP_EQUAL, value));
  }
  /**
   * Returns the comparison value to which the specified key is mapped.
   * @param key  the key whose associated comparison value is to be returned.
   * @return     the comparison value to which this map maps the specified key.
   * @throws NoSuchElementException  if there is no mapping for the specified key.
   * @throws NullPointerException    if the specified key is mapped to <code>null</code>.
   *   This exception can only happen in case of a type mismatch, i.e., the specified
   *   key has not previously been mapped by the <code>putInt</code> method.
   * @throws ClassCastException      if the specified key is not mapped to an <code>CharAttributeFilter</code>.
   *   This exception can only happen in case of a type mismatch, i.e., the specified
   *   key has not previously been mapped by the <code>putInt</code> method.
   */
  @Override
  public char getChar(String key)
  {
    CharAttributeFilter f = (CharAttributeFilter)get(key);
    if (f==null)
      throw new NoSuchElementException("char '"+key+"' not found");
    return f.charValue();
  }
  /**
   * Returns the comparison value to which the specified key is mapped. In case of any
   * error, <code>defaultValue</code> is returned.
   * @param key  the key whose associated comparison value is to be returned.
   * @param defaultValue  the value to be returned if there is no or no valid
   *   mapping for the specified key.
   * @return     the comparison value to which this map maps the specified key.
   */
  @Override
  public char getChar(String key, char defaultValue)
  {
    CharAttributeFilter f = (CharAttributeFilter)get(key);
    if (f==null)
      return defaultValue;
    return f.charValue();
  }
  /**
   * Defines an attribute filter with operator <code>op</code> and
   * comparison value <code>value</code> to be evaluated against
   * the attribute named <code>key</code>.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * The filter is internally stored using the <code>CharAttributeFilter</code> class.
   * @param key    key with which the specified filter is to be associated.
   * @param op     operator. One of <code>OP_EQUAL</code>, <code>OP_NOT_EQUAL</code>,
   *               <code>OP_GREATER</code>, <code>OP_LESS</code>,
   *               <code>OP_LESS_EQUAL</code> or <code>OP_GREATER_EQUAL</code>.
   * @param value  comparison value.
   * @see CharAttributeFilter
   */
  public void putChar(String key, int op, char value)
  {
    put(key, new CharAttributeFilter(op, value));
  }
  /**
   * Defines an attribute filter with operator <code>op</code> and
   * comparison value <code>value</code> to be evaluated against
   * the attribute named <code>key</code>.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * The filter is internally stored using the <code>CharAttributeFilter</code> class.
   * @param key    key with which the specified filter is to be associated.
   * @param op     operator. One of <code>==</code>, <code>!=</code>,
   *               <code>&lt;</code>, <code>&lt;=</code>, <code>&gt;</code> or
   *               <code>&gt;=</code>.
   * @param value  comparison value.
   * @see CharAttributeFilter
   */
  public void putChar(String key, String op, char value)
  {
    put(key, new CharAttributeFilter(AttributeFilter.parseOp(op), value));
  }

  /**
   * Defines an attribute filter with operator <code>OP_EQUAL</code> and
   * comparison value <code>value</code> to be evaluated against
   * the attribute named <code>key</code>.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * The filter is internally stored using the <code>DoubleAttributeFilter</code> class.
   * @param key    key with which the specified filter is to be associated.
   * @param value  comparison value.
   * @see DoubleAttributeFilter
   */
  @Override
  public void putFloat(String key, float value)
  {
    put(key, new DoubleAttributeFilter(OP_EQUAL, value));
  }
  /**
   * Returns the comparison value to which the specified key is mapped.
   * @param key  the key whose associated comparison value is to be returned.
   * @return     the comparison value to which this map maps the specified key.
   * @throws NoSuchElementException  if there is no mapping for the specified key.
   * @throws NullPointerException    if the specified key is mapped to <code>null</code>.
   *   This exception can only happen in case of a type mismatch.
   * @throws ClassCastException      if the specified key is not mapped to an <code>DoubleAttributeFilter</code>.
   *   This exception can only happen in case of a type mismatch.
   */
  @Override
  public float getFloat(String key)
  {
    DoubleAttributeFilter f = (DoubleAttributeFilter)get(key);
    if (f==null)
      throw new NoSuchElementException("double '"+key+"' not found");
    return (float)f.doubleValue();
  }
  /**
   * Returns the comparison value to which the specified key is mapped. In case of any
   * error, <code>defaultValue</code> is returned.
   * @param key  the key whose associated comparison value is to be returned.
   * @param defaultValue  the value to be returned if there is no or no valid
   *   mapping for the specified key.
   * @return     the comparison value to which this map maps the specified key.
   */
  @Override
  public float getFloat(String key, float defaultValue)
  {
    DoubleAttributeFilter f = (DoubleAttributeFilter)get(key);
    if (f==null)
      return defaultValue;
    return (float)f.doubleValue();
  }

  /**
   * Defines an attribute filter with operator <code>OP_EQUAL</code> and
   * comparison value <code>value</code> to be evaluated against
   * the attribute named <code>key</code>.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * The filter is internally stored using the <code>DoubleAttributeFilter</code> class.
   * @param key    key with which the specified filter is to be associated.
   * @param value  comparison value.
   * @see DoubleAttributeFilter
   */
  @Override
  public void putDouble(String key, double value)
  {
    put(key, new DoubleAttributeFilter(OP_EQUAL, value));
  }
  /**
   * Returns the comparison value to which the specified key is mapped.
   * @param key  the key whose associated comparison value is to be returned.
   * @return     the comparison value to which this map maps the specified key.
   * @throws NoSuchElementException  if there is no mapping for the specified key.
   * @throws NullPointerException    if the specified key is mapped to <code>null</code>.
   *   This exception can only happen in case of a type mismatch.
   * @throws ClassCastException      if the specified key is not mapped to an <code>DoubleAttributeFilter</code>.
   *   This exception can only happen in case of a type mismatch.
   */
  @Override
  public double getDouble(String key)
  {
    DoubleAttributeFilter f = (DoubleAttributeFilter)get(key);
    if (f==null)
      throw new NoSuchElementException("double '"+key+"' not found");
    return f.doubleValue();
  }
  /**
   * Returns the comparison value to which the specified key is mapped. In case of any
   * error, <code>defaultValue</code> is returned.
   * @param key  the key whose associated comparison value is to be returned.
   * @param defaultValue  the value to be returned if there is no or no valid
   *   mapping for the specified key.
   * @return     the comparison value to which this map maps the specified key.
   */
  @Override
  public double getDouble(String key, double defaultValue)
  {
    DoubleAttributeFilter f = (DoubleAttributeFilter)get(key);
    if (f==null)
      return defaultValue;
    return f.doubleValue();
  }
  /**
   * Defines an attribute filter with operator <code>op</code> and
   * comparison value <code>value</code> to be evaluated against
   * the attribute named <code>key</code>.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * The filter is internally stored using the <code>DoubleAttributeFilter</code> class.
   * @param key    key with which the specified filter is to be associated.
   * @param op     operator. One of <code>OP_EQUAL</code>, <code>OP_NOT_EQUAL</code>,
   *               <code>OP_GREATER</code>, <code>OP_LESS</code>,
   *               <code>OP_LESS_EQUAL</code> or <code>OP_GREATER_EQUAL</code>.
   * @param value  comparison value.
   * @see DoubleAttributeFilter
   */
  public void putDouble(String key, int op, double value)
  {
    put(key, new DoubleAttributeFilter(op, value));
  }
  /**
   * Defines an attribute filter with operator <code>op</code> and
   * comparison value <code>value</code> to be evaluated against
   * the attribute named <code>key</code>.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * The filter is internally stored using the <code>DoubleAttributeFilter</code> class.
   * @param key    key with which the specified filter is to be associated.
   * @param op     operator. One of <code>==</code>, <code>!=</code>,
   *               <code>&lt;</code>, <code>&lt;=</code>, <code>&gt;</code> or
   *               <code>&gt;=</code>.
   * @param value  comparison value.
   * @see DoubleAttributeFilter
   */
  public void putDouble(String key, String op, double value)
  {
    put(key, new DoubleAttributeFilter(AttributeFilter.parseOp(op), value));
  }

  /**
   * Defines an attribute filter with operator <code>OP_EQUAL</code> and
   * comparison value <code>value</code> to be evaluated against
   * the attribute named <code>key</code>.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * The filter is internally stored using the <code>StringAttributeFilter</code> class.
   * @param key    key with which the specified filter is to be associated.
   * @param value  comparison value.
   * @see StringAttributeFilter
   */
  @Override
  public void putString(String key, String value)
  {
    put(key, new StringAttributeFilter(OP_EQUAL, value));
  }
  /**
   * Returns the comparison value to which the specified key is mapped.
   * @param key  the key whose associated comparison value is to be returned.
   * @return     the comparison value to which this map maps the specified key.
   * @throws NoSuchElementException  if there is no mapping for the specified key.
   * @throws NullPointerException    if the specified key is mapped to <code>null</code>.
   *   This exception can only happen in case of a type mismatch.
   * @throws ClassCastException      if the specified key is not mapped to an <code>StringAttributeFilter</code>.
   *   This exception can only happen in case of a type mismatch.
   */
  @Override
  public String getString(String key)
  {
    StringAttributeFilter f = (StringAttributeFilter)get(key);
    if (f==null)
      throw new NoSuchElementException("string '"+key+"' not found");
    return f.stringValue();
  }
  /**
   * Returns the comparison value to which the specified key is mapped. In case of any
   * error, <code>defaultValue</code> is returned.
   * @param key  the key whose associated comparison value is to be returned.
   * @param defaultValue  the value to be returned if there is no or no valid
   *   mapping for the specified key.
   * @return     the comparison value to which this map maps the specified key.
   */
  @Override
  public String getString(String key, String defaultValue)
  {
    StringAttributeFilter f = (StringAttributeFilter)get(key);
    if (f==null)
      return defaultValue;
    return f.stringValue();
  }
  /**
   * Defines an attribute filter with operator <code>op</code> and
   * comparison value <code>value</code> to be evaluated against
   * the attribute named <code>key</code>.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * The filter is internally stored using the <code>StringAttributeFilter</code> class.
   * @param key    key with which the specified filter is to be associated.
   * @param op     operator. One of <code>OP_EQUAL</code>, <code>OP_NOT_EQUAL</code>,
   *               <code>OP_GREATER</code>, <code>OP_LESS</code>,
   *               <code>OP_LESS_EQUAL</code>, <code>OP_GREATER_EQUAL</code>,
   *               <code>OP_STARTS</code>, <code>OP_ENDS</code> or <code>OP_CONTAINS</code>.
   *               In addition, the flag <code>OP_IGNORE_CASE</code> permits
   *               case insensitive compares.
   * @param value  comparison value.
   * @see StringAttributeFilter
   */
  public void putString(String key, int op, String value)
  {
    put(key, new StringAttributeFilter(op, value));
  }
  /**
   * Defines an attribute filter with operator <code>op</code> and
   * comparison value <code>value</code> to be evaluated against
   * the attribute named <code>key</code>.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * The filter is internally stored using the <code>StringAttributeFilter</code> class.
   * @param key    key with which the specified filter is to be associated.
   * @param op     operator. One of <code>==</code>, <code>!=</code>,
   *               <code>&lt;</code>, <code>&lt;=</code>, <code>&gt;</code>,
   *               <code>&gt;=</code>, <code>begins</code>, <code>ends</code> or
   *               <code>contains</code>.
   * @param value  comparison value.
   * @see StringAttributeFilter
   */
  public void putString(String key, String op, String value)
  {
    put(key, new StringAttributeFilter(AttributeFilter.parseOp(op), value));
  }

  /**
   * Defines an attribute filter with operator <code>OP_EQUAL</code> and
   * comparison value <code>value</code> to be evaluated against
   * the attribute named <code>key</code>.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * The filter is internally stored using the <code>GUIDAttributeFilter</code> class.
   * @param key    key with which the specified filter is to be associated.
   * @param value  comparison value.
   * @see GUIDAttributeFilter
   */
  @Override
  public void putGUID(String key, GUID value)
  {
    put(key, new GUIDAttributeFilter(OP_EQUAL, value));
  }
  /**
   * Returns the comparison value to which the specified key is mapped.
   * @param key  the key whose associated comparison value is to be returned.
   * @return     the comparison value to which this map maps the specified key.
   * @throws NoSuchElementException  if there is no mapping for the specified key.
   * @throws NullPointerException    if the specified key is mapped to <code>null</code>.
   *   This exception can only happen in case of a type mismatch.
   * @throws ClassCastException      if the specified key is not mapped to an <code>GUIDAttributeFilter</code>.
   *   This exception can only happen in case of a type mismatch.
   */
  @Override
  public GUID getGUID(String key)
  {
    GUIDAttributeFilter f = (GUIDAttributeFilter)get(key);
    if (f==null)
      throw new NoSuchElementException("GUID '"+key+"' not found");
    return f.GUIDValue();
  }
  /**
   * Defines an attribute filter with operator <code>op</code> and
   * comparison value <code>value</code> to be evaluated against
   * the attribute named <code>key</code>.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * The filter is internally stored using the <code>GUIDAttributeFilter</code> class.
   * @param key    key with which the specified filter is to be associated.
   * @param op     operator. One of <code>OP_EQUAL</code>, <code>OP_NOT_EQUAL</code>,
   *               <code>OP_GREATER</code>, <code>OP_LESS</code>,
   *               <code>OP_LESS_EQUAL</code> or <code>OP_GREATER_EQUAL</code>.
   * @param value  comparison value.
   * @see GUIDAttributeFilter
   */
  public void putGUID(String key, int op, GUID value)
  {
    put(key, new GUIDAttributeFilter(op, value));
  }
  /**
   * Defines an attribute filter with operator <code>op</code> and
   * comparison value <code>value</code> to be evaluated against
   * the attribute named <code>key</code>.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * The filter is internally stored using the <code>GUIDAttributeFilter</code> class.
   * @param key    key with which the specified filter is to be associated.
   * @param op     operator. One of <code>==</code>, <code>!=</code>,
   *               <code>&lt;</code>, <code>&lt;=</code>, <code>&gt;</code> or
   *               <code>&gt;=</code>.
   * @param value  comparison value.
   * @see GUIDAttributeFilter
   */
  public void putGUID(String key, String op, GUID value)
  {
    put(key, new GUIDAttributeFilter(AttributeFilter.parseOp(op), value));
  }

  /**
   * Defines an attribute filter with operator <code>OP_EQUAL</code> and
   * comparison value <code>value</code> to be evaluated against
   * the attribute named <code>key</code>.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * The filter is internally stored using the <code>ObjectAttributeFilter</code> class.
   * @param key    key with which the specified filter is to be associated.
   * @param value  comparison value.
   * @see ObjectAttributeFilter
   */
  @Override
  public void putObject(String key, Object value)
  {
    put(key, new ObjectAttributeFilter(OP_EQUAL, value));
  }
  /**
   * Returns the comparison value to which the specified key is mapped.
   * @param key  the key whose associated comparison value is to be returned.
   * @return     the comparison value to which this map maps the specified key.
   * @throws NoSuchElementException  if there is no mapping for the specified key.
   * @throws NullPointerException    if the specified key is mapped to <code>null</code>.
   *   This exception can only happen in case of a type mismatch.
   * @throws ClassCastException      if the specified key is not mapped to an <code>ObjectAttributeFilter</code>.
   *   This exception can only happen in case of a type mismatch.
   */
  @Override
  public Object getObject(String key)
  {
    ObjectAttributeFilter f = (ObjectAttributeFilter)get(key);
    if (f==null)
      throw new NoSuchElementException("object '"+key+"' not found");
    return f.getValue();
  }
  /**
   * Returns the comparison value to which the specified key is mapped. In case of any
   * error, <code>defaultValue</code> is returned.
   * @param key  the key whose associated comparison value is to be returned.
   * @param defaultValue  the value to be returned if there is no or no valid
   *   mapping for the specified key.
   * @return     the comparison value to which this map maps the specified key.
   */
  @Override
  public Object getObject(String key, Object defaultValue)
  {
    ObjectAttributeFilter f = (ObjectAttributeFilter)get(key);
    if (f==null)
      return defaultValue;
    return f.getValue();
  }
  /**
   * Defines a filter object to be evaluated against the object attribute named
   * <code>key</code>.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * The filter is internally stored using the <code>ObjectAttributeFilter</code> class.
   * @param key    key with which the specified filter is to be associated.
   * @param op     operator. One of <code>OP_EQUAL</code>, <code>OP_NOT_EQUAL</code> or
   *               <code>OP_FILTER</code>.
   *               If the operator is <code>OP_FILTER</code>, then the value specifies
   *               a filter object that implements <code>IFilter</code>.
   * @param value comparison object or filter object.
   * @see ObjectAttributeFilter
   */
  public void putObject(String key, int op, Object value) throws Exception
  {
    put(key, new ObjectAttributeFilter(op, value));
  }
  /**
   * Defines a filter object to be evaluated against the object attribute named
   * <code>key</code>.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * The filter is internally stored using the <code>ObjectAttributeFilter</code> class.
   * @param key    key with which the specified filter is to be associated.
   * @param op     operator. One of <code>==</code> or <code>!=</code>.
   * @param value  comparison object.
   * @see ObjectAttributeFilter
   */
  public void putObject(String key, String op, Object value) throws Exception
  {
    put(key, new ObjectAttributeFilter(AttributeFilter.parseOp(op), value));
  }

  /**
   * Defines a filter for a nested map.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * @param key    key with which the specified filter is to be associated.
   * @param filter  the filter object.
   */
  public void putMapFilter(String key, ActiveMapFilter filter)
  {
    put(key, filter._getFilter());
  }

  /**
   * Generates a passive filter map from this active object filter.
   */
  public TypedMapFilter _getFilter() // IFilter
  {
    return new TypedMapFilter(ht);
  }

  public IFilter merge(IFilter other) {
    throw new UnsupportedOperationException();
  }

  public boolean matches(Object obj) {
    TypedMapFilter tmf = _getFilter();
    return tmf.matches((TypedMap) obj);
  }
}
