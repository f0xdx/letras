/*
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is MundoCore Java.
 *
 * The Initial Developer of the Original Code is Telecooperation Group,
 * Department of Computer Science, Darmstadt University of Technology.
 * Portions created by the Initial Developer are
 * Copyright (C) 2001-2008 the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 * Erwin Aitenbichler
 */

package org.mundo.rt;

import java.util.Hashtable;


import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * This utility class offers various methods to connect message sources
 * to message consumers.
 *
 * @author Erwin Aitenbichler
 * @author Andreas Hartl
 */
public abstract class Signal
{
  /**
   * Connects a subscriber to a server object. This method exports an object.
   * Remote parties can use the channel associated with the subscriber to
   * issue remote method calls to the specified server object.
   *
   * @param sub  the subscriber object.
   * @param obj  the server object to export. If <code>obj</code> is a client stub,
   *             the associated local object is used.
   * @throws NullPointerException  if a client stub is passed and the associated
   *             object is not local.
   */
  public static void connect(Subscriber sub, Object obj)
  {
    if (obj instanceof DoObject)
    {
      obj=((DoObject)obj)._getLocalObject();
      if (obj==null)
        throw new NullPointerException("server object is not local");
    }
    new ObjectAdapter(sub, obj);
    // FIXME: Session should have a list of exported objects
  }

  /**
   * Connects a client stub to a publisher. After connecting, the client stub
   * can be used to issue remote method calls over the channel.
   *
   * @param stub  the client stub.
   * @param pub   the publisher object.
   */
  public static void connect(DoObject stub, Publisher pub)
  {
    stub._setPublisher(pub);
  }
  /**
   *
   */
  public static void connect(IEmits emitter, Publisher pub)
  {
    throw new UnsupportedOperationException("not implemented");
  }
  /**
   * Disconnects a client stub from its publisher and unadvertises the publisher.
   *
   * @param stub  the client stub.
   */
  public static void disconnect(DoObject stub)
  {
    Publisher pub=stub._getPublisher();
    if (pub!=null)
    {
      stub._setPublisher(null);
      pub.getSession().unpublish(pub);
    }
  }
  /**
   * <p>Connects a client stub to a publisher and defines strict, traditional
   * Client/Server interaction. This means that the server object must already
   * be connected at the other end and export an interface compatible to the
   * specified <code>DoObject</code>. If this method returns without throwing an
   * exception, it is guaranteed that following RMC calls will succeed as long
   * as the server remains reachable (and there are no version conflicts between
   * server and client stubs).</p>
   *
   * <p>This operation verifies that<ul>
   * <li>the specified publisher is relevant, i.e. a subscriber is listening
   *     on the same channel.</li>
   * <li>an ObjectAdapter is connected to the subscriber.</li>
   * <li>a suitable server stub exists and can be instantiated.</li>
   * <li>the interface implemented by the client stub is available on the server side.</li>
   * <li>the target object exists.</li>
   * <li>the server stub is compatible with the target object.</li>
   * </ul>
   *
   * @param stub  the client stub.
   * @param pub   the publisher object.
   * @throws RMCException  if the connect operation was not successful.
   */
  public static void connectStrict(DoObject stub, Publisher pub) throws RMCException
  {
    if (!pub.isRelevant())
    {
      boolean success=false;
      long tmax=System.currentTimeMillis()+stub._getTimeout();
      do
      {
        try
        {
          Thread.sleep(10);
        }
        catch(InterruptedException x)
        {
          throw new RMCException("Interrupt received");
        }
        if (pub.isRelevant())
        {
          success=true;
          break;
        }
      }
      while (System.currentTimeMillis()<tmax);
      if (!success)
        throw new RMCException("The specified publisher is not relevant (i.e. there are no subscribers)");
    }
    stub._setPublisher(pub);
    stub._testCompatibility();
  }

  //~ Methods ------------------------------------------------------------------

  /**
   * Returns an Iterator that iterates over all objects that are interested in
   * receiving events from the given object.
   *
   * @param ifc The signal interface class that contains the event being fired
   * @param src The object firing the event
   *
   * @return An iterator containing the event targets
   */
/*
  public static Iterator getTargets(Class ifc, IEmits src)
  {
    //    System.out.println("publish "+ifc.getName());
    MultiIterator iter = new MultiIterator();

    // add targets globally subscribed to the interface.
    // FIXME: inheritance not handled
    ArrayList a = (ArrayList)ifSubscribers.get(ifc);

    if (a!=null)
      iter.add(a.iterator());

    // add targets subscribed to source object.
    a = (ArrayList)objSubscribers.get(new ObjectInterfaceTuple(src, ifc));

    if (a!=null)
      iter.add(a.iterator());

    return iter;
  }
*/





























  /**
   * Returns the subscribers to the specified interface. Called by the
   * emit stubs generated by mcc.
   *
   * @return  An array holding the event targets. null if empty.
   */
  public static Object[] getIfSubscribers(Class ifc)
  {
    List list = (List)ifSubscribers.get(ifc);
    if (list==null)
      return null;
    Object[] a;
    synchronized(list)
    {
      a = list.toArray();
    }
    return a;
  }
  
  public static Object[] getTargets(Class ifc, IEmits src)
  {
    List list1 = (List)ifSubscribers.get(ifc);
    List list2 = (List)objSubscribers.get(new ObjectInterfaceTuple(src, ifc));

    if (list1==null && list2==null)
      return null;
    if (list1==null)
    {
      list1 = list2;
      list2 = null;
    }
    if (list2==null)
    {
      synchronized(list1)
      {
        return list1.toArray();
      }
    }
    
    synchronized(list1)
    {
      synchronized(list2)
      {
        Object[] a = new Object[list1.size()+list2.size()];
        int i=0;
        for (Object o : list1)
          a[i++] = o;
        for (Object o : list2)
          a[i++] = o;





        return a;
      }
    }
  }

  /**
   * Connects the slots of a target object to the signal interface of a source
   * object. Only the events of one signal interface are connected. Therefore,
   * if an object emits events  of more than one signal interface, one must
   * register the target object seperately for each signal interface.
   *
   * @param iface The signal interface class in which the target object is
   *        interested in
   * @param src The source object emitting the events
   * @param target The target object receiving the events
   *
   * @throws SignalMismatchException If either the source object does not
   * emit the given signal interface or if the target interface does not
   * implement the signal interface
   */
  public static void connect(Class iface, IEmits src, Object target) throws SignalMismatchException
  {
    if(!iface.isAssignableFrom(target.getClass()))
      throw new SignalMismatchException("Target class does not implement signal interface: " + iface.getName());
    if(!src.isEmitting(iface))
      throw new SignalMismatchException("Source class does not emit signal interface: " + iface.getName());
    hashListAdd(objSubscribers, new ObjectInterfaceTuple(src, iface), target);
  }

  /**
   * Connects an object as a slot to another object.
   *
   * @param src DOCUMENT ME!
   * @param target DOCUMENT ME!
   *
   * @throws SignalMismatchException If the source object does not generate
   */
/*
  public static void connect(IEmits src, Object target) throws SignalMismatchException
  {
    System.err.println("connect object not supported");
  }
*/
    /*
       Class ifs[]=target.getClass().getInterfaces();
       int n=0;
       try
        {
         Field f=src.getClass().getField("_emit");
         Object emitStub=f.get(src);
         if (emitStub==null)
          {
           Method m=src.getClass().getMethod("_createEmitStub", null);
           m.invoke(src, null);
           emitStub=f.get(src);
          }
         for (int i=0; i<ifs.length; i++)
          {
           f=emitStub.getClass().getField(getIfListName(ifs[i]));
           Vector v=(Vector)f.get(emitStub);
           v.add(target);
           n++;
          }
        }
       catch(java.lang.NoSuchFieldException x)
        {
        }
       catch(Exception x)
        {
         System.out.println(x);
        }
       if (n==0)
         throw new SignalMismatchException();
     */






















  /**
   * Under construction. Connects all objects emitting the specified signal
   * interface with the specified slot object. Currently, this only
   * works locally.
   *
   * @param nspc  Must be <code>"rt"</code>.
   * @param iface  The signal interface.
   * @param target  The slot object.
   */
  public static void connect(String nspc, Class iface, Object target)
  {
    // FIXME: namespace is ignored
    //    System.out.println("subscribe "+iface.getName());
    hashListAdd(ifSubscribers, iface, target);
  }
  
  public static void disconnect(Class iface, Object target)
  {
    List<Object> a = ifSubscribers.get(iface);


    if (a!=null) synchronized(a)
    {
      for (Iterator iter=a.iterator(); iter.hasNext();)
      {
        if (iter.next()==target)
        {
          iter.remove();
          return;
        }
      }
    }
    throw new IllegalStateException("signal not connected");
  }

  /**
   * DOCUMENT ME!
   *
   * @param ht DOCUMENT ME!
   * @param key DOCUMENT ME!
   * @param value DOCUMENT ME!
   */
  private static void hashListAdd(Hashtable<Object,List<Object>> ht, Object key, Object value)


  {










    List<Object> a=ht.get(key);
    if (a!=null)
    {
      synchronized(a)
      {
        a.add(value);
      }
    }
    else
    {
      a = new ArrayList<Object>();
      a.add(value);
      ht.put(key, a);
    }















  }

  /**
   * DOCUMENT ME!
   *
   * @param c DOCUMENT ME!
   *
   * @return DOCUMENT ME!
   */
  private static String getIfListName(Class c) {
    StringBuffer b = new StringBuffer(c.getName());

    for(int i = 0; i < b.length(); i++) {
      if(b.charAt(i) == '.' || b.charAt(i) == '$')
        b.setCharAt(i, '_');
    }

    b.insert(0, "list");

    return b.toString();
  }

  /**
   * Contains a tuple of target object and target interface
   */
  private static class ObjectInterfaceTuple
  {
    private Object object;
    private Class iface;

    public ObjectInterfaceTuple(Object object, Class iface)
    {
      this.object = object;
      this.iface = iface;
    }

    public boolean equals(Object o)
    {
      if(!(o instanceof ObjectInterfaceTuple))
        return false;

      ObjectInterfaceTuple oit = (ObjectInterfaceTuple)o;

      return oit.object.equals(object) && oit.iface.equals(iface);
    }

    public int hashCode()
    {
      return object.hashCode() ^ iface.hashCode();
    }
  }

  /**
   * Contains objects that subscribe to all events generated by a given signal
   * interface
   */
  private static Hashtable<Object,List<Object>> ifSubscribers = new Hashtable<Object,List<Object>>();
  private static Hashtable<Object,List<Object>> objSubscribers = new Hashtable<Object,List<Object>>();



}
