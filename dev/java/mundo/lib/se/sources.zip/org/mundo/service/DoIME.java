package org.mundo.service;


/**
 * Automatically generated distributed object class for <code>IME</code>.
 * @see org.mundo.service.IME
 */
public class DoIME extends org.mundo.rt.DoObject implements org.mundo.service.IME
{
  public DoIME()
  {
  }
  public DoIME(org.mundo.rt.Session session, Object obj) throws org.mundo.rt.RMCException
  {
    _bind(session, obj);
  }
  public DoIME(org.mundo.rt.Channel channel) throws org.mundo.rt.RMCException
  {
    _setPublisher(channel.getSession().publish(channel.getZone(), channel.getName()));
  }
  public DoIME(org.mundo.rt.DoObject o)
  {
    _assign(o);
  }
  public org.mundo.rt.ServerStub _getServerStub()
  {
    return SrvIME._getObject();
  }
  public static DoIME _of(org.mundo.rt.Session session, Object obj)
  {
    DoIME cs=(DoIME)_getDoObject(session, DoIME.class, obj);
    if (cs==null)
    {
      cs=new DoIME(session, obj);
      _putDoObject(session, obj, cs);
    }
    return cs;
  }
  public static DoIME _of(org.mundo.rt.Service s)
  {
    return _of(s.getSession(), s);
  }
  public String _getInterfaceName()
  {
    return "org.mundo.service.IME";
  }
  public static IME _localObject(IME obj)
  {
    if (obj instanceof org.mundo.rt.DoObject)
    {
      return (IME)((org.mundo.rt.DoObject)obj)._getLocalObject();
    }
    else
    {
      return obj;
    }
  }
  public String getName()
  {
    if (localObj!=null) 
    {
      return ((org.mundo.service.IME)localObj).getName();
    }
    org.mundo.rt.AsyncCall call=getName(SYNC);
    return call.getMap().getString("value");
  }
  public org.mundo.rt.AsyncCall getName(Options opt) 
  {
    org.mundo.rt.TypedMap m=new org.mundo.rt.TypedMap();
    m.putString("ptypes", "");
    m.putString("rtype", "s");
    org.mundo.rt.AsyncCall call=new org.mundo.rt.AsyncCall(this, "org.mundo.service.IME", "getName", m);
    if (opt==ONEWAY)
    {
      call.invokeOneWay();
    }
    else if (opt==SYNC || opt==ASYNC)
    {
      call.invoke();
    }
    if (opt==SYNC)
    {
      try
      {
        if (!call.waitForReply())
        {
          throw call.getException();
        }
      }
      catch(RuntimeException x)
      {
        throw x;
      }
      catch(Exception x)
      {
        throw new org.mundo.rt.RMCException("unexpected exception", x);
      }
    }
    return call;
  }
  
  public String getZoneName()
  {
    if (localObj!=null) 
    {
      return ((org.mundo.service.IME)localObj).getZoneName();
    }
    org.mundo.rt.AsyncCall call=getZoneName(SYNC);
    return call.getMap().getString("value");
  }
  public org.mundo.rt.AsyncCall getZoneName(Options opt) 
  {
    org.mundo.rt.TypedMap m=new org.mundo.rt.TypedMap();
    m.putString("ptypes", "");
    m.putString("rtype", "s");
    org.mundo.rt.AsyncCall call=new org.mundo.rt.AsyncCall(this, "org.mundo.service.IME", "getZoneName", m);
    if (opt==ONEWAY)
    {
      call.invokeOneWay();
    }
    else if (opt==SYNC || opt==ASYNC)
    {
      call.invoke();
    }
    if (opt==SYNC)
    {
      try
      {
        if (!call.waitForReply())
        {
          throw call.getException();
        }
      }
      catch(RuntimeException x)
      {
        throw x;
      }
      catch(Exception x)
      {
        throw new org.mundo.rt.RMCException("unexpected exception", x);
      }
    }
    return call;
  }
  
}