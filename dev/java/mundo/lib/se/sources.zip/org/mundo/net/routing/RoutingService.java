/*
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is MundoCore Java.
 *
 * The Initial Developer of the Original Code is Telecooperation Group,
 * Department of Computer Science, Darmstadt University of Technology.
 * Portions created by the Initial Developer are
 * Copyright (C) 2001-2008 the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 * Erwin Aitenbichler
 */

package org.mundo.net.routing;

import org.mundo.rt.Signal;
import org.mundo.rt.Service;
import org.mundo.rt.Message;
import org.mundo.rt.GUID;
import org.mundo.rt.TypedMap;
import org.mundo.rt.TypedArray;
import org.mundo.rt.Mundo;
import org.mundo.rt.Queue;
import org.mundo.rt.Semaphore;
import org.mundo.rt.IMessageHandler;
import org.mundo.rt.ProtocolStack;
import org.mundo.rt.Logger;
import org.mundo.net.ProtocolCoordinator;
import org.mundo.net.transport.TransportLink;
import org.mundo.net.transport.ITransportConnection;
import org.mundo.net.transport.ITransportService;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.HashMap;
import java.util.Iterator;
import java.net.InetAddress;
import java.net.UnknownHostException;




/**
 * This services requires Java 1.5.
 * 
 * <code>RoutingService</code> implements the following functionality:<ul>
 * <li>Given the <em>receiver's node identifier</em>, it routes a message
 *     to its destination. Thus, the service provides and end-to-end
 *     transport of messages between nodes.</li>
 * <li>The routing service keeps track of transport connections that
 *     exist to neighbor nodes.</li>
 * <li>If multiple connections to a node exist, the service always attempts
 *     to use the connection with the lowest metric, i.e. cost.</li>
 * <li>If connections break, they are automatically re-established,
 *     if possible.</li>
 * </ul>
 * Typically, applications do not directly interface with <code>RoutingService</code>.
 * They use higher-level broker services like <code>P2PTopicBroker</code>, or
 * higher-level concepts like remote method calls.
 *
 * @author Erwin Aitenbichler
 */
public final class RoutingService extends Service
       implements IMessageHandler, org.mundo.rt.IEmits
       /*emits IRoutingService.IConn, IMessageHandler*/
{
  public void init()
  {
    setState(STATE_INITIALIZING);
    thread=new WorkerThread();
    thread.start();

    ProtocolCoordinator.register(mimeType, this);
    setState(STATE_INITIALIZED);
  }
  public void shutdown()
  {
    setState(STATE_SHUTDOWN);
    super.shutdown();

    // send shutdown message to peers
    log.finest("sending NodeShutdown to peers");
    TypedMap map = new TypedMap();
    map.put("request", "NodeShutdown");
    map.put("nodeId", Mundo.getNodeId());
    Message msg = new Message("rs", "passive", map);
    msg.setType(mimeType);
    msg.setStack(ProtocolCoordinator.getInstance().getDefaultStack(), RoutingService.class);
    sendToOpen(msg);

    setState(STATE_DOWN);
    thread.interrupt();
  }
  public boolean down(Message msg) //IMessageHandler
  {
    TypedMap p = (TypedMap)msg.getMap("rs", "param");
    if (p==null)
      throw new IllegalArgumentException("chunk rs.param missing");

    // if this is a unicast message, then send just send it
    String destType = p.getString("destType");
    if ("node".equals(destType))
      return sendTo(p.getGUID("destId"), msg);

    // create a 1st level clone and set our MIME type
    msg = msg.copyFrame();
    String type = msg.getType();
    msg.setType(mimeType);

    TypedMap hdr = new TypedMap();
    hdr.putString("request", "message");
    hdr.putString("type", type);
    msg.put("rs", "passive", hdr);
    
    if ("zone".equals(destType))
    {
      hdr.putString("destType", "zone");
      TypedArray trace = new TypedArray();
      trace.addGUID(Mundo.getNodeId());
      hdr.putArray("trace", trace);
      
      sendToZone(msg);
      return true;
    }
    else if ("src".equals(destType))
    {
      hdr.putString("destType", "src");
      TypedArray src = p.getArray("src");
      hdr.putArray("src", src);

      sendTo(src.getGUID(src.size()-1), msg);
      return true;
    }
    return false;
  }
  public boolean up(Message msg) //IMessageHandler
  {
    TypedMap m = msg.getMap("rs", "passive");
    if (m!=null)
    {
      String req = m.getString("request", null);
      if ("NodeShutdown".equals(req))
      {
        GUID nodeId = m.getGUID("nodeId");
        log.fine("rcvd NodeShutdown from nodeId: "+nodeId.shortString());
        if (neighborTable.removeNode(nodeId))
        {
          log.fine("emit nodeRemoved: "+nodeId.shortString());
          emit.nodeRemoved(nodeId);
        }
        return true;
      }
      if ("message".equals(req))
        return upMessage(msg);
      log.fine("unknown request: "+req);
    }
    else
    {
      log.warning("rcvd unexpected msg: "+msg);
    }
    return true;
  }
  /**
   * Called when a payload message travels up the stack. If the message
   * is a broadcast or source routing (SR) message, it must eventually
   * be forwarded to other nodes.
   */
  private boolean upMessage(Message msg)
  {
    TypedMap hdr = msg.getMap("rs", "passive");
    log.fine("rcvd message "+hdr.getString("type"));













































































    msg.setType(hdr.getString("type"));
    // FIXME: rssub requires this, but it breaks P2PTopicBroker, etc.
//    TypedMap amap = msg.getMap("address", "passive");
//    amap.putString("channel", "rssub."+hdr.getString("type"));
    return emit.up(msg);
  }
  private boolean send(TransportLink link, Message msg)
  {
    msg=msg.copyFrame();
    TypedMap amap=new TypedMap();
    amap.put("link", link);
    msg.put("ts", "param", amap);
    return emit.down(msg);
  }
  private void openAsync(TransportLink link, Message msg)
  {
    TypedMap pmap=new TypedMap();
    pmap.put("request", "openAsync");
    pmap.put("link", link);
    Message cmsg=new Message("ts", "param", pmap);
    cmsg.copyStackFrom(msg);
    emit.down(cmsg);
  }
  public void sendToZone(Message msg) /* IRoutingRequest */
  {
    sendToZone(msg, null);
  }
  private void sendToZone(Message msg, GUID exclude)
  {
    synchronized(neighborTable)
    {
      for (TransportLink link : neighborTable.activeLinks.values())
      {
        if (exclude!=null && exclude.equals(link.remoteId))
          continue;
        log.finest("sendToZone > "+link);
        try
        {
          if (!send(link, msg))
          {
            enqueueMessage(link.remoteId, msg);
            openAsync(link, msg);
          }
        }
        catch(IllegalStateException x)
        {
          // Happens when the connection is concurrently disconnected
        }
        catch(Exception x)
        {
          x.printStackTrace();
        }
      }
    }
  }
  public void sendToOpen(Message msg) /* IRoutingRequest */
  {
    synchronized(neighborTable)
    {
      for (TransportLink link : neighborTable.activeLinks.values())
      {
        try
        {
          send(link, msg);
        }
        catch(IllegalStateException x)
        {
          // Happens when the connection is concurrently disconnected
        }
        catch(Exception x)
        {
          x.printStackTrace();
        }
      }
    }
  }
  public boolean sendTo(GUID id, Message msg) /* IRoutingRequest */
  {
    TransportLink link = neighborTable.get(id);
    if (link==null)
    {
      TypedArray src = routeTable.get(id);
      if (src!=null)
      {
        // clone the message and set our MIME type
        msg = msg.copyFrame();
        String type = msg.getType();
        msg.setType(mimeType);

        // create a source routing header
        TypedMap hdr = new TypedMap();
        hdr.putString("request", "message");
        hdr.putString("type", type);
        hdr.putString("destType", "src");
        hdr.putArray("src", src);
        msg.put("rs", "passive", hdr);

        GUID viaId = src.getGUID(src.size()-1);
        log.finer("send > "+id.shortString()+" via "+viaId.shortString());
        id = viaId;
        link = neighborTable.get(id);
      }
      if (link==null)
      {
        // We don't know the receiver/via node, maybe because connection
        // establishment is still in progress. Enqueue the message.
        log.finer("send > "+id.shortString()+": no route; queueing");
        return enqueueMessage(id, msg);
      }
    }
    synchronized(sendQueues)
    {
      // If a send queue for the specified id exists, then send enqueued
      // messages first.
      Queue q = (Queue)sendQueues.get(id);
      if (q!=null)
      {
        for (Iterator i=q.iterator(); i.hasNext();)
        {
          if (send(link, (Message)i.next()))
          {
            log.finer("send Q > "+id.shortString());
            i.remove();
          }
          else
          {
            log.finer("send Q > "+id.shortString()+" failed");
            openAsync(link, msg);
            return true;
          }
        }
        sendQueues.remove(id);
      }
      if (!send(link, msg))
      {
        log.finer("send > "+id.shortString()+" failed; queueing");
        enqueueMessage(id, msg);
        openAsync(link, msg);
        return true;
      }
      else
      {
        log.finer("send > "+id.shortString());
      }
    }
    return true;
  }
  private boolean enqueueMessage(GUID id, Message msg)
  {
    synchronized(sendQueues)
    {
      Queue<Message> q=sendQueues.get(id);
      if (q==null)
      {
        q=new Queue<Message>();
        sendQueues.put(id, q);
      }
      q.enqueue(msg);
    }
    return true;
  }
  public void discontinued(ITransportConnection conn) /* ITransportConnection.ISignal */
  {
  }
  /**
   * Returns the connection table.
   * @return  a list of <code>ITransportConnection</code> objects.
   */
  public TypedArray getLinks()
  {
    TypedArray links = new TypedArray();
    synchronized(neighborTable)
    {
      links.addAll(neighborTable.links);
    }
    return links;
  }

  public TransportLink getActiveLink(GUID destId)
  {
    synchronized(neighborTable)
    {
      return neighborTable.activeLinks.get(destId.toString());
    }
  }

  /**
   * Neighbor table data structure.
   */
  private class NeighborTable implements ITransportService.IConn
  {
    NeighborTable()
    {
      try
      {
        Signal.connect("rt", ITransportService.IConn.class, this);
      }
      catch(Exception x)
      {
        log.exception(x);
      }
    }
    /**
     * Raised when a new transport link becomes available.
     * @param link  the transport link object.
     * @see ITransportService.IConn
     */
    public void linkAdded(TransportLink link)
    {
      boolean newNode = false;
      synchronized(this)
      {
        if (!announcedNodes.contains(link.remoteId))
        {
          newNode = true;
          for (TransportLink l : links)
          {
            if (l.remoteId.equals(link.remoteId))
            {
              newNode = false;
              break;
            }
          }
        }
        links.add(link);
        promote(link);
        if (newNode)
          log.info("node + "+link.remoteId.shortString());
        log.info("link + "+link.remoteId.shortString());
        if (newNode)
          announcedNodes.add(link.remoteId);
      }
      if (newNode)
        emit.nodeAdded(link.remoteId);
    }
    /**
     * Raised when a transport link was removed.
     * @param link  the transport link object.
     * @see ITransportService.IConn
     */
    public void linkRemoved(TransportLink link)
    {
      synchronized(this)
      {
        if (!links.remove(link))
        {
          log.severe("unknown link: "+link.toString());
          return;
        }
      }
      handleLinkRemoved(link);
    }
    private void handleLinkRemoved(TransportLink link)
    {
      GUID lostNodeId = null;
      synchronized(this)
      {
        if (announcedNodes.contains(link.remoteId))
        {
          lostNodeId = link.remoteId;
          for (TransportLink l : links)
          {
            if (link.remoteId.equals(l.remoteId))
            {
              lostNodeId = null;
              break;
            }
          }
        }
        findBest(link.remoteId);
        log.info("link - "+link.remoteId.shortString());
        if (lostNodeId!=null)
          announcedNodes.remove(lostNodeId);
      }
      if (lostNodeId!=null)
      {
        log.fine("emit nodeRemoved: "+lostNodeId.shortString());
        emit.nodeRemoved(lostNodeId);
      }
    }
    
    /**
     * Raised when a new transport connection has been established.
     * @param link  the transport link object.
     * @see ITransportService.IConn
     */
    public synchronized void connectionOpened(TransportLink link)
    {
      GUID destId = link.remoteId;

      // If a send queue for destId exists, then send enqueued messages.
      synchronized(sendQueues)
      {
        Queue q = (Queue)sendQueues.get(destId);
        if (q!=null)
        {
          boolean success = true;
          for (Iterator i=q.iterator(); i.hasNext();)
          {
            if (send(link, (Message)i.next()))
            {
              log.finer("send Q > "+destId.shortString());
              i.remove();
            }
            else
            {
              log.warning("send Q > "+destId.shortString()+" failed, but connection just opened");
              success = false;
              break;
            }
          }
          if (success)
            sendQueues.remove(destId);
        }
      }

      promote(link);
      log.info("connection + "+link.remoteId.shortString());
    }
    /**
     * Raised when a transport connection has been closed.
     * @param link  the transport link object.
     * @see ITransportService.IConn
     */
    public synchronized void connectionClosed(TransportLink link)
    {
      findBest(link.remoteId);
      log.info("connection - "+link.remoteId.shortString());
    }
    /**
     * Set the specified route as active route if it has a lower metric.
     */
    private void promote(TransportLink link)
    {
      TransportLink current = activeLinks.get(link.remoteId);
      if (current!=null && current.getMetric()<=link.getMetric())
        return;
      activeLinks.put(link.remoteId, link);
    }
    /**
     * Sets the route with the lowest metric as active route for the specified destination.
     */
    private void findBest(GUID destId)
    {
      int minMetric = Integer.MAX_VALUE;
      TransportLink minLink = null;
      for (TransportLink l : links)
      {
        if (l.remoteId.equals(destId) && l.getMetric()<minMetric)
        {
          minLink = l;
          minMetric = l.getMetric();
        }
      }
      if (minLink!=null)
        activeLinks.put(destId, minLink);
      else
        activeLinks.remove(destId);
    }
    /**
     * Returns the active route for the specified destination.
     */
    private synchronized TransportLink get(GUID destId)
    {
      return (TransportLink)activeLinks.get(destId);
    }
    /**
     *
     */
    synchronized void cleanup()
    {
      for (Iterator<TransportLink> iter=links.iterator(); iter.hasNext();)
      {
        TransportLink link = iter.next();
        if (link.lease.add(1)>10)
        {
          log.severe("lease expired for "+link.toString());
          iter.remove();
          handleLinkRemoved(link);
        }
      }
    }

    synchronized boolean removeNode(GUID id)
    {
      // Timeout all routes to the peer which is shutting down
      for (TransportLink link : links)
      {
        if (id.equals(link.remoteId))
          link.timeout = 0;
      }
      return announcedNodes.remove(id);
    }

    private ArrayList<TransportLink> links = new ArrayList<TransportLink>();
    private HashMap<GUID,TransportLink> activeLinks = new HashMap<GUID,TransportLink>();
//    private Semaphore routesSem = new Semaphore(1);
    private HashSet<GUID> announcedNodes = new HashSet<GUID>();
  }

  /**
   * 
   */
  private class RouteTable
  {
    void addTrace(TypedArray src)
    {
      if (src.size()<2)
        return;
      synchronized(this)
      {
        GUID destId = src.getGUID(0);
        TypedArray r = routes.get(destId);
        if (r==null || r.size()>=src.size())
          routes.put(destId, src);
      }
    }
    synchronized TypedArray get(GUID destId)
    {
      return routes.get(destId);
    }
    private HashMap<GUID,TypedArray> routes = new HashMap<GUID,TypedArray>();
  }
  
  private class WorkerThread extends Thread
  {
    WorkerThread()
    {
    }
    public void run()
    {
      try
      {
        for(;;)
        {
          Thread.sleep(1000);
          long startTime=System.currentTimeMillis();
          neighborTable.cleanup();
          long dt=System.currentTimeMillis()-startTime;
          if (dt>100)
            workerLog.fine("neighborTable.cleanup took "+dt+" ms");
        }
      }
      catch(InterruptedException x)
      {
      }
    }
  }
  
  private NeighborTable neighborTable = new NeighborTable();
  private RouteTable routeTable = new RouteTable();
  private HashMap<GUID,Queue<Message>> sendQueues = new HashMap<GUID,Queue<Message>>();
  private static Logger log = Logger.getLogger("rs");
  private static Logger workerLog = Logger.getLogger("rs.worker");
  private WorkerThread thread;
  private static final String mimeType = "message/mc-rs";

  // Generated by mcc
  protected class __EmitStub__ implements IRoutingService.IConn, IMessageHandler
  {
    public void nodeAdded(GUID p0) // IRoutingService.IConn
    {
      Object[] a=org.mundo.rt.Signal.getTargets(IRoutingService.IConn.class, RoutingService.this);
      if (a==null) return;
      for (int i=0; i<a.length; i++)
      {
        try
        {
          ((IRoutingService.IConn)a[i]).nodeAdded(p0);
        }
        catch(Exception x)
        {
          org.mundo.rt.Logger.global.exception(x);
        }
      }
    }
    public void nodeRemoved(GUID p0) // IRoutingService.IConn
    {
      Object[] a=org.mundo.rt.Signal.getTargets(IRoutingService.IConn.class, RoutingService.this);
      if (a==null) return;
      for (int i=0; i<a.length; i++)
      {
        try
        {
          ((IRoutingService.IConn)a[i]).nodeRemoved(p0);
        }
        catch(Exception x)
        {
          org.mundo.rt.Logger.global.exception(x);
        }
      }
    }
    public boolean down(Message p0) // IMessageHandler
    {
      Object[] a=org.mundo.rt.Signal.getTargets(IMessageHandler.class, RoutingService.this);
      if (a==null) throw new IllegalStateException("signal not connected");
      return ((IMessageHandler)a[0]).down(p0);
    }
    public boolean up(Message p0) // IMessageHandler
    {
      Object[] a=org.mundo.rt.Signal.getTargets(IMessageHandler.class, RoutingService.this);
      if (a==null) throw new IllegalStateException("signal not connected");
      return ((IMessageHandler)a[0]).up(p0);
    }
  }
  private __EmitStub__ emit=new __EmitStub__();
  public boolean isEmitting(Class signal)
  {
    if (IRoutingService.IConn.class.isAssignableFrom(signal)) return true;
    if (IMessageHandler.class.isAssignableFrom(signal)) return true;
    return false;
  }
}
