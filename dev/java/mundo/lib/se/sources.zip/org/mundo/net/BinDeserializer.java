/*
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is MundoCore Java.
 *
 * The Initial Developer of the Original Code is Telecooperation Group,
 * Department of Computer Science, Darmstadt University of Technology.
 * Portions created by the Initial Developer are
 * Copyright (C) 2001-2008 the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 * Erwin Aitenbichler
 */

package org.mundo.net;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.Iterator;



import org.mundo.rt.Message;
import org.mundo.rt.Blob;
import org.mundo.rt.GUID;
import org.mundo.rt.TypedContainer;
import org.mundo.rt.TypedArray;
import org.mundo.rt.TypedMap;
import org.mundo.rt.Logger;

//#define TRACE log.trace(42);

/**
 * <code>BinDeserializer</code> transforms a byte stream into a passive object
 * tree. This implementation is not based on streams an will therefore also
 * work on Java versions without serialization support.
 *
 * @see BinSerializer
 * @author Erwin Aitenbichler
 */
public class BinDeserializer
{
  /**
   * Initializies a new BinDeserializer.
   */
  public BinDeserializer()
  {
  }

  /**
   * Deserializes an object.
   * @param blob  the input byte stream.
   * @return      the passive object tree.
   */
  public Object deserialize(Blob blob) throws IOException
  {
    b = blob.getBuffer();
    i = 0;
    return deserialize();
  }

  /**
   * Deserializes a message. Deserializes the chunk <code>main:bin<code>
   * into <code>main:passive</code>.
   * @param msg  a message containing blobs with the serialized data.
   */
  public void deserializeMain(Message msg) throws IOException
  {
    Blob blob = msg.getBlob("main", "bin");
    if (blob==null)
      throw new IllegalArgumentException("main:bin expected");

    b = blob.getBuffer();
    i = 0;
    msg.put("main", "passive", (TypedMap)deserialize());
  }

  /**
   * Deserializes a message. Deserializes all passive and binary chunks.
   * @param msg  a message containing blobs with the serialized data.
   */
  public void deserialize(Message msg) throws IOException
  {
    Blob blob=msg.getBlob("all", "bin");
    if (blob==null)
    {
      System.out.println(msg);
      throw new IllegalArgumentException("all:bin expected");
    }
    b=blob.getBuffer();
//    log.dump(b);
    i=0;
    // Read number of chunks
    int j, n=readInt();
    for (j=0; j<n; j++)
    {
      // Read chunk size in bytes
      int chunkSize=readInt();
      // Read chunk name string
      String name=readString();
      // Read chunk type string
      String type=readString();
      if (type.equals("passive"))
      {
        Object obj=deserialize();
        msg.put(name, type, (TypedMap)obj);
      }
      else
      {
        int sz=chunkSize-4-name.length()-4-type.length();
        Blob content=new Blob();
        content.write(b, i, sz);
        i+=sz;
        msg.put(name, type, content);
      }
    }
  }

  /**
   * Deserializes an object.
   * @param is  an input stream providing the serialized data.
   * @return  the deserialized object.
   */
  public Object deserializeObject(InputStream is) throws IOException
  {
    Blob blob = new Blob();
    blob.readFrom(is);
    return deserialize(blob);
  }

  private static int b2i(byte b)
  {
//    if (b<0)
//      return 0x100+(int)b;
//    return (int)b;
    return (int)(b&0xff);
  }

  private static long i2l(int i)
  {
    if (i<0)
      return 0x100000000L+(long)i;
    return (long)i;
  }

  private short readShort()
  {
    short v=(short)(b2i(b[i])|(b2i(b[i+1])<<8));
    i+=2;
    return v;
  }

  private int readInt()
  {
    int v=b2i(b[i])|(b2i(b[i+1])<<8)|(b2i(b[i+2])<<16)|(b2i(b[i+3])<<24);
    i+=4;
    return v;
  }

  private long readLong()
  {
    int i1=readInt();
    int i2=readInt();
    return i2l(i1)|(i2l(i2)<<32);
  }

  private String readString()
  {
    int v=readInt();
    String s;
    try
    {
      s=new String(b, i, v, "UTF8");
    }
    catch(UnsupportedEncodingException x)
    {
      byte[] a = new byte[v];
      System.arraycopy(b, i, a, 0, v);
      s=new String(a);
    }
    i+=v;
    return s;
  }

  private byte[] readBytes()
  {
    int l=readInt();
    byte[] a=new byte[l];
    System.arraycopy(b, i, a, 0, l);
    i+=l;
    return a;
  }

  private Object deserialize() throws IOException
  {
    switch (b[i++])
    {
      case '0': // object null
      case '1': // string null (distinguished only by the C++ version)
        return null;
      case 'b':
        return new Byte(b[i++]);
      case 'B':
        return new TypedContainer.UnsignedByte(b[i++]);
      case 't':
        return new Boolean( b[i++]!=0 );
      case 'c':
        return new Character((char)(b[i++]&0xff));
      case 'C':
      {
        int v=b[i++];
        v|=(b[i++]<<8);
        return new Character((char)v);
      }
      case 'j':
        return new Short(readShort());
      case 'J':
        return new TypedContainer.UnsignedShort(readShort());
      case 'i':
        return new Integer(readInt());
      case 'I':
        return new TypedContainer.UnsignedInteger(readInt());
      case 'l':
        return new Long(readLong());
      case 'L':
        return new TypedContainer.UnsignedLong(readLong());
      case 'f':
        return new Float(Float.intBitsToFloat(readInt()));
      case 'd':
        return new Double(Double.longBitsToDouble(readLong()));
      case 'g':
      {
        byte[] a = new byte[GUID.GUID_SIZE];
        System.arraycopy(b, i, a, 0, GUID.GUID_SIZE);
        i+=GUID.GUID_SIZE;
        return new GUID(a);
      }
      case 's':
        return readString();
      case 'x':
        return new TypedMap.JavaXDR(readBytes());
      case 'A':
      {
        TypedArray a=new TypedArray();
        int n=readInt();
        String cn=readString();
        if (cn.length()>0)
          a.setActiveClassName(cn);
        for (int i=0; i<n; i++)
          a.add(deserialize());
        return a;
      }
      case 'M':
      {
        TypedMap m=new TypedMap();
        int n=readInt();
        String cn=readString();
        if (cn.length()>0)
          m.setActiveClassName(cn);
        for (int i=0; i<n; i++)
        {
          String key=readString();
          m.put(key, deserialize());
        }
        return m;
      }
      case 'N':
      {
        int n=readInt();
        Blob blob=new Blob();
        blob.write(b, i, n);
        i+=n;
        return blob;
      }
      default:
      {
        i--;
        String s;
        if (b[i]>32)
          s = "unknown token '"+(char)b[i]+"' at "+i;
        else
          s = "unknown token "+b[i]+" at "+i;
        log.warning(s);
        throw new IOException(s);
      }
    }
  }
  
  byte[] b;
  int i;
  private static Logger log = Logger.getLogger("bindeser");
}
