package org.mundo.service;


/**
 * Automatically generated distributed object class for <code>IUS</code>.
 * @see org.mundo.service.IUS
 */
public class DoIUS extends org.mundo.rt.DoObject implements org.mundo.service.IUS
{
  public DoIUS()
  {
  }
  public DoIUS(org.mundo.rt.Session session, Object obj) throws org.mundo.rt.RMCException
  {
    _bind(session, obj);
  }
  public DoIUS(org.mundo.rt.Channel channel) throws org.mundo.rt.RMCException
  {
    _setPublisher(channel.getSession().publish(channel.getZone(), channel.getName()));
  }
  public DoIUS(org.mundo.rt.DoObject o)
  {
    _assign(o);
  }
  public org.mundo.rt.ServerStub _getServerStub()
  {
    return SrvIUS._getObject();
  }
  public static DoIUS _of(org.mundo.rt.Session session, Object obj)
  {
    DoIUS cs=(DoIUS)_getDoObject(session, DoIUS.class, obj);
    if (cs==null)
    {
      cs=new DoIUS(session, obj);
      _putDoObject(session, obj, cs);
    }
    return cs;
  }
  public static DoIUS _of(org.mundo.rt.Service s)
  {
    return _of(s.getSession(), s);
  }
  public String _getInterfaceName()
  {
    return "org.mundo.service.IUS";
  }
  public static IUS _localObject(IUS obj)
  {
    if (obj instanceof org.mundo.rt.DoObject)
    {
      return (IUS)((org.mundo.rt.DoObject)obj)._getLocalObject();
    }
    else
    {
      return obj;
    }
  }
  public String getName()
  {
    if (localObj!=null) 
    {
      return ((org.mundo.service.IUS)localObj).getName();
    }
    org.mundo.rt.AsyncCall call=getName(SYNC);
    return call.getMap().getString("value");
  }
  public org.mundo.rt.AsyncCall getName(Options opt) 
  {
    org.mundo.rt.TypedMap m=new org.mundo.rt.TypedMap();
    m.putString("ptypes", "");
    m.putString("rtype", "s");
    org.mundo.rt.AsyncCall call=new org.mundo.rt.AsyncCall(this, "org.mundo.service.IUS", "getName", m);
    if (opt==ONEWAY)
    {
      call.invokeOneWay();
    }
    else if (opt==SYNC || opt==ASYNC)
    {
      call.invoke();
    }
    if (opt==SYNC)
    {
      try
      {
        if (!call.waitForReply())
        {
          throw call.getException();
        }
      }
      catch(RuntimeException x)
      {
        throw x;
      }
      catch(Exception x)
      {
        throw new org.mundo.rt.RMCException("unexpected exception", x);
      }
    }
    return call;
  }
  
  public void associate(DoIME p0)
  {
    if (localObj!=null) 
    {
      ((org.mundo.service.IUS)localObj).associate(p0);
      return;
    }
    associate(p0, SYNC);
  }
  public org.mundo.rt.AsyncCall associate(DoIME p0, Options opt) 
  {
    org.mundo.rt.TypedMap m=new org.mundo.rt.TypedMap();
    m.putString("ptypes", "DoIME");
    m.putString("rtype", "");
    m.putObject("p0", p0);
    org.mundo.rt.AsyncCall call=new org.mundo.rt.AsyncCall(this, "org.mundo.service.IUS", "associate", m);
    if (opt==ONEWAY)
    {
      call.invokeOneWay();
    }
    else if (opt==SYNC || opt==ASYNC)
    {
      call.invoke();
    }
    if (opt==SYNC)
    {
      try
      {
        if (!call.waitForReply())
        {
          throw call.getException();
        }
      }
      catch(RuntimeException x)
      {
        throw x;
      }
      catch(Exception x)
      {
        throw new org.mundo.rt.RMCException("unexpected exception", x);
      }
    }
    return call;
  }
  
  public void deassociate(DoIME p0)
  {
    if (localObj!=null) 
    {
      ((org.mundo.service.IUS)localObj).deassociate(p0);
      return;
    }
    deassociate(p0, SYNC);
  }
  public org.mundo.rt.AsyncCall deassociate(DoIME p0, Options opt) 
  {
    org.mundo.rt.TypedMap m=new org.mundo.rt.TypedMap();
    m.putString("ptypes", "DoIME");
    m.putString("rtype", "");
    m.putObject("p0", p0);
    org.mundo.rt.AsyncCall call=new org.mundo.rt.AsyncCall(this, "org.mundo.service.IUS", "deassociate", m);
    if (opt==ONEWAY)
    {
      call.invokeOneWay();
    }
    else if (opt==SYNC || opt==ASYNC)
    {
      call.invoke();
    }
    if (opt==SYNC)
    {
      try
      {
        if (!call.waitForReply())
        {
          throw call.getException();
        }
      }
      catch(RuntimeException x)
      {
        throw x;
      }
      catch(Exception x)
      {
        throw new org.mundo.rt.RMCException("unexpected exception", x);
      }
    }
    return call;
  }
  
}