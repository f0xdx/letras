package org.mundo.service;


/**
 * Automatically generated server stub for <code>IServiceManager</code>
 * @see org.mundo.service.IServiceManager
 */
public class SrvIServiceManager extends org.mundo.rt.ServerStub
{
  public SrvIServiceManager()
  {
  }
  private static org.mundo.rt.ServerStub _obj;
  public static org.mundo.rt.ServerStub _getObject()
  {
    if (_obj==null)
    {
      _obj=new SrvIServiceManager();
    }
    return _obj;
  }
  public void invoke(Object o, org.mundo.rt.TypedMap m, org.mundo.rt.TypedMap r)
  {
    String n=m.getString("request");
    IServiceManager p=(IServiceManager)o;
    try
    {
      if (n.equals("getServiceInstances") && m.getString("ptypes").equals(""))
      {
        r.putObject("value", p.getServiceInstances());
        return;
      }
      if (n.equals("getServiceClasses") && m.getString("ptypes").equals(""))
      {
        r.putObject("value", p.getServiceClasses());
        return;
      }
      if (n.equals("getServiceConfig") && m.getString("ptypes").equals("g"))
      {
        r.putObject("value", p.getServiceConfig((org.mundo.rt.GUID)m.getObject("p0")));
        return;
      }
      if (n.equals("setServiceConfig") && m.getString("ptypes").equals("g,org.mundo.rt.TypedMap"))
      {
        p.setServiceConfig((org.mundo.rt.GUID)m.getObject("p0"), (org.mundo.rt.TypedMap)m.getObject("p1"));
        return;
      }
      if (n.equals("shutdownService") && m.getString("ptypes").equals("g"))
      {
        p.shutdownService((org.mundo.rt.GUID)m.getObject("p0"));
        return;
      }
      if (n.equals("shutdownService") && m.getString("ptypes").equals("s"))
      {
        p.shutdownService(m.getString("p0"));
        return;
      }
      if (n.equals("newInstance") && m.getString("ptypes").equals("s,s,org.mundo.rt.TypedMap"))
      {
        r.putObject("value", p.newInstance(m.getString("p0"), m.getString("p1"), (org.mundo.rt.TypedMap)m.getObject("p2")));
        return;
      }
      if (n.equals("uploadFile") && m.getString("ptypes").equals("s,org.mundo.rt.Blob"))
      {
        p.uploadFile(m.getString("p0"), (org.mundo.rt.Blob)m.getObject("p1"));
        return;
      }
      if (n.equals("downloadFile") && m.getString("ptypes").equals("s"))
      {
        r.putObject("value", p.downloadFile(m.getString("p0")));
        return;
      }
      if (n.equals("deleteFile") && m.getString("ptypes").equals("s"))
      {
        p.deleteFile(m.getString("p0"));
        return;
      }
      if (n.equals("advertiseServices") && m.getString("ptypes").equals(""))
      {
        p.advertiseServices();
        return;
      }
      if (n.equals("resumeService") && m.getString("ptypes").equals("org.mundo.rt.TypedMap"))
      {
        p.resumeService((org.mundo.rt.TypedMap)m.getObject("p0"));
        return;
      }
      if (n.equals("_getMethods") && m.getString("ptypes").equals(""))
      {
        r.putString("value",
        "java.util.List getServiceInstances()\n"+
        "java.util.List getServiceClasses()\n"+
        "org.mundo.rt.TypedMap getServiceConfig(g)\n"+
        "v setServiceConfig(g,org.mundo.rt.TypedMap)\n"+
        "v shutdownService(g)\n"+
        "v shutdownService(s)\n"+
        "org.mundo.rt.DoObject newInstance(s,s,org.mundo.rt.TypedMap)\n"+
        "v uploadFile(s,org.mundo.rt.Blob)\n"+
        "org.mundo.rt.Blob downloadFile(s)\n"+
        "v deleteFile(s)\n"+
        "v advertiseServices()\n"+
        "v resumeService(org.mundo.rt.TypedMap)\n"+
        "");
        return;
      }
    }
    catch(Exception x)
    {
      exceptionOccured(x, o, m, r);
    }
  }
}