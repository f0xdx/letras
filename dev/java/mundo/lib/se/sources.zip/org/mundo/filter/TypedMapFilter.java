/*
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is MundoCore Java.
 *
 * The Initial Developer of the Original Code is Telecooperation Group,
 * Department of Computer Science, Darmstadt University of Technology.
 * Portions created by the Initial Developer are
 * Copyright (C) 2001-2008 the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 * Erwin Aitenbichler
 */

package org.mundo.filter;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.mundo.rt.GUID;
import org.mundo.rt.TypedContainer;
import org.mundo.rt.TypedMap;

/**
 * A <code>TypedMapFilter</code> holds a set of attribute filters
 * to be evaluated against passive <code>TypedMap</code>s.
 *
 * @author Erwin Aitenbichler
 */
public final class TypedMapFilter extends AttributeFilter implements
       Map<String,AttributeFilter>


{
  /**
   * Initializes an empty <code>TypedMapFilter</code>.
   */
  public TypedMapFilter()
  {
    op = OP_EQUAL;
  }

  /**
   * Initializes a <code>TypedMapFilter</code> from a <code>TypedMap</code>.
   * All attributes are tested for equality.
   */
  public TypedMapFilter(int op, TypedMap map)
  {
    if (op!=OP_EQUAL && op!=OP_NOT_EQUAL)
      throw new IllegalArgumentException("invalid operator");
    this.op=op;

    Iterator iter=map.entryIterator();
    TypedMap.Entry e;
    while (iter.hasNext())
    {
      e=(TypedMap.Entry)iter.next();
      ht.put((String)e.getKey(), forValue(e.getValue()));
    }
  }

  TypedMapFilter(Map m)
  {
    ht = new HashMap<String,AttributeFilter>(m);
  }






  /**
   * Tests if the specified map matches this filter.
   */
  public boolean matches(Object obj)
  {
    boolean match=((op & OP_NOT)>0) ? false : true;
    if (obj==null)
      return !match;
    TypedMap map=(TypedMap)obj;
    Iterator iter=ht.entrySet().iterator();
    Map.Entry e;
    while (iter.hasNext())
    {
      e=(Map.Entry)iter.next();
      String key=(String)e.getKey();
      AttributeFilter af=(AttributeFilter)e.getValue();
      if (af.getOp()==AttributeFilter.OP_IGNORE)
        continue;
      if (!map.containsKey(key))
        return !match;
      if (!af.matches(map.getObject(key)))
        return !match;
    }
    return match;
  }
  /**
   * Returns the comparison value. This operation is not supported by this class.
   * @throws UnsupportedOperationException
   */
  public Object getValue()
  {
    throw new UnsupportedOperationException();
  }
  /**
   * Returns a string representation of this filter. The string representation
   * consists of a list of key-value mappings in the order returned by the
   * map's entrySet view's iterator, enclosed in braces ("{}"). The active
   * class name is printed, if it is set, followed by a colon (":"). Adjacent
   * mappings are separated by the characters ", " (comma and space). Each
   * key-value mapping is rendered as the key followed by an equals sign ("=")
   * followed by the associated value.
   * 
   * @see java.lang.Object#toString()
   */
  public String toString()
  {
    boolean first=true;
    StringBuffer sb=new StringBuffer();
    sb.append("{");
    Object key;
    AttributeFilter value;
    for (Iterator iter=keySet().iterator(); iter.hasNext();)
    {
      key=iter.next();
      value=(AttributeFilter)get(key);
      if (value.getOp()!=OP_IGNORE)
      {
        if (!first)
          sb.append(", ");
        sb.append(key.toString());
        sb.append(value.toString());
        first=false;
      }
    }
    sb.append("}");
    return sb.toString();
  }

  /**
   * Defines an attribute filter with operator <code>op</code> and
   * comparison value <code>value</code> to be evaluated against
   * the attribute named <code>key</code>.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * The filter is internally stored using the <code>IntegerAttributeFilter</code> class.
   * @param key    key with which the specified filter is to be associated.
   * @param op     operator. One of <code>OP_EQUAL</code>, <code>OP_NOT_EQUAL</code>,
   *               <code>OP_GREATER</code>, <code>OP_LESS</code>,
   *               <code>OP_LESS_EQUAL</code> or <code>OP_GREATER_EQUAL</code>.
   * @param value  comparison value.
   * @see IntegerAttributeFilter
   */
  public void putInt(String key, int op, int value)
  {
    put(key, new IntegerAttributeFilter(op, value));
  }

  /**
   * Defines an attribute filter with operator <code>op</code> and
   * comparison value <code>value</code> to be evaluated against
   * the attribute named <code>key</code>.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * The filter is internally stored using the <code>IntegerAttributeFilter</code> class.
   * @param key    key with which the specified filter is to be associated.
   * @param op     operator. One of <code>==</code>, <code>!=</code>,
   *               <code>&lt;</code>, <code>&lt;=</code>, <code>&gt;</code> or
   *               <code>&gt;=</code>.
   * @param value  comparison value.
   * @see IntegerAttributeFilter
   */
  public void putInt(String key, String op, int value)
  {
    put(key, new IntegerAttributeFilter(AttributeFilter.parseOp(op), value));
  }

  /**
   * Defines an attribute filter with operator <code>op</code> and
   * comparison value <code>value</code> to be evaluated against
   * the attribute named <code>key</code>.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * The filter is internally stored using the <code>CharAttributeFilter</code> class.
   * @param key    key with which the specified filter is to be associated.
   * @param op     operator. One of <code>OP_EQUAL</code>, <code>OP_NOT_EQUAL</code>,
   *               <code>OP_GREATER</code>, <code>OP_LESS</code>,
   *               <code>OP_LESS_EQUAL</code> or <code>OP_GREATER_EQUAL</code>.
   * @param value  comparison value.
   * @see CharAttributeFilter
   */
  public void putChar(String key, int op, char value)
  {
    put(key, new CharAttributeFilter(op, value));
  }

  /**
   * Defines an attribute filter with operator <code>op</code> and
   * comparison value <code>value</code> to be evaluated against
   * the attribute named <code>key</code>.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * The filter is internally stored using the <code>CharAttributeFilter</code> class.
   * @param key    key with which the specified filter is to be associated.
   * @param op     operator. One of <code>==</code>, <code>!=</code>,
   *               <code>&lt;</code>, <code>&lt;=</code>, <code>&gt;</code> or
   *               <code>&gt;=</code>.
   * @param value  comparison value.
   * @see CharAttributeFilter
   */
  public void putChar(String key, String op, char value)
  {
    put(key, new CharAttributeFilter(AttributeFilter.parseOp(op), value));
  }

  /**
   * Defines an attribute filter with operator <code>op</code> and
   * comparison value <code>value</code> to be evaluated against
   * the attribute named <code>key</code>.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * The filter is internally stored using the <code>GUIDAttributeFilter</code> class.
   * @param key    key with which the specified filter is to be associated.
   * @param op     operator. One of <code>OP_EQUAL</code>, <code>OP_NOT_EQUAL</code>,
   *               <code>OP_GREATER</code>, <code>OP_LESS</code>,
   *               <code>OP_LESS_EQUAL</code> or <code>OP_GREATER_EQUAL</code>.
   * @param value  comparison value.
   * @see GUIDAttributeFilter
   */
  public void putGUID(String key, int op, GUID value)
  {
    put(key, new GUIDAttributeFilter(op, value));
  }

  /**
   * Defines an attribute filter with operator <code>op</code> and
   * comparison value <code>value</code> to be evaluated against
   * the attribute named <code>key</code>.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * The filter is internally stored using the <code>GUIDAttributeFilter</code> class.
   * @param key    key with which the specified filter is to be associated.
   * @param op     operator. One of <code>==</code>, <code>!=</code>,
   *               <code>&lt;</code>, <code>&lt;=</code>, <code>&gt;</code> or
   *               <code>&gt;=</code>.
   * @param value  comparison value.
   * @see GUIDAttributeFilter
   */
  public void putGUID(String key, String op, GUID value)
  {
    put(key, new GUIDAttributeFilter(AttributeFilter.parseOp(op), value));
  }

  /**
   * Defines an attribute filter with operator <code>op</code> and
   * comparison value <code>value</code> to be evaluated against
   * the attribute named <code>key</code>.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * The filter is internally stored using the <code>LongAttributeFilter</code> class.
   * @param key    key with which the specified filter is to be associated.
   * @param op     operator. One of <code>OP_EQUAL</code>, <code>OP_NOT_EQUAL</code>,
   *               <code>OP_GREATER</code>, <code>OP_LESS</code>,
   *               <code>OP_LESS_EQUAL</code> or <code>OP_GREATER_EQUAL</code>.
   * @param value  comparison value.
   * @see LongAttributeFilter
   */
  public void putLong(String key, int op, long value)
  {
    put(key, new LongAttributeFilter(op, value));
  }

  /**
   * Defines an attribute filter with operator <code>op</code> and
   * comparison value <code>value</code> to be evaluated against
   * the attribute named <code>key</code>.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * The filter is internally stored using the <code>LongAttributeFilter</code> class.
   * @param key    key with which the specified filter is to be associated.
   * @param op     operator. One of <code>==</code>, <code>!=</code>,
   *               <code>&lt;</code>, <code>&lt;=</code>, <code>&gt;</code> or
   *               <code>&gt;=</code>.
   * @param value  comparison value.
   * @see LongAttributeFilter
   */
  public void putLong(String key, String op, long value)
  {
    put(key, new LongAttributeFilter(AttributeFilter.parseOp(op), value));
  }

  /**
   * Defines an attribute filter with operator <code>op</code> and
   * comparison value <code>value</code> to be evaluated against
   * the attribute named <code>key</code>.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * The filter is internally stored using the <code>DoubleAttributeFilter</code> class.
   * @param key    key with which the specified filter is to be associated.
   * @param op     operator. One of <code>OP_EQUAL</code>, <code>OP_NOT_EQUAL</code>,
   *               <code>OP_GREATER</code>, <code>OP_LESS</code>,
   *               <code>OP_LESS_EQUAL</code> or <code>OP_GREATER_EQUAL</code>.
   * @param value  comparison value.
   * @see DoubleAttributeFilter
   */
  public void putDouble(String key, int op, double value)
  {
    put(key, new DoubleAttributeFilter(op, value));
  }

  /**
   * Defines an attribute filter with operator <code>op</code> and
   * comparison value <code>value</code> to be evaluated against
   * the attribute named <code>key</code>.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * The filter is internally stored using the <code>DoubleAttributeFilter</code> class.
   * @param key    key with which the specified filter is to be associated.
   * @param op     operator. One of <code>==</code>, <code>!=</code>,
   *               <code>&lt;</code>, <code>&lt;=</code>, <code>&gt;</code> or
   *               <code>&gt;=</code>.
   * @param value  comparison value.
   * @see DoubleAttributeFilter
   */
  public void putDouble(String key, String op, double value)
  {
    put(key, new DoubleAttributeFilter(AttributeFilter.parseOp(op), value));
  }

  /**
   * Defines an attribute filter with operator <code>op</code> and
   * comparison value <code>value</code> to be evaluated against
   * the attribute named <code>key</code>.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * The filter is internally stored using the <code>BooleanAttributeFilter</code> class.
   * @param key    key with which the specified filter is to be associated.
   * @param op     operator. One of <code>OP_EQUAL</code> or <code>OP_NOT_EQUAL</code>.
   * @param value  comparison value.
   * @see BooleanAttributeFilter
   */
  public void putBoolean(String key, int op, boolean value)
  {
    put(key, new BooleanAttributeFilter(op, value));
  }

  /**
   * Defines an attribute filter with operator <code>op</code> and
   * comparison value <code>value</code> to be evaluated against
   * the attribute named <code>key</code>.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * The filter is internally stored using the <code>BooleanAttributeFilter</code> class.
   * @param key    key with which the specified filter is to be associated.
   * @param op     operator. One of <code>==</code> or <code>!=</code>.
   * @param value  comparison value.
   * @see BooleanAttributeFilter
   */
  public void putBoolean(String key, String op, boolean value)
  {
    put(key, new BooleanAttributeFilter(AttributeFilter.parseOp(op), value));
  }

  /**
   * Defines an attribute filter with operator <code>op</code> and
   * comparison value <code>value</code> to be evaluated against
   * the attribute named <code>key</code>.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * The filter is internally stored using the <code>StringAttributeFilter</code> class.
   * @param key    key with which the specified filter is to be associated.
   * @param op     operator. One of <code>OP_EQUAL</code>, <code>OP_NOT_EQUAL</code>,
   *               <code>OP_GREATER</code>, <code>OP_LESS</code>,
   *               <code>OP_LESS_EQUAL</code>, <code>OP_GREATER_EQUAL</code>,
   *               <code>OP_STARTS</code>, <code>OP_ENDS</code> or <code>OP_CONTAINS</code>.
   *               In addition, the flag <code>OP_IGNORE_CASE</code> permits
   *               case insensitive compares.
   * @param value  comparison value.
   * @see StringAttributeFilter
   */
  public void putString(String key, int op, String value)
  {
    put(key, new StringAttributeFilter(op, value));
  }

  /**
   * Defines an attribute filter with operator <code>op</code> and
   * comparison value <code>value</code> to be evaluated against
   * the attribute named <code>key</code>.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * The filter is internally stored using the <code>StringAttributeFilter</code> class.
   * @param key    key with which the specified filter is to be associated.
   * @param op     operator. One of <code>==</code>, <code>!=</code>,
   *               <code>&lt;</code>, <code>&lt;=</code>, <code>&gt;</code>,
   *               <code>&gt;=</code>, <code>begins</code>, <code>ends</code> or
   *               <code>contains</code>.
   * @param value  comparison value.
   * @see StringAttributeFilter
   */
  public void putString(String key, String op, String value)
  {
    put(key, new StringAttributeFilter(AttributeFilter.parseOp(op), value));
  }

  /*
   * Defines a filter object to be evaluated against the object attribute named
   * <code>key</code>.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * The filter is internally stored using the <code>ObjectAttributeFilter</code> class.
   * @param key    key with which the specified filter is to be associated.
   * @param op     operator. One of <code>OP_EQUAL</code>, <code>OP_NOT_EQUAL</code> or
   *               <code>OP_FILTER</code>.
   *               If the operator is <code>OP_FILTER</code>, then the value specifies
   *               a filter object that implements <code>IFilter</code>.
   * @param value comparison object or filter object.
   * @see ObjectAttributeFilter
   */
/*
  public void putObject(String key, int op, Object value)
  {
    put(key, new ObjectAttributeFilter(op, value));
  }
*/
  public void putPassivated(String key, int op, Object value) throws Exception
  {
    if (value instanceof IFilter)
      value = ((IFilter)value)._getFilter();
    else
      value = TypedContainer.passivate(value);
    put(key, new ObjectAttributeFilter(op, value));
  }

  /*
   * Defines a filter object to be evaluated against the object attribute named
   * <code>key</code>.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * The filter is internally stored using the <code>ObjectAttributeFilter</code> class.
   * @param key    key with which the specified filter is to be associated.
   * @param op     operator. One of <code>==</code> or <code>!=</code>.
   * @param value  comparison object.
   * @see ObjectAttributeFilter
   */
/*
  public void putObject(String key, String op, Object value)
  {
    put(key, new ObjectAttributeFilter(AttributeFilter.parseOp(op), value));
  }
*/
  /**
   * Defines a filter for a nested map.
   * If the map previously contained a mapping for <code>key</code>,
   * the old mapping is replaced regardless of the previous type.
   * @param key    key with which the specified filter is to be associated.
   * @param filter  the filter object.
   */
  public void putMapFilter(String key, TypedMapFilter filter)
  {
    put(key, filter);
  }

  /**
   * Removes all mappings from this map.
   * 
   * @see java.util.Map#clear()
   */
  public void clear() // Map
  {
    ht.clear();
  }
  /**
   * Returns <code>true</code> if this map contains a mapping for the specified key.
   * 
   * @see java.util.Map#containsKey(Object)
   */
  public boolean containsKey(Object key) // Map
  {
    return ht.containsKey(key);
  }
  /**
   * Returns <code>true</code> if this map maps one or more keys to this value.
   * More formally, returns <code>true</code> if and only if this map contains
   * at least one mapping to a value v such that
   * <code>(value==null ? v==null : value.equals(v))</code>. This operation
   * will probably require time linear in the map size for most implementations
   * of map.
   * 
   * @see java.util.Map#containsValue(Object)
   */
  public boolean containsValue(Object value) // Map
  {
    return ht.containsValue(value);
  }
  /**
   * Returns a set view of the mappings contained in this map. Each element in
   * this set is a Map.Entry. The set is backed by the map, so changes to the
   * map are reflected in the set, and vice-versa. (If the map is modified
   * while an iteration over the set is in progress, the results of the iteration
   * are undefined.) The set supports element removal, which removes the
   * corresponding entry from the map, via the <code>Iterator.remove</code>,
   * <code>Set.remove</code>, <code>removeAll</code>, <code>retainAll</code>
   * and <code>clear</code> operations. It does not support the <code>add</code>
   * or <code>addAll</code> operations.
   * 
   * @see java.util.Map#entrySet()
   */
  public Set<Map.Entry<String,AttributeFilter>> entrySet() // Map


  {
    return ht.entrySet();
  }
  /**
   * Compares the specified object with this map for equality. Returns
   * <code>true</code> if the given object is also a <code>TypedMap</code>
   * and the two maps represent the same mappings. Furthermore, the
   * represented active class has to be identical.
   *  
   * @see java.util.Map#equals(Object)
   */
  public boolean equals(Object obj)
  {
    return ht.equals(((TypedMapFilter)obj).ht);
  }
  /**
   * Returns the value to which this map maps the specified key. Returns
   * <code>null</code> if the map contains no mapping for this key. A return
   * value of <code>null</code> does not necessarily indicate that the map
   * contains no mapping for the key; it's also possible that the map
   * explicitly maps the key to <code>null</code>. The <code>containsKey</code>
   * operation may be used to distinguish these two cases.
   * 
   * @see java.util.Map#get(Object)
   */
  public AttributeFilter get(Object key) // Map


  {
    return ht.get(key);
  }
  /**
   * Returns the hash code value for this map. The hash code of a map is defined
   * to be the sum of the hash codes of each entry in the map's
   * <code>entrySet()</code> view.
   * 
   * @see java.util.Map#hashCode()
   */
  public int hashCode() // Map
  {
    return ht.hashCode();
  }
  /**
   * Returns <code>true</code> if this map contains no key-value mappings.
   * 
   * @see java.util.Map#isEmpty()
   */
  public boolean isEmpty() // Map
  {
    return ht.isEmpty();
  }
  /**
   * Returns a Set view of the keys contained in this map. The Set is backed by
   * the map, so changes to the map are reflected in the Set, and vice-versa.
   * (If the map is modified while an iteration over the Set is in progress,
   * the results of the iteration are undefined.)
   * 
   * @see java.util.Map#keySet()
   */
  public Set<String> keySet() // Map


  {
    return ht.keySet();
  }
  /**
   * Associates the specified value with the specified key in this map
   * (optional operation). If the map previously contained a mapping for this
   * key, the old value is replaced.
   *
   * @see java.util.Map#put(Object,Object)
   */
  public AttributeFilter put(String key, AttributeFilter value) // Map


  {
    return ht.put(key, value);
  }
  /**
   * Copies all of the mappings from the specified map to this map. These
   * mappings will replace any mappings that this map had for any of the keys
   * currently in the specified map.
   * 
   * @see java.util.Map#putAll(Map)
   */
  public void putAll(Map<? extends String, ? extends AttributeFilter> t) // Map


  {
    ht.putAll(t);
  }
  /**
   * Removes the mapping for this key from this map if present.
   * 
   * @see java.util.Map#remove(Object)
   */
  public AttributeFilter remove(Object key) // Map


  {
    return ht.remove(key);
  }
  /**
   * Returns the number of key-value mappings in this map.
   * 
   * @see java.util.Map#size()
   */
  public int size() // Map
  {
    return ht.size();
  }
  /**
   * Returns a collection view of the values contained in this map. The collection
   * is backed by the map, so changes to the map are reflected in the collection,
   * and vice-versa. (If the map is modified while an iteration over the collection
   * is in progress, the results of the iteration are undefined.) 
   * 
   * @see java.util.Map#values()
   */
  public Collection<AttributeFilter> values() // Map


  {
    return ht.values();
  }

  public void _passivate(TypedMap pParent) throws Exception
  {
    super._passivate(pParent);
    TypedMap p=new TypedMap();
    for (Map.Entry<String,AttributeFilter> e : ht.entrySet())
      p.put(e.getKey(), TypedContainer.passivate(e.getValue()));






    pParent.put("filters", p);
  }
  public void _activate(org.mundo.rt.TypedMap pParent, org.mundo.rt.TypedMap ctx) throws Exception
  {
    super._activate(pParent, ctx);
    try
    {
      TypedMap p=pParent.getMap("filters");
      for (Map.Entry<String,Object> e : p.entrySet())
        ht.put(e.getKey(), (AttributeFilter)TypedContainer.activate(e.getValue(), ctx));






    }
    catch(Exception x)
    {
      x.printStackTrace();
    }
  }

  private HashMap<String,AttributeFilter> ht = new HashMap<String,AttributeFilter>();


}
