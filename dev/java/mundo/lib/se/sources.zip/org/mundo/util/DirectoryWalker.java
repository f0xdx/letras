/*
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is MundoCore Java.
 *
 * The Initial Developer of the Original Code is Telecooperation Group,
 * Department of Computer Science, Darmstadt University of Technology.
 * Portions created by the Initial Developer are
 * Copyright (C) 2001-2008 the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 * Erwin Aitenbichler
 */

package org.mundo.util;

import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Queue;
import java.util.Set;

/**
 * A DirectoryWalker iterates over all of the files of a directory and its
 * subdirectories. The DirectoryWalker is aware of symbolic links and of
 * recursions that may result from them.
 * 
 * Walking will start at given directory and is breadth first. Calls to the
 * remove method of the Walker will be mapped to a delete for the file.
 * 
 * The iterators of a DirectoryWalker are not fail-fast - the directories may be
 * modified during the runtime of the DirectoryWalker without detecting that.
 * 
 * @author AHa
 */
public class DirectoryWalker implements Iterable<File>
{



  private boolean followsymbolic;

  private File dir;

  /**
   * Equivalent to DirectoryWalker(dir, true)
   * 
   * @param dir the directory to walk through
   * @throws IOException 
   */
  public DirectoryWalker(File dir) throws IOException {
    this(dir, true);
  }

  /**
   * Initializes a new directory walker for a given directory. If the dir
   * parameter does not point to a directory at the time the Walker's iterator
   * method is called, then the Walker constructed will stop imediately.
   * 
   * @param dir the directory to walk through.
   * @param followsymbolic true if symbolic links should be followed, false
   *          otherwise
   */
  public DirectoryWalker(File dir, boolean followsymbolic) throws IOException {
    if(dir == null)
      throw new NullPointerException();
    this.dir = dir.getCanonicalFile();
    this.followsymbolic = followsymbolic;
  }

  public Iterator<File> iterator()
  {
    return new WalkerIterator(dir, new HashSet<File>());
  }






  private class WalkerIterator implements Iterator<File>


  {
    int idx = 0;

    File[] dircontent;
    Queue<File> subdir = new LinkedList<File>();
    Set<File> walked;
    Iterator<File> child;




    boolean valid = false;
    File cur;

    WalkerIterator(File dir, Set<File> walked)


    {
      this.walked = walked;
      if(walked.add(dir))
        dircontent = dir.listFiles();
      if(dircontent == null)
        dircontent = new File[0];
    }

    private void ensureChild() {
      while(!subdir.isEmpty() && (child == null || !child.hasNext()))
        child = new WalkerIterator((File)subdir.poll(), walked);
      if(child == null)
      {
        List<File> l = Collections.emptyList(); 


        child = l.iterator();
      }
    }

    public boolean hasNext() {
      if(idx < dircontent.length)
        return true;
      ensureChild();
      return child.hasNext();
    }

    public File next()


    {
      valid = true;

      // first spit out the files of the current directory to create a breadth
      // first access
      if(idx < dircontent.length) {
        cur = dircontent[idx++];
        if(cur.isDirectory())
          try {
            File canonical = cur.getCanonicalFile();
            // the cannonical path method tries to resolve a symlink if the
            boolean nosymlink = canonical.equals(cur.getAbsoluteFile());

            if(nosymlink || followsymbolic)
              subdir.add(canonical);
          } catch(IOException e) {
            // ignore IOExceptions right now if the canonical path could not be
            // resolved - as a result this will just return the File and not
            // follow the subdirectory
          }
      } else {
        ensureChild();
        if(!child.hasNext())
          throw new NoSuchElementException();
        cur = (File)child.next();
      }
      return cur;
    }

    public void remove() {
      if(!valid)
        throw new IllegalStateException();

      valid = false;
      cur.delete();
    }

  }

}
